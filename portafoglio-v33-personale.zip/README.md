# Portafoglio 2026 V3.3 Personale

Versione tecnica 3.3.0 - versionCode 41.

## Novità V3.3
- capitale investito e liquidità separati;
- patrimonio totale calcolato come investito + liquidità;
- rendimento calcolato sul patrimonio totale, così l'acquisto di titoli con liquidità già nel broker non crea un falso rendimento;
- nuovi campi iniziali/finali per investito e liquidità;
- compatibilità con i vecchi snapshot V3.2: i valori totali esistenti restano conservati e possono essere separati successivamente;
- backup CSV V3.3 con i nuovi campi e import dei backup precedenti.

La versione personale mantiene lo stesso applicationId per preservare il database quando Android consente un aggiornamento firmato con la stessa chiave.
