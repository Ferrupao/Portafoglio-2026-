# Portafoglio 2026 — V3.4.28 DEV

Aggiornamento grafico e funzionale orientato a leggibilità, performance lorda e coerenza cromatica.

## Novità V3.4.28 DEV
- Nuova schermata separata **Performance** con viste **Giorno / Mese / Anno**.
- Performance lorda registrata = proventi lordi noti + P/L realizzato lordo; tasse e costi non vengono sottratti. Gli storici aggregati con data tecnica concorrono solo al totale annuo, senza falsa attribuzione giornaliera/mensile.
- I proventi inseriti come "già netto" sono mostrati nel dettaglio ma esclusi dal totale lordo perché il lordo non è noto.
- Accesso alla Performance da Dashboard, Home/Riepilogo storico e menu Altro del portafoglio.
- Valori positivi e proventi in verde; costi, tasse, minusvalenze e perdite in rosso.
- **Netto noto YTD** sostituisce "Netto YTD parziale" quando lo storico fiscale è incompleto, con indicazione della quota di lordo fiscalmente completa.
- Composizione patrimonio ridisegnata in stile più scuro e compatto, ispirata alla leggibilità delle schermate broker moderne senza copiarne l'interfaccia.
- Grafico patrimonio trasformato in **semicerchio**, senza percentuali interne; percentuali solo nelle righe di categoria sotto il grafico.
- Pulsanti/card più scuri e caratteri leggermente più grandi.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `70`
- versionName: `3.4.28-dev`
- DB_VERSION: `10` invariato
- Aggiornamento installabile sopra V3.4.27 senza disinstallazione.
