# Portafoglio 2026 V3.4.21 Stable Beta

Versione tecnica **3.4.21** - versionCode **63** - database **10**.

## Novità V3.4.21 – interfaccia più intuitiva

- nella Home **Cerca titolo** e **Inserisci titolo** sono ora le prime azioni operative, prima dell’elenco dei portafogli;
- **Cerca titolo** continua a cercare globalmente per **nome, ISIN o ticker**;
- **Inserisci titolo** dalla Home chiede subito il portafoglio di destinazione;
- il vecchio pulsante ambiguo **Inserimento rapido** è rinominato **Altre operazioni rapide** e resta secondario;
- nelle dashboard dei singoli portafogli la scheda **Posizioni** viene mostrata prima dei grafici;
- i pulsanti **Cerca titolo** e **Inserisci titolo** nelle dashboard sono più alti e leggibili sui display stretti;
- i grafici restano disponibili più in basso, dopo le azioni operative;
- tutte le correzioni V3.4.20 restano incluse: ricerca nome/ISIN/ticker, categoria manuale prioritaria, Poste Italiane classificata come Azioni, Altro residuale per BTP/BOT/obbligazioni.

## Compatibilità

Mantiene lo stesso `applicationId`, lo stesso database **10** e la stessa pipeline di firma permanente. È progettata per essere installata sopra la V3.4.20 senza cancellare i dati.

Backup CSV aggiornato a **PORTAFOGLIO2026_V3421** e compatibile con i backup precedenti.
