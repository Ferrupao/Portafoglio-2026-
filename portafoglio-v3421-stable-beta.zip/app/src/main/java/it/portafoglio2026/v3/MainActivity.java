package it.portafoglio2026.v3;

import android.app.*;
import android.os.Bundle;
import android.os.Build;
import android.graphics.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Settings;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    DbHelper db;
    LinearLayout content, menuGrid;
    TextView title, subtitle;
    String current = "HOME";
    final String TOTAL = "Totale";
    final String[] months={"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"};
    final String[] categories={"Azioni","ETF","ETP","Certificati","Altro"};
    final String[] incomeCategories={"Azioni","ETF","ETP","Certificati","Liquidità","Altro"};
    final String[] incomeTypes={"Dividendo","Cedola","Distribuzione","Interesse","Altro provento"};
    final String[] brokerProfiles={"Riconoscimento automatico","Trade Republic","Directa","Fineco","Interactive Brokers","DEGIRO","Scalable Capital","eToro","Altro / Generico"};
    final String[] genericMovementTypes={"Versamento personale","Prelievo","Trasferimento interno","PAC","Acquisto","Vendita","Altro"};
    final String[] tradeRepublicMovementTypes={"Versamento personale","Prelievo","Trasferimento interno","PAC","Acquisto","Vendita","Round up","Saveback","Pagamento carta (escluso dall’analisi)","Altro"};
    final DecimalFormat euro = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.ITALY));
    final DecimalFormat pct = new DecimalFormat("0.00%", DecimalFormatSymbols.getInstance(Locale.ITALY));
    String pendingImport="";
    DirectaImport pendingDirectaImport;
    String pendingImportPortfolio="";
    String pendingStatementHash="", pendingStatementName="";

    static class DirectaImport {
        String date=""; Double cash=null, invested=null, printedInvested=null; String parser="";
        List<DbHelper.Position> positions=new ArrayList<>();
    }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        PDFBoxResourceLoader.init(getApplicationContext());
        db=new DbHelper(this);
        db.normalizeKnownNetIncomeModes();
        db.normalizeKnownHistoricalIncomeTypes();
        buildShell();
        showHome();
    }

    TextView tv(String text,int size,boolean bold){
        TextView v=new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(Color.rgb(31,41,55));
        if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        v.setPadding(dp(4),dp(6),dp(4),dp(6)); return v;
    }

    Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); b.setGravity(Gravity.CENTER); b.setMinHeight(dp(52)); return b;
    }

    void buildShell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        getWindow().setStatusBarColor(Color.rgb(16,42,67)); getWindow().setNavigationBarColor(Color.rgb(245,247,250));
        if(Build.VERSION.SDK_INT>=30){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets s=insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0,s.top,0,s.bottom); return insets;
            });
        }else root.setFitsSystemWindows(true);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(8),0,dp(8),0); top.setBackgroundColor(Color.rgb(16,42,67));
        Button home=btn("⌂"); home.setTextSize(22); home.setOnClickListener(v->showHome());
        top.addView(home,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setPadding(dp(8),0,0,0);
        title=tv("Portafoglio 2026",20,true); title.setTextColor(Color.WHITE); title.setPadding(0,0,0,0);
        subtitle=tv("",12,false); subtitle.setTextColor(Color.rgb(215,230,244)); subtitle.setPadding(0,0,0,0);
        titles.addView(title); titles.addView(subtitle); top.addView(titles,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(58)));

        menuGrid=new LinearLayout(this); menuGrid.setOrientation(LinearLayout.VERTICAL); menuGrid.setPadding(dp(8),dp(7),dp(8),dp(7)); menuGrid.setBackgroundColor(Color.WHITE); menuGrid.setVisibility(View.GONE);
        String[][] rows={{"Dashboard","Titoli","Proventi"},{"Rendimento","PAC","Storico"},{"Impostazioni"}};
        for(String[] rowNames:rows){
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for(String name:rowNames){
                Button b=btn(name); b.setTextSize(13); b.setSingleLine(true);
                b.setOnClickListener(v->navigate(name));
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),1); p.setMargins(dp(3),dp(2),dp(3),dp(2)); row.addView(b,p);
            }
            menuGrid.addView(row,new LinearLayout.LayoutParams(-1,dp(54)));
        }
        root.addView(menuGrid,new LinearLayout.LayoutParams(-1,dp(176)));

        ScrollView sc=new ScrollView(this); sc.setFillViewport(true);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(12),dp(12),dp(26)); sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); root.requestApplyInsets();
    }

    void navigate(String name){
        if(name.equals("Dashboard")) showDashboard(); else if(name.equals("Titoli")) showPositionsList("Tutti"); else if(name.equals("Proventi")) showIncome(); else if(name.equals("Rendimento")) showReturns();
        else if(name.equals("PAC")) showPac(); else if(name.equals("Storico")) showHistory(); else showSettings();
    }

    void heading(String main,String sub){ title.setText(main); subtitle.setText(sub); content.removeAllViews(); }
    void setPortfolio(String p){current=p; menuGrid.setVisibility(View.VISIBLE); subtitle.setText(p);}
    String brokerFilter(){return current.equals(TOTAL)?null:current;}

    LinearLayout card(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(12),dp(14),dp(12)); l.setBackgroundResource(R.drawable.card);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); l.setLayoutParams(p); return l;
    }
    TextView kpi(String label,String value){TextView v=tv(label+"\n"+value,18,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(12),dp(8),dp(12));v.setBackgroundResource(R.drawable.card);return v;}

    void showHome(){
        current="HOME"; menuGrid.setVisibility(View.GONE); java.util.List<String> ps=db.portfolioNames(true);
        heading("Portafoglio 2026","Stable Beta 3.4.21 • "+ps.size()+" portafogli attivi • Totale");
        double gross=db.sumIncomeActive("gross"), totalValue=db.latestPortfolioValueAllActive();
        int unseparatedCount=db.unseparatedPortfolioCountActive();
        Double titlesValue=unseparatedCount==0?db.latestInvestedValueAllActive():db.knownInvestedValueAllActive();
        Double cash=unseparatedCount==0?db.latestCashValueAllActive():db.knownCashValueAllActive();
        String titlesText=totalValue==0?"non inserito":(titlesValue==null?"non inserito":euro.format(titlesValue)+" €");
        String cashText=totalValue==0?"non inserita":(cash==null?"non inserita":euro.format(cash)+" €");

        LinearLayout row1=new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(kpi("Valore titoli",titlesText),new LinearLayout.LayoutParams(0,-2,1));
        row1.addView(kpi("Liquidità",cashText),new LinearLayout.LayoutParams(0,-2,1)); content.addView(row1);
        LinearLayout row2=new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(kpi("Patrimonio totale",totalValue==0?"non inserito":euro.format(totalValue)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        row2.addView(kpi("Proventi lordi da inizio anno",euro.format(gross)+" €"),new LinearLayout.LayoutParams(0,-2,1)); content.addView(row2);

        if(unseparatedCount>0){
            java.util.List<String> pending=new ArrayList<>();
            for(String b:ps) if(!db.isPortfolioFullySeparated(b) && db.latestPortfolioValue(b)!=0) pending.add(b);
            LinearLayout info=card(); info.addView(tv("Completa i dati del portafoglio",16,true));
            info.addView(tv("Da completare: "+android.text.TextUtils.join(", ",pending)+". Il Patrimonio totale comprende comunque tutti i portafogli. Valore titoli e Liquidità mostrano sempre gli importi già inseriti e restano visibili anche se un altro portafoglio è ancora incompleto.",13,false));
            content.addView(info);
        }

        Double ytd=calcYtdReturn(null);
        content.addView(kpi("Rendimento da inizio anno",ytd==null?"Non disponibile":pct.format(ytd)));

        LinearLayout annualHome=card(); annualHome.addView(tv("Storico risultati anni precedenti",17,true));
        Cursor ah=db.annualHistory(); int shown=0;
        while(ah.moveToNext() && shown<3){
            int yr=ah.getInt(ah.getColumnIndexOrThrow("year"));
            Double gi=getNullable(ah,"gross_income"), pp=getNullable(ah,"portfolio_profit"), rr=getNullable(ah,"return_rate");
            String line=String.valueOf(yr);
            if(gi!=null) line+=" • proventi "+euro.format(gi)+" €";
            if(pp!=null) line+=" • guadagno/perdita "+euro.format(pp)+" €";
            if(rr!=null) line+=" • "+pct.format(rr);
            annualHome.addView(tv(line,13,false)); shown++;
        }
        ah.close();
        if(shown==0) annualHome.addView(tv("Nessun anno precedente inserito.",13,false));
        content.addView(annualHome);

        LinearLayout primaryActions=card(); primaryActions.addView(tv("Azioni principali",18,true));
        Button globalSearch=btn("🔎 CERCA TITOLO"); globalSearch.setOnClickListener(v->{setPortfolio(TOTAL);showPositionsList("Tutti");}); primaryActions.addView(globalSearch);
        Button globalInsert=btn("＋ INSERISCI TITOLO"); globalInsert.setOnClickListener(v->choosePortfolioForPositionEntry()); primaryActions.addView(globalInsert);
        primaryActions.addView(tv("Cerca per nome, ISIN o ticker. Inserisci un nuovo titolo scegliendo subito il portafoglio di destinazione.",12,false));
        content.addView(primaryActions);

        LinearLayout choose=card(); choose.addView(tv("Scegli portafoglio",18,true));
        for(String name:ps){ Button b=btn(name.toUpperCase(Locale.ITALY)); b.setOnClickListener(v->{setPortfolio(name);showDashboard();}); choose.addView(b); }
        Button total=btn("TOTALE"); total.setOnClickListener(v->{setPortfolio(TOTAL);showDashboard();}); choose.addView(total);
        Button addPortfolio=btn("＋ AGGIUNGI PORTAFOGLIO"); addPortfolio.setOnClickListener(v->addPortfolioDialog()); choose.addView(addPortfolio);
        Button updatePortfolio=btn("AGGIORNA PATRIMONIO"); updatePortfolio.setOnClickListener(v->choosePortfolioForWealthUpdate()); choose.addView(updatePortfolio);
        Button statementImport=btn("IMPORTA ESTRATTO CONTO"); statementImport.setOnClickListener(v->showStatementImportCenter()); choose.addView(statementImport);
        Button generalSettings=btn("⚙ IMPOSTAZIONI GENERALI"); generalSettings.setOnClickListener(v->showGeneralSettings()); choose.addView(generalSettings);
        content.addView(choose);

        Button quick=btn("ALTRE OPERAZIONI RAPIDE"); quick.setOnClickListener(v->quickEntry()); content.addView(quick);
        LinearLayout disclaimerCard=card();
        disclaimerCard.addView(tv("Avvertenza",16,true));
        disclaimerCard.addView(tv("Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.",12,false));
        content.addView(disclaimerCard);

        LinearLayout info=card(); info.addView(tv("Stable Beta 3.4.21 – test privato",17,true));
        info.addView(tv("• Cerca titolo e Inserisci titolo sono ora le prime azioni visibili nella home\n• nuovo pulsante Cerca titolo dalla home e dentro ogni portafoglio\n• nei singoli portafogli la sezione Posizioni viene prima dei grafici, per ridurre lo scorrimento\n• pulsante Inserisci titolo più alto e leggibile sui display stretti\n• ricerca globale o per singolo portafoglio per nome, ISIN o ticker\n• pulsante Inserisci titolo direttamente dentro ogni portafoglio\n• categoria del titolo salvabile manualmente: Altro è riservato a BTP, BOT, obbligazioni e strumenti non contemplati\n• Poste Italiane IT0003796171 riconosciuta automaticamente come Azioni\n• elenco generale Titoli con filtri, ricerca e dettaglio rapido\n• sezione Proventi con Cedole, Dividendi, Distribuzioni, Interessi e Altri proventi\n• riclassificazione automatica dello storico Directa: Azioni/ETF = Dividendi, ETP = Distribuzioni, Certificati = Cedole\n• i vecchi importi cumulativi Directa sono marcati come Storico aggregato e la data è indicata come tecnica\n• elenco mese per mese e grafico interattivo: toccando il mese si apre il relativo dettaglio\n• categorie Azioni, ETF, ETP e Certificati cliccabili dal riepilogo proventi\n• vendita totale/parziale con P/L realizzato, commissioni e imposte\n• P/L non realizzato calcolato quando il PMC è completo\n• media mensile dei proventi calcolata sui mesi trascorsi dell’anno\n• gli importi netti o le imposte mancanti vengono segnalati come dati da completare\n• PAC Totale corretto sul piano mensile corrente e copertura mensile nascosta quando i netti sono incompleti/cumulativi\n• importazione estratto conto per singolo broker con anteprima, controllo duplicati SHA-256 e snapshot mensile\n• il nuovo estratto sostituisce il valore corrente del broker senza sommarlo al precedente e preserva PMC/commissioni già registrati\n• backup CSV V3.4.21 con verifica preventiva, ripristino transazionale e backup di sicurezza interno\n• nessun dato patrimoniale personale è precaricato nelle nuove installazioni\n• versione Beta per test privato: effettua periodicamente un backup",14,false)); content.addView(info);
    }

    void quickEntry(){
        final java.util.List<String> ps=db.portfolioNames(true); if(ps.isEmpty()){toast("Aggiungi prima un portafoglio");return;}
        final String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio").setItems(names,(d,which)->{
            String broker=names[which]; setPortfolio(broker);
            final String[] opts={"Provento","Aggiorna patrimonio","Rendimento mensile","PAC"};
            new AlertDialog.Builder(this).setTitle(broker+" – Altre operazioni rapide").setItems(opts,(d2,x)->{if(x==0)showIncome();else if(x==1)showWealthUpdateOptions(broker);else if(x==2)showReturns();else showPac();}).show();
        }).show();
    }

    void showDashboard(){
        if(current.equals("HOME")){showHome();return;} heading("Dashboard",current);
        String broker=brokerFilter();
        double gross=broker==null?db.sumIncomeActive("gross"):db.sumIncome(broker,"gross"), net=broker==null?db.sumIncomeActive("net"):db.sumIncome(broker,"net");
        int nmonths=ytdMonthsElapsed();
        double value=current.equals(TOTAL)?db.latestPortfolioValueAllActive():db.latestPortfolioValue(current);
        boolean totalView=current.equals(TOTAL);
        int unseparatedCount=totalView?db.unseparatedPortfolioCountActive():0;
        Double titlesValue=totalView?(unseparatedCount==0?db.latestInvestedValueAllActive():db.knownInvestedValueAllActive()):db.latestInvestedValue(current);
        Double cash=totalView?(unseparatedCount==0?db.latestCashValueAllActive():db.knownCashValueAllActive()):db.latestCashValue(current);
        String titlesText=value==0?"non inserito":(titlesValue==null?"non inserito":euro.format(titlesValue)+" €");
        String cashText=value==0?"non inserita":(cash==null?"non inserita":euro.format(cash)+" €");

        LinearLayout r1=new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(kpi("Valore titoli",titlesText),new LinearLayout.LayoutParams(0,-2,1));
        r1.addView(kpi("Liquidità",cashText),new LinearLayout.LayoutParams(0,-2,1)); content.addView(r1);
        LinearLayout r2=new LinearLayout(this); r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(kpi("Patrimonio totale",value==0?"non inserito":euro.format(value)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        r2.addView(kpi("Proventi lordi da inizio anno",euro.format(gross)+" €"),new LinearLayout.LayoutParams(0,-2,1)); content.addView(r2);

        if(totalView&&unseparatedCount>0){
            java.util.List<String> pending=new ArrayList<>();
            for(String b:db.portfolioNames(true)) if(!db.isPortfolioFullySeparated(b) && db.latestPortfolioValue(b)!=0) pending.add(b);
            LinearLayout info=card(); info.addView(tv("Completa i dati del portafoglio",16,true));
            info.addView(tv("Da completare: "+android.text.TextUtils.join(", ",pending)+". Il Patrimonio totale comprende comunque tutti i portafogli. Valore titoli e Liquidità mostrano gli importi già inseriti e saranno completi quando aggiungerai i dati mancanti.",13,false));
            content.addView(info);
        }

        LinearLayout r3=new LinearLayout(this); r3.setOrientation(LinearLayout.HORIZONTAL);
        boolean netIncomplete=broker==null?db.hasIncompleteNetActive():db.hasIncompleteNet(broker);
        r3.addView(kpi("Proventi netti",netIncomplete?"da completare":euro.format(net)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        r3.addView(kpi("Media mensile proventi",nmonths==0?"-":euro.format(gross/nmonths)+" €"),new LinearLayout.LayoutParams(0,-2,1)); content.addView(r3);

        double commissions=db.sumCosts(broker,"COMMISSIONE"),taxes=db.sumCosts(broker,"IMPOSTA"),realGross=db.sumRealized(broker,"realized_pl_gross"),realNet=db.sumRealized(broker,"realized_pl_net");Double unreal=unrealizedPl(broker);
        LinearLayout costsRow=new LinearLayout(this);costsRow.setOrientation(LinearLayout.HORIZONTAL);
        costsRow.addView(kpi("Commissioni pagate 2026",euro.format(commissions)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        costsRow.addView(kpi("Imposte pagate 2026",euro.format(taxes)+" €"),new LinearLayout.LayoutParams(0,-2,1));content.addView(costsRow);
        LinearLayout plRow=new LinearLayout(this);plRow.setOrientation(LinearLayout.HORIZONTAL);
        plRow.addView(kpi("P/L realizzato lordo",euro.format(realGross)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        plRow.addView(kpi("P/L realizzato netto",euro.format(realNet)+" €"),new LinearLayout.LayoutParams(0,-2,1));content.addView(plRow);
        content.addView(kpi("P/L non realizzato",unreal==null?"PMC incompleto":euro.format(unreal)+" €"));
        Double ytd=calcYtdReturn(broker); content.addView(kpi("Rendimento da inizio anno",ytd==null?"Non disponibile":pct.format(ytd)));

        int missingPmc=broker==null?db.missingPmcCountActive():db.missingPmcCount(broker);
        if(missingPmc>0 || netIncomplete || ytd==null){
            LinearLayout todo=card(); todo.addView(tv("Dati da completare",16,true));
            String msg="";
            if(missingPmc>0) msg+="• PMC mancanti: "+missingPmc+" posizione"+(missingPmc==1?"":"i")+"\n";
            if(netIncomplete) msg+="• Proventi netti/imposte: dati incompleti\n";
            if(ytd==null) msg+="• Rendimento YTD: servono snapshot/flussi mensili completi\n";
            todo.addView(tv(msg.trim(),13,false));
            if(missingPmc>0){Button complete=btn("Apri Titoli e completa PMC");complete.setOnClickListener(v->showPositionsList("Tutti"));todo.addView(complete);}
            content.addView(todo);
        }

        if(!current.equals(TOTAL)){
            int pcnt=db.positionCount(current);
            LinearLayout pos=card();pos.addView(tv("Posizioni",17,true));String sd=db.statusDate(current);
            double posValue=db.sumPositionsCurrentValue(current); Double cost=db.sumPositionsCostBasis(current);
            String details=pcnt+" strumenti"+(sd.isEmpty()?"":" • aggiornamento "+sd);
            if(pcnt>0)details+="\nValore attuale titoli: "+euro.format(posValue)+" €";
            if(cost!=null){double pl=posValue-cost;double pr=Math.abs(cost)<0.000001?0:pl/cost;details+="\nCapitale di carico: "+euro.format(cost)+" € • Guadagno/Perdita "+euro.format(pl)+" € ("+pct.format(pr)+")";}
            else if(pcnt>0)details+="\nCompleta il PMC delle posizioni per calcolare Guadagno/Perdita.";
            pos.addView(tv(details,13,false));
            LinearLayout titleActions=new LinearLayout(this);titleActions.setOrientation(LinearLayout.HORIZONTAL);
            Button searchTitle=btn("🔎 Cerca titolo");searchTitle.setTextSize(14);searchTitle.setOnClickListener(v->showPositionsList("Tutti"));
            Button insertTitle=btn("＋ Inserisci titolo");insertTitle.setTextSize(14);insertTitle.setOnClickListener(v->positionEditDialog(current,null,null,null,null,null,null,null));
            titleActions.addView(searchTitle,new LinearLayout.LayoutParams(0,dp(68),1));titleActions.addView(insertTitle,new LinearLayout.LayoutParams(0,dp(68),1));pos.addView(titleActions);
            Button importStmt=btn("Importa estratto conto • "+current);importStmt.setOnClickListener(v->startStatementImport(current));pos.addView(importStmt);
            Button view=btn("Aggiornamento manuale");view.setOnClickListener(v->showManualPortfolioEditor(current));pos.addView(view);content.addView(pos);
        }

        LinearLayout breakdown=card(); breakdown.addView(tv("Ripartizione proventi",17,true));
        for(String cat:categories)addBar(breakdown,cat,broker==null?db.sumCategoryActive(cat):db.sumCategory(broker,cat),gross); content.addView(breakdown);

        LinearLayout chart=card(); chart.addView(tv("Proventi mensili lordi",17,true)); chart.addView(tv("Tocca una barra per aprire i proventi del mese.",12,false)); chart.addView(new ChartView(this,monthlyIncome(broker),false,"€",m->showIncomeMonth(m)),new LinearLayout.LayoutParams(-1,dp(190))); content.addView(chart);
        LinearLayout pchart=card(); pchart.addView(tv("Patrimonio nel tempo",17,true)); pchart.addView(new ChartView(this,monthlyPortfolio(broker),true,"€"),new LinearLayout.LayoutParams(-1,dp(190))); content.addView(pchart);

        if(current.equals(TOTAL)){
            LinearLayout imports=card();imports.addView(tv("Importazioni estratti conto",17,true));imports.addView(tv("Carica l’estratto mensile di un singolo broker. Prima dell’aggiornamento viene mostrata un’anteprima; lo stesso file non può essere importato due volte.",13,false));Button impStmt=btn("Apri centro importazioni");impStmt.setOnClickListener(v->showStatementImportCenter());imports.addView(impStmt);content.addView(imports);
            LinearLayout split=card(); split.addView(tv("Confronto portafogli",17,true));
            for(String b:db.portfolioNames(true)) split.addView(tv(b+": "+euro.format(db.latestPortfolioValue(b))+" € | proventi "+euro.format(db.sumIncome(b,"gross"))+" €",14,false));
            content.addView(split);
        }
    }

    void addBar(LinearLayout parent,String label,double v,double total){
        double p=total==0?0:v/total;
        LinearLayout hit=new LinearLayout(this); hit.setOrientation(LinearLayout.VERTICAL); hit.setPadding(dp(2),dp(2),dp(2),dp(4));
        TextView line=tv(label+": "+euro.format(v)+" €  ("+pct.format(p)+")",14,false);
        hit.addView(line);
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(1000); bar.setProgress((int)Math.round(p*1000)); hit.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));
        hit.setClickable(true); hit.setFocusable(true); hit.setOnClickListener(vw->showPositionsList(label));
        parent.addView(hit,new LinearLayout.LayoutParams(-1,-2));
    }

    String positionCategory(String broker,String name,String isin){
        String stored=db.positionCategory(broker,isin);
        if(isMainPositionCategory(stored)) return stored;
        return inferPositionCategory(name,isin);
    }

    boolean isMainPositionCategory(String c){
        if(c==null)return false;
        for(String x:categories)if(x.equalsIgnoreCase(c.trim()))return true;
        return false;
    }

    boolean looksLikeOtherInstrument(String name){
        String n=(name==null?"":name).toUpperCase(Locale.ITALY);
        return n.contains("BTP")||n.contains("BOT")||n.contains("CCT")||n.contains("OBBLIG")||n.contains(" BOND")||n.contains("TREASURY")||n.contains("BUND")||n.contains("GOVERNMENT BOND")||n.contains("TITOLO DI STATO");
    }

    String inferPositionCategory(String name,String isin){
        String n=(name==null?"":name).toUpperCase(Locale.ITALY);
        String i=(isin==null?"":isin).toUpperCase(Locale.ITALY);
        if(looksLikeOtherInstrument(name)) return "Altro";
        if(n.startsWith("EFG EXP")||n.startsWith("LQ EXP")||n.startsWith("CIT EXP")||n.startsWith("MRX EXP")||n.startsWith("VON EXP")||n.contains("CERTIFICATE")||n.contains("CERTIFICATO")) return "Certificati";
        if(n.contains("INCOMESHARES")||n.contains(" ETP")||n.contains(" ETC")||n.contains("PHYSICAL GOLD")) return "ETP";
        if(n.contains("ETF")||n.contains("UCITS")||n.contains("ISHARES")||n.contains("VANECK")||n.contains("AMUNDI")||n.contains("SPDR")||n.contains("VANGUARD")||n.contains("FIDELITY")||n.contains("WISDOMTREE")||n.contains("REX TECH")||n.contains("EQUITY PREMIUM INCOME")||n.contains("WORLD EQUITY HIGH INCOME")||n.contains("REX CRYPTO")) return "ETF";
        if(i.equals("IT0005218380")||i.equals("IT0003128367")||i.equals("IT0000072618")||i.equals("IT0003856405")||i.equals("IT0005366767")||i.equals("IT0003796171")||i.equals("KYG651631007")||i.equals("US5494982029")||i.equals("US84615Q1031")||n.contains("POSTE ITALIANE")||n.contains("BANCO BPM")||n.equals("ENEL")||n.contains("INTESA SANPAOLO")||n.equals("LEONARDO")||n.equals("NEXI")) return "Azioni";
        return "Altro";
    }


    String knownTicker(String name,String isin){
        String n=(name==null?"":name).toUpperCase(Locale.ITALY),i=(isin==null?"":isin).toUpperCase(Locale.ITALY);
        if(i.equals("IT0003796171")||n.contains("POSTE ITALIANE"))return "PST";
        if(i.equals("IT0005218380")||n.contains("BANCO BPM"))return "BAMI";
        if(i.equals("IT0003128367")||n.equals("ENEL"))return "ENEL";
        if(i.equals("IT0000072618")||n.contains("INTESA SANPAOLO"))return "ISP";
        if(i.equals("IT0003856405")||n.equals("LEONARDO"))return "LDO";
        if(i.equals("IT0005366767")||n.equals("NEXI"))return "NEXI";
        if(i.equals("KYG651631007")||n.contains("JOBY AVIATION"))return "JOBY";
        if(i.equals("US5494982029")||n.contains("LUCID GROUP"))return "LCID";
        return "";
    }

    static class PositionRow {
        String broker,isin,ticker,name,cat,date; double qty,price,value; Double pmc; double pl;
        PositionRow(String b,String i,String t,String n,String c,double qu,Double pm,double pr,double va,String d){
            broker=b; isin=i; ticker=t==null?"":t; name=n; cat=c; qty=qu; pmc=pm; price=pr; value=va; date=d; pl=pm==null?0:va-qu*pm;
        }
    }

    void showPositionsList(String initialCategory){
        if(current.equals("HOME")){showHome();return;}
        heading("Titoli / Posizioni",current);
        final String[] category={initialCategory==null?"Tutti":initialCategory};
        final String[] state={"Aperte"};
        final String[] order={"Valore"};
        LinearLayout controls=card();
        controls.addView(tv(current.equals(TOTAL)?"Ricerca globale titoli":"Titoli • "+current,17,true));
        controls.addView(tv("Cerca immediatamente per nome, ISIN o ticker.",12,false));
        EditText search=textField("Nome, ISIN o ticker","");
        controls.addView(search);
        Button insert=btn("＋ Inserisci titolo");insert.setOnClickListener(v->{if(current.equals(TOTAL))choosePortfolioForPositionEntry();else positionEditDialog(current,null,null,null,null,null,null,null);});controls.addView(insert);
        LinearLayout cats1=new LinearLayout(this);cats1.setOrientation(LinearLayout.HORIZONTAL);
        for(String c:new String[]{"Tutti","Azioni","ETF"}){Button b=btn(c);b.setTextSize(12);b.setOnClickListener(v->{category[0]=c;showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});cats1.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));}
        controls.addView(cats1);
        LinearLayout cats2=new LinearLayout(this);cats2.setOrientation(LinearLayout.HORIZONTAL);
        for(String c:new String[]{"ETP","Certificati","Altro"}){Button b=btn(c);b.setTextSize(12);b.setOnClickListener(v->{category[0]=c;showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});cats2.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));}
        controls.addView(cats2);
        LinearLayout states=new LinearLayout(this);states.setOrientation(LinearLayout.HORIZONTAL);
        for(String st:new String[]{"Aperte","Chiuse"}){Button b=btn(st);b.setTextSize(12);b.setOnClickListener(v->{state[0]=st;showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});states.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));}
        controls.addView(states);
        LinearLayout sorts=new LinearLayout(this);sorts.setOrientation(LinearLayout.HORIZONTAL);
        for(String so:new String[]{"Valore","P/L","Nome"}){Button b=btn("Ordina "+so);b.setTextSize(11);b.setOnClickListener(v->{order[0]=so;showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});sorts.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));}
        controls.addView(sorts);
        content.addView(controls);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int b,int c){}
            public void onTextChanged(CharSequence x,int a,int b,int c){showPositionsListFiltered(category[0],state[0],order[0],x.toString());}
            public void afterTextChanged(Editable e){}
        });
        showPositionsListFiltered(category[0],state[0],order[0],"");
    }

    void showPositionsListFiltered(String category,String state,String order,String query){
        while(content.getChildCount()>1) content.removeViewAt(1);
        String q=(query==null?"":query.trim().toUpperCase(Locale.ITALY));
        ArrayList<PositionRow> rows=new ArrayList<>();
        if(state.equals("Aperte")){
            java.util.List<String> brokers=current.equals(TOTAL)?db.portfolioNames(true):java.util.Arrays.asList(current);
            for(String b:brokers){
                Cursor c=db.positions(b);
                while(c.moveToNext()){
                    String name=c.getString(c.getColumnIndexOrThrow("instrument")),isin=c.getString(c.getColumnIndexOrThrow("isin"));int ti=c.getColumnIndex("ticker");String ticker=ti>=0&&!c.isNull(ti)?c.getString(ti):"";if(ticker.isEmpty())ticker=knownTicker(name,isin);
                    String cat=positionCategory(b,name,isin);
                    if(!category.equals("Tutti")&&!cat.equals(category))continue;
                    if(!q.isEmpty()&&!name.toUpperCase(Locale.ITALY).contains(q)&&!isin.toUpperCase(Locale.ITALY).contains(q)&&!ticker.toUpperCase(Locale.ITALY).contains(q))continue;
                    double qty=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));
                    int pi=c.getColumnIndex("pmc");Double pmc=pi>=0&&!c.isNull(pi)?c.getDouble(pi):null;
                    String date=c.getString(c.getColumnIndexOrThrow("source_date"));
                    rows.add(new PositionRow(b,isin,ticker,name,cat,qty,pmc,pr,val,date));
                } c.close();
            }
        }else{
            Cursor c=db.closedSales(current.equals(TOTAL)?null:current);
            while(c.moveToNext()){
                String b=c.getString(c.getColumnIndexOrThrow("broker")),name=c.getString(c.getColumnIndexOrThrow("instrument")),isin=c.getString(c.getColumnIndexOrThrow("isin"));
                String cat=positionCategory(b,name,isin);
                if(!category.equals("Tutti")&&!cat.equals(category))continue;
                if(!q.isEmpty()&&!name.toUpperCase(Locale.ITALY).contains(q)&&!isin.toUpperCase(Locale.ITALY).contains(q))continue;
                double qty=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("gross_amount"));
                Double pmc=null;double cost=c.getDouble(c.getColumnIndexOrThrow("cost_basis"));if(qty>0)pmc=cost/qty;
                rows.add(new PositionRow(b,isin,"",name,cat,qty,pmc,pr,val,c.getString(c.getColumnIndexOrThrow("date"))));
            }c.close();
        }
        if(order.equals("Nome")) Collections.sort(rows,(a,b)->a.name.compareToIgnoreCase(b.name));
        else if(order.equals("P/L")) Collections.sort(rows,(a,b)->Double.compare(b.pl,a.pl));
        else Collections.sort(rows,(a,b)->Double.compare(b.value,a.value));
        LinearLayout header=card();header.addView(tv((category.equals("Tutti")?"Tutti i titoli":category)+" • "+state+" • "+rows.size()+" risultati",15,true));content.addView(header);
        if(rows.isEmpty()){LinearLayout empty=card();empty.addView(tv("Nessun titolo trovato con questi filtri.",13,false));content.addView(empty);return;}
        for(PositionRow r:rows){
            LinearLayout item=card();
            double income=db.sumIncomeForInstrument(r.broker,r.isin);
            String txt=r.name+"\n"+r.isin+(r.ticker.isEmpty()?"":" • Ticker "+r.ticker)+" • "+r.cat+(current.equals(TOTAL)?" • "+r.broker:"")+
                    "\nQuantità: "+trim(r.qty)+" • PMC: "+(r.pmc==null?"non inserito":trim(r.pmc))+" • Prezzo: "+trim(r.price)+
                    "\nValore: "+euro.format(r.value)+" €"+(r.pmc==null?"":" • P/L: "+euro.format(r.pl)+" €")+
                    "\nProventi 2026 attribuiti: "+euro.format(income)+" €";
            item.addView(tv(txt,13,true));
            if(state.equals("Aperte")){Button open=btn("Apri titolo");open.setOnClickListener(v->showPositionDetail(r.broker,r.isin));item.addView(open);}
            content.addView(item);
        }
    }

    void showPositionDetail(String broker,String isin){
        Cursor c=db.position(broker,isin);
        if(!c.moveToFirst()){c.close();toast("Posizione non trovata");return;}
        String name=c.getString(c.getColumnIndexOrThrow("instrument"));int ti=c.getColumnIndex("ticker");String ticker=ti>=0&&!c.isNull(ti)?c.getString(ti):"";if(ticker.isEmpty())ticker=knownTicker(name,isin);double qty=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));
        int pi=c.getColumnIndex("pmc");Double pmc=pi>=0&&!c.isNull(pi)?c.getDouble(pi):null;int bfi=c.getColumnIndex("buy_fee");double buyFee=bfi>=0&&!c.isNull(bfi)?c.getDouble(bfi):0;c.close();
        heading(name,broker);
        LinearLayout d=card();d.addView(tv("Categoria: "+positionCategory(broker,name,isin)+"\nISIN: "+isin+(ticker.isEmpty()?"":"\nTicker: "+ticker)+
                "\nQuantità: "+trim(qty)+"\nPMC: "+(pmc==null?"non inserito":trim(pmc))+"\nPrezzo attuale: "+trim(pr)+
                "\nValore attuale: "+euro.format(val)+" €"+(pmc==null?"":"\nP/L non realizzato: "+euro.format(val-qty*pmc)+" €")+
                "\nProventi 2026 attribuiti: "+euro.format(db.sumIncomeForInstrument(broker,isin))+" €",14,false));content.addView(d);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        final Double fpmc=pmc;final double fq=qty,fpr=pr,fbf=buyFee;final String fn=name,fi=isin,fb=broker;
        Button edit=btn("Modifica");edit.setOnClickListener(v->positionEditDialog(fb,fi,fn,fq,fpmc,fpr,fi,fbf));
        Button sell=btn("Vendi");sell.setOnClickListener(v->positionSaleDialog(fb,fi,fn,fq,fpmc,fpr,fbf));
        actions.addView(edit,new LinearLayout.LayoutParams(0,dp(50),1));actions.addView(sell,new LinearLayout.LayoutParams(0,dp(50),1));content.addView(actions);
        LinearLayout hist=card();hist.addView(tv("Storico vendite",16,true));Cursor sales=db.salesForIsin(broker,isin);int n=0;while(sales.moveToNext()){n++;hist.addView(tv(sales.getString(sales.getColumnIndexOrThrow("date"))+" • "+trim(sales.getDouble(sales.getColumnIndexOrThrow("quantity")))+" × "+trim(sales.getDouble(sales.getColumnIndexOrThrow("price")))+" • P/L netto "+euro.format(sales.getDouble(sales.getColumnIndexOrThrow("realized_pl_net")))+" €",12,false));}sales.close();if(n==0)hist.addView(tv("Nessuna vendita registrata.",12,false));content.addView(hist);
        Button back=btn("Torna ai titoli");back.setOnClickListener(v->{current=broker;showPositionsList("Tutti");});content.addView(back);
    }

    Double unrealizedPl(String broker){
        if(broker!=null){if(db.positionCount(broker)==0)return 0.0;Double cost=db.sumPositionsCostBasis(broker);return cost==null?null:db.sumPositionsCurrentValue(broker)-cost;}
        double total=0;for(String b:db.portfolioNames(true)){if(db.positionCount(b)==0)continue;Double cost=db.sumPositionsCostBasis(b);if(cost==null)return null;total+=db.sumPositionsCurrentValue(b)-cost;}return total;
    }

    double[] monthlyIncome(String broker){double[] a=new double[12];for(int m=1;m<=12;m++)a[m-1]=broker==null?db.sumIncomeMonthActive(m,"gross"):db.sumIncomeMonth(broker,m,"gross");return a;}
    double[] monthlyPortfolio(String broker){
        double[] a=new double[12];
        if(broker==null){for(String b:db.portfolioNames(true)){double[] x=monthlyPortfolio(b);for(int i=0;i<12;i++)a[i]+=x[i];}return a;}
        Cursor c=db.snapshots(broker);while(c.moveToNext()){int m=c.getInt(c.getColumnIndexOrThrow("month"));Double f=getNullable(c,"final_value");if(f!=null)a[m-1]=f;}c.close();return carryForward(a);
    }
    double[] carryForward(double[] a){double last=0;for(int i=0;i<a.length;i++){if(a[i]>0)last=a[i];else if(last>0)a[i]=last;}return a;}

    EditText field(String hint,Double val){
        EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setBackgroundResource(R.drawable.input_bg);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);if(val!=null)e.setText(trim(val));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;
    }
    EditText textField(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setBackgroundResource(R.drawable.input_bg);e.setText(val==null?"":val);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    void addLabeledField(LinearLayout box,String label,EditText field){
        TextView l=tv(label,11,true);l.setPadding(dp(4),dp(5),dp(4),0);box.addView(l);box.addView(field);
    }
    String trim(double d){if(Math.abs(d-Math.rint(d))<0.000001)return String.valueOf((long)Math.rint(d));return String.valueOf(d);}
    String currentDate(){Calendar c=Calendar.getInstance();return String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}
    Double num(EditText e){return parseUserNumber(e.getText().toString());}
    Double parseUserNumber(String raw){
        try{
            if(raw==null)return null;
            String s=raw.trim().replace("€","").replace("\u00A0","").replace(" ","");
            if(s.isEmpty())return null;
            int comma=s.lastIndexOf(','),dot=s.lastIndexOf('.');
            if(comma>=0&&dot>=0){
                if(comma>dot)s=s.replace(".","").replace(',', '.');
                else s=s.replace(",","");
            }else if(comma>=0){
                s=s.replace(',', '.');
            }
            return Double.parseDouble(s);
        }catch(Exception ex){return null;}
    }
    boolean invalidNumber(EditText e){String s=e.getText().toString().trim();return !s.isEmpty()&&parseUserNumber(s)==null;}
    double n(EditText e){Double x=num(e);return x==null?0:x;}
    Double getNullable(Cursor c,String col){int i=c.getColumnIndexOrThrow(col);return c.isNull(i)?null:c.getDouble(i);}

    Spinner spinner(String[] data,int selected){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,data);s.setAdapter(a);if(selected>=0&&selected<data.length)s.setSelection(selected);return s;}

    int ytdMonthsElapsed(){
        Calendar now=Calendar.getInstance();int year=now.get(Calendar.YEAR);
        if(year<2026)return 0;if(year>2026)return 12;return now.get(Calendar.MONTH)+1;
    }

    double scopeIncomeMonth(int month,String field){return current.equals(TOTAL)?db.sumIncomeMonthActive(month,field):db.sumIncomeMonth(current,month,field);}
    boolean scopeIncompleteNetMonth(int month){return current.equals(TOTAL)?db.hasIncompleteNetMonthActive(month):db.hasIncompleteNetMonth(current,month);}
    Cursor scopeIncomesForMonth(int month){return current.equals(TOTAL)?db.incomesForMonthActive(month):db.incomesForMonth(current,month);}
    boolean scopeHasCumulativeIncome(){if(current.equals(TOTAL)){for(String b:db.portfolioNames(true))if(db.hasAnyCumulativeIncome(b))return true;return false;}return db.hasAnyCumulativeIncome(current);}

    String incomeGroupLabel(String raw){
        String x=raw==null?"":raw.toLowerCase(Locale.ROOT);
        if(x.contains("cedol"))return "Cedole";
        if(x.contains("dividend"))return "Dividendi";
        if(x.contains("distrib"))return "Distribuzioni";
        if(x.contains("interess"))return "Interessi";
        return "Altri proventi";
    }

    boolean isHistoricalAggregateIncome(String broker,String instrument,String notes){
        String b=broker==null?"":broker.toLowerCase(Locale.ROOT);
        String i=instrument==null?"":instrument.toLowerCase(Locale.ROOT);
        String n=notes==null?"":notes.toLowerCase(Locale.ROOT);
        return b.contains("directa")&&(n.contains("storico aggregato directa")||n.contains("cumulat")||n.contains("aggregat")||i.matches("proventi .* 2026"));
    }

    String historicalIncomeTag(String broker,String instrument,String notes){
        return isHistoricalAggregateIncome(broker,instrument,notes)?" • Storico aggregato":"";
    }

    String incomeAmountLine(double gross,double net,String mode,String notes){
        String low=notes==null?"":notes.toLowerCase(Locale.ROOT);
        boolean incomplete=!"NETTO".equalsIgnoreCase(mode)&&low.contains("da completare")&&(low.contains("netto")||low.contains("imposte"));
        if("NETTO".equalsIgnoreCase(mode))return euro.format(net)+" € già netto";
        if(incomplete)return euro.format(gross)+" € lordo | netto da completare";
        return euro.format(gross)+" € lordo | "+euro.format(net)+" € netto";
    }

    void showIncome(){
        heading("Proventi",current);
        int curMonth=Math.max(1,Math.min(12,Calendar.getInstance().get(Calendar.MONTH)+1));
        double yGross=current.equals(TOTAL)?db.sumIncomeActive("gross"):db.sumIncome(current,"gross");
        double yNet=current.equals(TOTAL)?db.sumIncomeActive("net"):db.sumIncome(current,"net");
        boolean yIncomplete=current.equals(TOTAL)?db.hasIncompleteNetActive():db.hasIncompleteNet(current);

        LinearLayout currentCard=card();currentCard.addView(tv("Proventi di "+months[curMonth-1],18,true));
        double mg=scopeIncomeMonth(curMonth,"gross"),mn=scopeIncomeMonth(curMonth,"net");boolean monthIncomplete=scopeIncompleteNetMonth(curMonth);
        currentCard.addView(tv("Totale mese: "+euro.format(mg)+" €"+(monthIncomplete?" lordi • netto da completare":" • netto "+euro.format(mn)+" €")+"\nTotale 2026: "+euro.format(yGross)+" € lordi"+(yIncomplete?" • netto da completare":" • "+euro.format(yNet)+" € netti"),14,true));
        Button openCurrent=btn("Apri dettaglio di "+months[curMonth-1]);openCurrent.setOnClickListener(v->showIncomeMonth(curMonth));currentCard.addView(openCurrent);content.addView(currentCard);

        LinearLayout chart=card();chart.addView(tv("Proventi mese per mese",17,true));chart.addView(tv("Tocca una barra per aprire direttamente i proventi di quel mese.",12,false));
        chart.addView(new ChartView(this,monthlyIncome(brokerFilter()),false,"€",m->showIncomeMonth(m)),new LinearLayout.LayoutParams(-1,dp(190)));content.addView(chart);

        if(scopeHasCumulativeIncome()){
            LinearLayout warning=card();warning.addView(tv("Nota sui dati mensili",15,true));warning.addView(tv("Alcuni proventi Directa recuperati dallo storico sono importi cumulativi/aggregati. Sono mostrati nel mese tecnico di registrazione e non rappresentano necessariamente la vera data di accredito. Nel dettaglio sono marcati come “Storico aggregato”; con futuri estratti movimenti saranno sostituiti progressivamente da date e classificazioni reali.",12,false));content.addView(warning);
        }

        LinearLayout monthsCard=card();monthsCard.addView(tv("Elenco proventi 2026 – mese per mese",17,true));
        for(int m=1;m<=12;m++){
            final int month=m;double g=scopeIncomeMonth(m,"gross"),ne=scopeIncomeMonth(m,"net");boolean inc=scopeIncompleteNetMonth(m);Cursor mc=scopeIncomesForMonth(m);int cnt=mc.getCount();mc.close();
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(3),0,dp(3));
            String netText=inc?"netto da completare":euro.format(ne)+" € netto";
            TextView label=tv(months[m-1]+"\n"+euro.format(g)+" € lordi • "+netText+" • "+cnt+" movimenti",13,m==curMonth);label.setOnClickListener(v->showIncomeMonth(month));
            Button open=btn("Apri");open.setOnClickListener(v->showIncomeMonth(month));
            row.addView(label,new LinearLayout.LayoutParams(0,-2,1));row.addView(open,new LinearLayout.LayoutParams(dp(78),dp(48)));monthsCard.addView(row);
        }
        content.addView(monthsCard);

        java.util.List<String> pnames=db.portfolioNames(true); String defaultBroker=current.equals(TOTAL)?(pnames.isEmpty()?DbHelper.DIRECTA:pnames.get(0)):current;
        LinearLayout form=card(); form.addView(tv("＋ Nuovo provento",17,true));
        form.addView(tv("Classificazione: Cedola = certificati; Dividendo = azioni/ETF; Distribuzione = ETP o altri strumenti income; Interesse = liquidità; Altro provento = casi residui.",12,false));
        if(!current.equals(TOTAL)){String profile=db.getBrokerProfile(current);form.addView(tv("Profilo broker: "+profile+("Trade Republic".equals(profile)?" • Round up e Saveback si registrano in Storico > Movimenti.":""),12,false));}
        String[] brokerNames=pnames.toArray(new String[0]); int defIdx=Math.max(0,pnames.indexOf(defaultBroker)); Spinner brokerSp=spinner(brokerNames,defIdx); if(current.equals(TOTAL))form.addView(brokerSp);
        Spinner monthSp=spinner(months,curMonth-1); form.addView(monthSp);
        EditText date=textField("Data (YYYY-MM-DD)","2026-"+String.format(Locale.US,"%02d",monthSp.getSelectedItemPosition()+1)+"-01"); form.addView(date);
        form.addView(tv("Categoria del provento",12,true)); Spinner cat=spinner(incomeCategories,0); form.addView(cat); form.addView(tv("Tipo di provento",12,true)); Spinner typ=spinner(incomeTypes,0); form.addView(typ);
        EditText instrument=textField("Strumento / nome",""); form.addView(instrument); EditText isin=textField("ISIN (facoltativo)",""); form.addView(isin);
        Spinner amountMode=spinner(new String[]{"Importo lordo","Importo già netto"},0);form.addView(tv("Tipo importo",12,true));form.addView(amountMode);
        EditText gross=field("Importo €",null); form.addView(gross); EditText tax=field("Aliquota % (solo se lordo)",db.getTaxRate()*100); form.addView(tax); EditText notes=textField("Note",""); form.addView(notes);
        TextView netPreview=tv("Netto calcolato: -",15,true); form.addView(netPreview);
        Runnable preview=()->{Double g=num(gross),t=num(tax);boolean alreadyNet=amountMode.getSelectedItemPosition()==1;if(g==null)netPreview.setText("Netto calcolato: -");else if(alreadyNet)netPreview.setText("Importo già netto: "+euro.format(g)+" € • nessuna seconda tassazione");else netPreview.setText("Netto calcolato: "+euro.format(g*(1-(t==null?26:t)/100.0))+" €");};
        amountMode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){tax.setEnabled(pos==0);preview.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        Button calc=btn("Calcola netto"); calc.setOnClickListener(v->preview.run()); form.addView(calc);
        Button save=btn("Salva provento"); save.setOnClickListener(v->{
            Double g=num(gross);if(g==null){toast("Inserisci l'importo");return;}String selectedType=typ.getSelectedItem().toString();String selectedCategory=cat.getSelectedItem().toString();
            if("Cedola".equals(selectedType)&&!"Certificati".equals(selectedCategory)){toast("La voce Cedola è riservata ai Certificati. Per gli altri strumenti usa Dividendo, Distribuzione o Interesse.");return;}
            int m=monthSp.getSelectedItemPosition()+1;boolean alreadyNet=amountMode.getSelectedItemPosition()==1;double tr=alreadyNet?0:(num(tax)==null?26:num(tax))/100.0;String b=current.equals(TOTAL)?brokerSp.getSelectedItem().toString():current;
            db.addIncome(date.getText().toString().trim(),m,b,selectedCategory,instrument.getText().toString(),isin.getText().toString(),selectedType,g,tr,notes.getText().toString(),alreadyNet?"NETTO":"LORDO");toast("Provento salvato");showIncomeMonth(m);
        }); form.addView(save); content.addView(form);

        LinearLayout list=card(); list.addView(tv("Ultimi proventi",17,true)); Cursor c=brokerFilter()==null?db.incomesActive():db.incomes(brokerFilter());int count=0;
        while(c.moveToNext()&&count<12){
            long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),inst=c.getString(c.getColumnIndexOrThrow("instrument")),ca=c.getString(c.getColumnIndexOrThrow("category")),rawType=c.getString(c.getColumnIndexOrThrow("income_type")),isinVal=c.getString(c.getColumnIndexOrThrow("isin"));double g=c.getDouble(c.getColumnIndexOrThrow("gross")),ne=c.getDouble(c.getColumnIndexOrThrow("net")),tr=c.getDouble(c.getColumnIndexOrThrow("tax_rate"));int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";int noteIdx=c.getColumnIndex("notes");String incomeNotes=noteIdx>=0&&!c.isNull(noteIdx)?c.getString(noteIdx):"";
            LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);TextView tx=tv(dt+" • "+b+historicalIncomeTag(b,inst,incomeNotes)+"\n"+incomeGroupLabel(rawType)+" • "+ca+" • "+inst+"\n"+incomeAmountLine(g,ne,mode,incomeNotes),13,false);tx.setOnClickListener(v->showIncomeRecordDetail(dt,b,ca,rawType,inst,isinVal,g,ne,tr,mode,incomeNotes));rr.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo provento?").setPositiveButton("Elimina",(dd,w)->{db.deleteIncome(id);showIncome();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));list.addView(rr);count++;
        }c.close(); if(count==0)list.addView(tv("Nessun provento inserito.",14,false));content.addView(list);
    }

    void showIncomeMonth(int month){
        if(month<1||month>12){showIncome();return;}heading("Proventi • "+months[month-1],current);
        Button back=btn("← Tutti i mesi");back.setOnClickListener(v->showIncome());content.addView(back);
        double gross=scopeIncomeMonth(month,"gross"),net=scopeIncomeMonth(month,"net");boolean incomplete=scopeIncompleteNetMonth(month);Cursor countCursor=scopeIncomesForMonth(month);int count=countCursor.getCount();countCursor.close();
        LinearLayout summary=card();summary.addView(tv(months[month-1]+" 2026",18,true));summary.addView(tv("Proventi registrati: "+euro.format(gross)+" € lordi\n"+(incomplete?"Proventi netti: da completare":"Proventi netti: "+euro.format(net)+" €")+"\nMovimenti: "+count,14,true));content.addView(summary);

        LinkedHashMap<String,Double> groups=new LinkedHashMap<>();groups.put("Cedole",0.0);groups.put("Dividendi",0.0);groups.put("Distribuzioni",0.0);groups.put("Interessi",0.0);groups.put("Altri proventi",0.0);
        LinkedHashMap<String,Double> brokers=new LinkedHashMap<>();Cursor agg=scopeIncomesForMonth(month);while(agg.moveToNext()){String t=incomeGroupLabel(agg.getString(agg.getColumnIndexOrThrow("income_type"))),b=agg.getString(agg.getColumnIndexOrThrow("broker"));double g=agg.getDouble(agg.getColumnIndexOrThrow("gross"));groups.put(t,groups.get(t)+g);brokers.put(b,brokers.containsKey(b)?brokers.get(b)+g:g);}agg.close();
        LinearLayout breakdown=card();breakdown.addView(tv("Composizione del mese",17,true));for(Map.Entry<String,Double> e:groups.entrySet())if(e.getValue()!=0)breakdown.addView(tv(e.getKey()+": "+euro.format(e.getValue())+" €",13,false));if(count==0)breakdown.addView(tv("Nessun provento registrato in questo mese.",13,false));if(current.equals(TOTAL)&&!brokers.isEmpty()){breakdown.addView(tv("Per portafoglio",14,true));for(Map.Entry<String,Double> e:brokers.entrySet())breakdown.addView(tv(e.getKey()+": "+euro.format(e.getValue())+" €",13,false));}content.addView(breakdown);

        LinearLayout list=card();list.addView(tv("Movimenti di "+months[month-1],17,true));Cursor c=scopeIncomesForMonth(month);int n=0;while(c.moveToNext()){
            long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),inst=c.getString(c.getColumnIndexOrThrow("instrument")),ca=c.getString(c.getColumnIndexOrThrow("category")),rawType=c.getString(c.getColumnIndexOrThrow("income_type")),isinVal=c.getString(c.getColumnIndexOrThrow("isin"));double g=c.getDouble(c.getColumnIndexOrThrow("gross")),ne=c.getDouble(c.getColumnIndexOrThrow("net")),tr=c.getDouble(c.getColumnIndexOrThrow("tax_rate"));int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";int noteIdx=c.getColumnIndex("notes");String notes=noteIdx>=0&&!c.isNull(noteIdx)?c.getString(noteIdx):"";
            LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);TextView tx=tv(dt+" • "+b+historicalIncomeTag(b,inst,notes)+"\n"+incomeGroupLabel(rawType)+" • "+inst+"\n"+incomeAmountLine(g,ne,mode,notes),13,false);tx.setOnClickListener(v->showIncomeRecordDetail(dt,b,ca,rawType,inst,isinVal,g,ne,tr,mode,notes));rr.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo provento?").setPositiveButton("Elimina",(dd,w)->{db.deleteIncome(id);showIncomeMonth(month);}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));list.addView(rr);n++;
        }c.close();if(n==0)list.addView(tv("Nessun movimento nel mese.",13,false));content.addView(list);
    }

    void showIncomeRecordDetail(String date,String broker,String category,String rawType,String instrument,String isin,double gross,double net,double taxRate,String mode,String notes){
        StringBuilder msg=new StringBuilder();boolean historical=isHistoricalAggregateIncome(broker,instrument,notes);msg.append(historical?"Data tecnica: ":"Data: ").append(date).append("\nPortafoglio: ").append(broker);if(historical)msg.append("\nOrigine: Storico aggregato Directa\nNota data: non necessariamente la data effettiva di accredito");msg.append("\nTipo: ").append(incomeGroupLabel(rawType));if(rawType!=null&&!rawType.isEmpty()&&!incomeGroupLabel(rawType).equals(rawType))msg.append(" (").append(rawType).append(")");msg.append("\nCategoria: ").append(category);if(instrument!=null&&!instrument.isEmpty())msg.append("\nStrumento: ").append(instrument);if(isin!=null&&!isin.isEmpty())msg.append("\nISIN: ").append(isin);msg.append("\n\n").append(incomeAmountLine(gross,net,mode,notes));if(!"NETTO".equalsIgnoreCase(mode))msg.append("\nAliquota registrata: ").append(String.format(Locale.ITALY,"%.2f%%",taxRate*100));if(notes!=null&&!notes.trim().isEmpty())msg.append("\n\nNote: ").append(notes);
        new AlertDialog.Builder(this).setTitle("Dettaglio provento").setMessage(msg.toString()).setPositiveButton("Chiudi",null).show();
    }

    void showReturns(){
        heading("Rendimento",current);
        if(current.equals(TOTAL)){
            LinearLayout info=card();info.addView(tv("Totale aggregato",17,true));
            info.addView(tv("Il rendimento da inizio anno viene calcolato automaticamente usando i mesi salvati dei portafogli attivi. Per modificare i dati scegli il singolo portafoglio. Versamenti e prelievi esterni sono separati dai movimenti interni.",14,false));content.addView(info);
            showReturnSummary(null);return;
        }
        Spinner sp=spinner(months,Calendar.getInstance().get(Calendar.MONTH));content.addView(sp);LinearLayout form=card();content.addView(form);
        Runnable load=()->{
            form.removeAllViews();int m=sp.getSelectedItemPosition()+1;
            Double ini=null,fin=null,dep=null,wd=null,iniInv=null,iniCash=null,finInv=null,finCash=null;String notes="";
            Cursor c=db.snapshot(current,m);if(c.moveToFirst()){ini=getNullable(c,"initial_value");fin=getNullable(c,"final_value");dep=getNullable(c,"deposits");wd=getNullable(c,"withdrawals");iniInv=getNullable(c,"initial_invested");iniCash=getNullable(c,"initial_cash");finInv=getNullable(c,"final_invested");finCash=getNullable(c,"final_cash");int i=c.getColumnIndexOrThrow("notes");notes=c.isNull(i)?"":c.getString(i);}c.close();
            final Double oldIni=ini,oldFin=fin;
            double grossM=db.sumIncomeMonth(current,m,"gross"), netM=db.sumIncomeMonth(current,m,"net");
            form.addView(tv(months[m-1]+" – "+current,17,true));
            form.addView(tv("Proventi del mese registrati: "+euro.format(grossM)+" € lordi | "+euro.format(netM)+" € netti\nValore titoli + Liquidità = Patrimonio totale. I proventi sono informativi: se sono già compresi nel patrimonio finale non vanno sommati di nuovo e non sono versamenti esterni.",14,true));
            if((oldIni!=null&&iniInv==null&&iniCash==null)||(oldFin!=null&&finInv==null&&finCash==null))
                form.addView(tv("Questo mese contiene un vecchio patrimonio totale. Se vuoi distinguere titoli e liquidità, completa i campi qui sotto; lo storico non viene cancellato.",12,false));
            EditText fIniInv=field("Valore titoli INIZIALE €",iniInv),fIniCash=field("Liquidità INIZIALE €",iniCash),fFinInv=field("Valore titoli FINALE €",finInv),fFinCash=field("Liquidità FINALE €",finCash),fDep=field("Versamenti ESTERNI €",dep),fWd=field("Prelievi ESTERNI €",wd),fNotes=textField("Note",notes);
            form.addView(fIniInv);form.addView(fIniCash);form.addView(fFinInv);form.addView(fFinCash);form.addView(fDep);form.addView(fWd);form.addView(fNotes);
            TextView out=tv("",15,true);Button save=btn("Calcola e salva");save.setOnClickListener(v->{
                Double iInv=num(fIniInv),iCash=num(fIniCash),fInv=num(fFinInv),fCash=num(fFinCash);
                Double iniTotal=sumParts(iInv,iCash),finTotal=sumParts(fInv,fCash);
                if(iniTotal==null||finTotal==null){toast("Inserisci Valore titoli e/o Liquidità sia iniziali sia finali");return;}
                db.saveSnapshotSplit(current,m,iInv,iCash,fInv,fCash,num(fDep),num(fWd),fNotes.getText().toString());
                Double rr=calcReturnValues(iniTotal,finTotal,num(fDep),num(fWd));
                out.setText("Patrimonio iniziale: "+euro.format(iniTotal)+" €\nPatrimonio finale: "+euro.format(finTotal)+" €\nRendimento del mese: "+(rr==null?"Non disponibile":pct.format(rr))+"\nProventi lordi mese: "+euro.format(grossM)+" €\nProventi netti mese: "+euro.format(netM)+" €");toast("Patrimonio e rendimento salvati");
            });form.addView(save);form.addView(out);
            LinearLayout explain=card();explain.addView(tv("Come viene calcolato",16,true));
            explain.addView(tv("Patrimonio totale = Valore titoli + Liquidità. Acquistare o vendere titoli usando denaro già presente nel broker è un movimento interno e non crea rendimento. Nei Versamenti/Prelievi esterni inserisci solo denaro che entra o esce realmente dal broker. Dividendi e cedole restano parte del risultato del portafoglio e non vanno registrati come versamenti esterni. Se un PAC è finanziato con denaro nuovo proveniente dall’esterno, registra quel denaro come Versamento esterno; se usa liquidità già presente nel broker, è un movimento interno. Formula mensile: Modified Dietz semplificato.",13,false));form.addView(explain);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){load.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        showReturnSummary(current);
    }

    void showReturnSummary(String broker){
        LinearLayout x=card();x.addView(tv("Andamento rendimento mensile",17,true));
        x.addView(new ChartView(this,monthlyReturns(broker),false,"%"),new LinearLayout.LayoutParams(-1,dp(190)));
        Double ytd=calcYtdReturn(broker);
        x.addView(tv("Rendimento da inizio anno: "+(ytd==null?"Non disponibile":pct.format(ytd)),15,true));
        if(ytd==null) x.addView(tv("Per calcolarlo automaticamente inserisci almeno un mese con patrimonio iniziale, patrimonio finale ed eventuali versamenti/prelievi esterni.",12,false));
        content.addView(x);
    }

    Double sumParts(Double invested,Double cash){if(invested==null&&cash==null)return null;return (invested==null?0:invested)+(cash==null?0:cash);}
    Double calcReturnValues(Double ini,Double fin,Double dep,Double wd){if(ini==null||fin==null)return null;double flow=(dep==null?0:dep)-(wd==null?0:wd);double denom=ini+0.5*flow;if(Math.abs(denom)<0.000001)return null;return (fin-ini-flow)/denom;}
    Double calcMonthlyReturn(String broker,int month){
        if(broker==null){double ini=0,fin=0,dep=0,wd=0;boolean any=false;for(String b:db.portfolioNames(true)){Double[] x=snapshotValues(b,month);boolean has=x[0]!=null&&x[1]!=null;if(has){any=true;ini+=x[0];fin+=x[1];dep+=x[2]==null?0:x[2];wd+=x[3]==null?0:x[3];}}return any?calcReturnValues(ini,fin,dep,wd):null;}
        Double[] x=snapshotValues(broker,month);return calcReturnValues(x[0],x[1],x[2],x[3]);
    }
    Double[] snapshotValues(String broker,int month){Double[] a={null,null,null,null};Cursor c=db.snapshot(broker,month);if(c.moveToFirst()){a[0]=getNullable(c,"initial_value");a[1]=getNullable(c,"final_value");a[2]=getNullable(c,"deposits");a[3]=getNullable(c,"withdrawals");}c.close();return a;}
    double[] monthlyReturns(String broker){double[] a=new double[12];for(int m=1;m<=12;m++){Double r=calcMonthlyReturn(broker,m);a[m-1]=r==null?Double.NaN:r*100;}return a;}
    Double calcYtdReturn(String broker){
        double currentValue=broker==null?db.latestPortfolioValueAllActive():db.latestPortfolioValue(broker);
        if(currentValue<=0)return null;
        double prod=1;boolean any=false;
        for(int m=1;m<=12;m++){Double r=calcMonthlyReturn(broker,m);if(r!=null){prod*=1+r;any=true;}}
        return any?prod-1:null;
    }

    void showPac(){
        heading("PAC",current);
        if(current.equals(TOTAL)){showPacTotal();return;}
        Spinner sp=spinner(months,Calendar.getInstance().get(Calendar.MONTH));content.addView(sp);LinearLayout form=card();content.addView(form);
        Runnable load=()->{
            form.removeAllViews();int m=sp.getSelectedItemPosition()+1;Double planned=null,ext=null,in=null;String notes="";Cursor c=db.pac(current,m);if(c.moveToFirst()){planned=getNullable(c,"planned");ext=getNullable(c,"external_actual");in=getNullable(c,"internal_actual");int ni=c.getColumnIndexOrThrow("notes");notes=c.isNull(ni)?"":c.getString(ni);}c.close();if(planned==null)planned=db.getPacDefault(current);
            boolean netIncomplete=db.hasIncompleteNetMonth(current,m)||db.hasCumulativeIncomeCoveringMonth(current,m);
            double netIncome=db.sumIncomeMonth(current,m,"net");
            double grossIncome=db.sumIncomeMonth(current,m,"gross");
            double suggestedInternal=netIncomplete?0:Math.min(netIncome,planned),suggestedExternal=netIncomplete?planned:Math.max(planned-suggestedInternal,0);
            form.addView(tv(months[m-1]+" – "+current,17,true));
            form.addView(tv(netIncomplete
                    ?"Proventi netti del mese: da completare • Lordi registrati: "+euro.format(grossIncome)+" €"
                    :"Proventi netti del mese: "+euro.format(netIncome)+" €",14,true));
            if(db.hasCumulativeIncomeCoveringMonth(current,m))
                form.addView(tv("Questo mese è coperto da proventi cumulativi/aggregati: la copertura netta mensile non viene stimata finché manca il dettaglio mensile.",12,false));
            EditText fPlan=field("PAC programmato €",planned),fExt=field("Capitale esterno effettivo €",ext),fIn=field("Proventi/reinvestimento interno €",in),fNotes=textField("Note",notes);form.addView(fPlan);form.addView(fExt);form.addView(fIn);form.addView(fNotes);
            Button suggest=btn("Usa copertura suggerita");
            suggest.setEnabled(!netIncomplete);
            suggest.setOnClickListener(v->{fIn.setText(trim(suggestedInternal));fExt.setText(trim(suggestedExternal));});
            form.addView(suggest);

            Button allInternal=btn("PAC tutto da liquidità interna");
            allInternal.setOnClickListener(v->{double p=n(fPlan);fExt.setText("0");fIn.setText(trim(p));});
            form.addView(allInternal);

            form.addView(tv(netIncomplete
                    ?"Copertura suggerita disattivata: il netto mensile non è completo. Puoi comunque registrare manualmente capitale esterno e finanziamento interno se li conosci."
                    :"Copertura suggerita = usa prima i proventi netti del mese e considera esterno il resto.\nPAC tutto da liquidità interna = 0 € esterno e 100% finanziato con liquidità/proventi già presenti nel broker.",12,false));

            TextView out=tv("",15,true);
            Button save=btn("Salva PAC");
            save.setOnClickListener(v->{
                double p=n(fPlan),e=n(fExt),ii=n(fIn);
                Runnable doSave=()->{
                    db.savePac(current,m,num(fPlan),num(fExt),num(fIn),fNotes.getText().toString());
                    double covInternal=p==0?0:ii/p;
                    double covExternal=p==0?0:e/p;
                    String coverage=netIncomplete?"Copertura da proventi del mese: da completare":"Copertura da proventi del mese: "+pct.format(p==0?0:netIncome/p);
                    String surplus=netIncomplete?"Surplus proventi del mese dopo PAC: da completare":"Surplus proventi del mese dopo PAC: "+euro.format(Math.max(netIncome-p,0))+" €";
                    out.setText(coverage
                            +"\nFinanziamento interno registrato: "+pct.format(covInternal)
                            +"\nCapitale esterno registrato: "+pct.format(covExternal)
                            +"\n"+surplus);
                    toast("PAC salvato");
                };
                double diff=Math.abs((e+ii)-p);
                if(p>0 && diff>0.01){
                    new AlertDialog.Builder(this)
                            .setTitle("Controlla composizione PAC")
                            .setMessage("Capitale esterno + finanziamento interno = "+euro.format(e+ii)+" €, mentre il PAC programmato è "+euro.format(p)+" €.\n\nDifferenza: "+euro.format(diff)+" €. Vuoi salvare comunque?")
                            .setPositiveButton("Salva comunque",(d,w)->doSave.run())
                            .setNegativeButton("Correggi",null)
                            .show();
                }else doSave.run();
            });
            form.addView(save);form.addView(out);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){load.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        showPacYear(current);
    }

    void showPacYear(String broker){
        LinearLayout c=card();c.addView(tv("Copertura PAC anno",17,true));double planned=0,ext=0,in=0;Cursor p=db.pacs(broker);while(p.moveToNext()){Double x=getNullable(p,"planned"),e=getNullable(p,"external_actual"),ii=getNullable(p,"internal_actual");if(x!=null)planned+=x;if(e!=null)ext+=e;if(ii!=null)in+=ii;}p.close();double net=db.sumIncome(broker,"net");boolean incomplete=db.hasIncompleteNet(broker)||db.hasAnyCumulativeIncome(broker);
        String netLine=incomplete?"da completare":euro.format(net)+" €";
        String covLine=incomplete?"da completare":pct.format(planned==0?0:net/planned);
        c.addView(tv("PAC programmato nei mesi registrati: "+euro.format(planned)+" €\nProventi netti da inizio anno: "+netLine+"\nCapitale esterno registrato: "+euro.format(ext)+" €\nReinvestimento interno registrato: "+euro.format(in)+" €\nCopertura teorica: "+covLine,14,false));
        if(db.hasAnyCumulativeIncome(broker))c.addView(tv("Sono presenti proventi cumulativi/aggregati: la copertura annuale netta resta da completare finché non vengono separati per periodo e netto effettivo.",12,false));
        content.addView(c);
    }

    void showPacTotal(){
        int currentMonth=Calendar.getInstance().get(Calendar.MONTH)+1;
        LinearLayout c=card();c.addView(tv("PAC mensile complessivo",17,true));double totalPlan=0,totalExt=0;StringBuilder lines=new StringBuilder();for(String b:db.portfolioNames(true)){double p=getPacMonth(b,currentMonth),e=sumPacField(b,"external_actual");totalPlan+=p;totalExt+=e;lines.append(b).append(" programmato ").append(months[currentMonth-1].toLowerCase(Locale.ITALY)).append(": ").append(euro.format(p)).append(" €\n");}
        lines.append("PAC mensile totale: ").append(euro.format(totalPlan)).append(" €\n");
        lines.append("Capitale esterno registrato da inizio anno: ").append(euro.format(totalExt)).append(" €");
        c.addView(tv(lines.toString(),14,false));
        c.addView(tv("Il PAC mensile mostra il piano del mese corrente, non la somma dei mesi precedenti. Reinvestimenti e PAC finanziati da cedole/dividendi restano flussi interni e non sono nuovo capitale esterno.",13,true));content.addView(c);

        LinearLayout chart=card();chart.addView(tv("Copertura netta mensile del PAC",17,true));
        chart.addView(tv("Vengono mostrati solo i mesi in cui il netto è completo e i proventi non sono registrati come totale cumulativo. I mesi non determinabili restano vuoti.",12,false));
        double[] v=new double[12];java.util.Arrays.fill(v,Double.NaN);
        for(int m=1;m<=currentMonth;m++){
            double plan=0;for(String b:db.portfolioNames(true))plan+=getPacMonth(b,m);
            boolean unavailable=db.hasIncompleteNetMonthActive(m)||db.hasCumulativeIncomeCoveringMonthActive(m);
            if(!unavailable && plan>0){double net=db.sumIncomeMonthActive(m,"net");v[m-1]=100*net/plan;}
        }
        chart.addView(new ChartView(this,v,false,"%"),new LinearLayout.LayoutParams(-1,dp(190)));content.addView(chart);
    }
    double sumPacField(String broker,String field){Cursor c=db.pacs(broker);double x=0;while(c.moveToNext()){Double v=getNullable(c,field);if(v!=null)x+=v;}c.close();return x;}
    double getPacMonth(String broker,int month){Cursor c=db.pac(broker,month);double x=db.getPacDefault(broker);if(c.moveToFirst()){Double v=getNullable(c,"planned");if(v!=null)x=v;}c.close();return x;}

    String[] movementTypesForBroker(String broker){return db.isTradeRepublicProfile(broker)?tradeRepublicMovementTypes:genericMovementTypes;}
    String flowClassForMovement(String type){
        if(type.equals("Versamento personale"))return "ESTERNO_ENTRATA";
        if(type.equals("Prelievo"))return "ESTERNO_USCITA";
        if(type.startsWith("Pagamento carta"))return "ESCLUSO";
        if(type.equals("Saveback"))return "PREMIO";
        if(type.equals("Commissione")||type.equals("Imposta"))return "COSTO";
        if(type.equals("Altro"))return "ALTRO";
        return "INTERNO";
    }
    void movementDialog(String broker){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        Spinner month=spinner(months,Calendar.getInstance().get(Calendar.MONTH));
        EditText date=textField("Data (YYYY-MM-DD)",currentDate());
        Spinner type=spinner(movementTypesForBroker(broker),0);
        EditText amount=field("Importo €",null);EditText notes=textField("Note","");
        box.addView(tv("Profilo broker: "+db.getBrokerProfile(broker),12,true));box.addView(month);box.addView(date);box.addView(type);box.addView(amount);box.addView(notes);
        new AlertDialog.Builder(this).setTitle("Nuovo movimento • "+broker).setView(box).setPositiveButton("Salva",(d,w)->{
            Double a=num(amount);if(a==null||a<0){toast("Importo non valido");return;}String t=type.getSelectedItem().toString();String fc=flowClassForMovement(t);db.addMovement(date.getText().toString().trim(),month.getSelectedItemPosition()+1,broker,t,fc,a,notes.getText().toString());toast("Movimento salvato come "+fc);showHistory();
        }).setNegativeButton("Annulla",null).show();
    }
    void addMovementSection(){
        LinearLayout mv=card();mv.addView(tv("Movimenti classificati",17,true));String broker=brokerFilter();
        if(broker!=null){mv.addView(tv("Profilo: "+db.getBrokerProfile(broker)+". Le categorie specifiche del broker vengono attivate automaticamente; le regole contabili di base restano uguali per tutti.",12,false));Button add=btn("＋ Nuovo movimento");add.setOnClickListener(v->movementDialog(broker));mv.addView(add);}
        else mv.addView(tv("Vista aggregata dei movimenti dei portafogli attivi.",12,false));
        double extIn=db.sumMovements(broker,"ESTERNO_ENTRATA"),extOut=db.sumMovements(broker,"ESTERNO_USCITA"),internal=db.sumMovements(broker,"INTERNO"),reward=db.sumMovements(broker,"PREMIO"),excluded=db.sumMovements(broker,"ESCLUSO");
        mv.addView(tv("Versamenti esterni: "+euro.format(extIn)+" € | Prelievi esterni: "+euro.format(extOut)+" €\nMovimenti interni: "+euro.format(internal)+" € | Premi/Saveback: "+euro.format(reward)+" €\nSpese escluse dall’analisi: "+euro.format(excluded)+" €",13,true));
        Cursor c=db.movements(broker);int count=0;while(c.moveToNext()&&count<12){long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),t=c.getString(c.getColumnIndexOrThrow("movement_type")),fc=c.getString(c.getColumnIndexOrThrow("flow_class"));double a=c.getDouble(c.getColumnIndexOrThrow("amount"));LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);rr.addView(tv(dt+" • "+b+"\n"+t+" • "+fc+" • "+euro.format(a)+" €",12,false),new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo movimento?").setPositiveButton("Elimina",(dd,w)->{db.deleteMovement(id);showHistory();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));mv.addView(rr);count++;}c.close();if(count==0)mv.addView(tv("Nessun movimento classificato.",12,false));content.addView(mv);
    }

    void costDialog(String broker){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        Spinner month=spinner(months,Calendar.getInstance().get(Calendar.MONTH));EditText date=textField("Data YYYY-MM-DD",currentDate());Spinner kind=spinner(new String[]{"Commissione","Imposta"},0);Spinner type=spinner(new String[]{"Acquisto","Vendita","Tobin Tax","Plusvalenza","Imposta di bollo","Ritenuta estera","Imposta su interessi","Altre imposte","Altro"},0);EditText amount=field("Importo pagato €",null),instrument=textField("Strumento / riferimento (facoltativo)",""),isin=textField("ISIN / ticker (facoltativo)",""),notes=textField("Note","");
        box.addView(month);box.addView(date);box.addView(kind);box.addView(type);box.addView(amount);box.addView(instrument);box.addView(isin);box.addView(notes);
        new AlertDialog.Builder(this).setTitle("Registra costo o imposta • "+broker).setView(box).setPositiveButton("Salva",(d,w)->{Double a=num(amount);if(a==null||a<0){toast("Importo non valido");return;}String k=kind.getSelectedItemPosition()==0?"COMMISSIONE":"IMPOSTA";db.addCost(date.getText().toString().trim(),month.getSelectedItemPosition()+1,broker,k,type.getSelectedItem().toString(),a,instrument.getText().toString(),isin.getText().toString(),notes.getText().toString());toast("Costo registrato");showHistory();}).setNegativeButton("Annulla",null).show();
    }

    void addFinancialHistorySection(){
        String broker=brokerFilter();LinearLayout fin=card();fin.addView(tv("Costi, imposte e P/L realizzato",17,true));
        double commissions=db.sumCosts(broker,"COMMISSIONE"),taxes=db.sumCosts(broker,"IMPOSTA"),plGross=db.sumRealized(broker,"realized_pl_gross"),plNet=db.sumRealized(broker,"realized_pl_net");Double unreal=unrealizedPl(broker);
        fin.addView(tv("Commissioni 2026: "+euro.format(commissions)+" €\nImposte 2026: "+euro.format(taxes)+" €\nP/L realizzato lordo: "+euro.format(plGross)+" €\nP/L realizzato netto: "+euro.format(plNet)+" €\nP/L non realizzato: "+(unreal==null?"PMC incompleto":euro.format(unreal)+" €"),13,true));
        if(broker!=null){fin.addView(tv("Regime fiscale: "+db.fiscalRegime(broker),12,false));Button add=btn("＋ Registra commissione / imposta");add.setOnClickListener(v->costDialog(broker));fin.addView(add);}
        String[] taxTypes={"Tobin Tax","Plusvalenza","Imposta di bollo","Ritenuta estera","Imposta su interessi","Altre imposte"};StringBuilder tb=new StringBuilder();for(String t:taxTypes){double x=db.sumTaxType(broker,t);if(x!=0){if(tb.length()>0)tb.append(" • ");tb.append(t).append(": ").append(euro.format(x)).append(" €");}}if(tb.length()>0)fin.addView(tv(tb.toString(),12,false));
        Cursor cc=db.costs(broker);int count=0;while(cc.moveToNext()&&count<10){long id=cc.getLong(cc.getColumnIndexOrThrow("id"));String dt=cc.getString(cc.getColumnIndexOrThrow("date")),b=cc.getString(cc.getColumnIndexOrThrow("broker")),k=cc.getString(cc.getColumnIndexOrThrow("cost_kind")),t=cc.getString(cc.getColumnIndexOrThrow("cost_type")),inst=cc.getString(cc.getColumnIndexOrThrow("instrument"));double a=cc.getDouble(cc.getColumnIndexOrThrow("amount"));LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);rr.addView(tv(dt+" • "+b+"\n"+k+" • "+t+(inst==null||inst.isEmpty()?"":" • "+inst)+" • "+euro.format(a)+" €",12,false),new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo costo/imposta? I dati di una vendita già registrata non verranno modificati.").setPositiveButton("Elimina",(dd,w)->{db.deleteCost(id);showHistory();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));fin.addView(rr);count++;}cc.close();
        content.addView(fin);

        LinearLayout closed=card();closed.addView(tv("Operazioni chiuse / vendite",17,true));Cursor sc=db.sales(broker);int sn=0;while(sc.moveToNext()&&sn<15){String dt=sc.getString(sc.getColumnIndexOrThrow("date")),b=sc.getString(sc.getColumnIndexOrThrow("broker")),inst=sc.getString(sc.getColumnIndexOrThrow("instrument"));double q=sc.getDouble(sc.getColumnIndexOrThrow("quantity")),price=sc.getDouble(sc.getColumnIndexOrThrow("price")),g=sc.getDouble(sc.getColumnIndexOrThrow("gross_amount")),pn=sc.getDouble(sc.getColumnIndexOrThrow("realized_pl_net")),co=sc.getDouble(sc.getColumnIndexOrThrow("commission")),ta=sc.getDouble(sc.getColumnIndexOrThrow("taxes"));closed.addView(tv(dt+" • "+b+"\n"+inst+" • "+trim(q)+" × "+trim(price)+" = "+euro.format(g)+" €\nP/L netto "+euro.format(pn)+" € • commissioni "+euro.format(co)+" € • imposte "+euro.format(ta)+" €",12,false));sn++;}sc.close();if(sn==0)closed.addView(tv("Nessuna vendita registrata.",12,false));content.addView(closed);
    }

    void showHistory(){
        heading("Storico",current);
        addMovementSection();
        addFinancialHistorySection();

        LinearLayout annual=card(); annual.addView(tv("Storico risultati annuali",17,true));
        annual.addView(tv("Qui puoi conservare i risultati degli anni precedenti separando proventi e performance del portafoglio.",12,false));
        Button addYear=btn("＋ Aggiungi / modifica anno");
        addYear.setOnClickListener(v->annualHistoryDialog(null)); annual.addView(addYear);
        Cursor ah=db.annualHistory();
        while(ah.moveToNext()){
            int yr=ah.getInt(ah.getColumnIndexOrThrow("year"));
            Double gi=getNullable(ah,"gross_income"), ni=getNullable(ah,"net_income"), pp=getNullable(ah,"portfolio_profit"), rr=getNullable(ah,"return_rate");
            String notes=ah.getString(ah.getColumnIndexOrThrow("notes"));
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(0,dp(7),0,dp(7));
            String text=yr+"";
            if(gi!=null) text+="\nProventi lordi: "+euro.format(gi)+" €";
            if(ni!=null) text+="\nProventi netti: "+euro.format(ni)+" €";
            if(pp!=null) text+="\nGuadagno/perdita portafoglio: "+euro.format(pp)+" €";
            if(rr!=null) text+="\nRendimento: "+pct.format(rr);
            if(notes!=null&&!notes.trim().isEmpty()) text+="\n"+notes;
            row.addView(tv(text,13,true));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=btn("Modifica"); edit.setOnClickListener(v->annualHistoryDialog(yr));
            Button del=btn("Elimina"); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Elimina anno "+yr).setMessage("Eliminare definitivamente questo dato storico annuale? Il dato non verrà ricreato automaticamente.").setPositiveButton("Elimina",(d,w)->{db.deleteAnnualHistory(yr);showHistory();}).setNegativeButton("Annulla",null).show());
            actions.addView(edit,new LinearLayout.LayoutParams(0,dp(46),1)); actions.addView(del,new LinearLayout.LayoutParams(0,dp(46),1));
            row.addView(actions); annual.addView(row);
        }
        ah.close(); content.addView(annual);

        String broker=brokerFilter();LinearLayout chart=card();chart.addView(tv("Proventi mensili 2026",17,true));chart.addView(tv("Tocca una barra per aprire il dettaglio del mese.",12,false));chart.addView(new ChartView(this,monthlyIncome(broker),false,"€",m->showIncomeMonth(m)),new LinearLayout.LayoutParams(-1,dp(180)));content.addView(chart);
        for(int m=1;m<=12;m++){
            double gross=broker==null?db.sumIncomeMonthActive(m,"gross"):db.sumIncomeMonth(broker,m,"gross"),net=broker==null?db.sumIncomeMonthActive(m,"net"):db.sumIncomeMonth(broker,m,"net"),value=portfolioMonth(broker,m),pac=0; if(current.equals(TOTAL)){for(String b:db.portfolioNames(true))pac+=getPacMonth(b,m);}else pac=getPacMonth(current,m);Double r=calcMonthlyReturn(broker,m);
            if(gross==0&&value==0&&r==null&&m>Calendar.getInstance().get(Calendar.MONTH)+1)continue;
            LinearLayout c=card();c.addView(tv(months[m-1],16,true));c.addView(tv("Patrimonio: "+(value==0?"-":euro.format(value)+" €")+"\nLordo: "+euro.format(gross)+" € | Netto: "+euro.format(net)+" €\nPAC programmato: "+euro.format(pac)+" €\nRendimento: "+(r==null?"-":pct.format(r)),14,false));content.addView(c);
        }
    }
    double portfolioMonth(String broker,int m){if(broker==null){double total=0;for(String b:db.portfolioNames(true))total+=portfolioMonth(b,m);return total;}Cursor c=db.snapshot(broker,m);double x=0;if(c.moveToFirst()){Double f=getNullable(c,"final_value");if(f!=null)x=f;}c.close();return x;}

    void annualHistoryDialog(Integer existingYear){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(8),dp(18),0);
        EditText year=field("Anno",existingYear==null?null:existingYear.doubleValue());
        EditText gross=field("Proventi lordi annuali €",null);
        EditText net=field("Proventi netti annuali € (opzionale)",null);
        EditText profit=field("Guadagno/perdita portafoglio €",null);
        EditText ret=field("Rendimento annuo %",null);
        EditText notes=textField("Note","");
        if(existingYear!=null){
            Cursor c=db.annualHistoryYear(existingYear);
            if(c.moveToFirst()){
                Double x=getNullable(c,"gross_income"); if(x!=null)gross.setText(trim(x));
                x=getNullable(c,"net_income"); if(x!=null)net.setText(trim(x));
                x=getNullable(c,"portfolio_profit"); if(x!=null)profit.setText(trim(x));
                x=getNullable(c,"return_rate"); if(x!=null)ret.setText(trim(x*100.0));
                notes.setText(c.getString(c.getColumnIndexOrThrow("notes")));
            }
            c.close();
        }
        box.addView(year);box.addView(gross);box.addView(net);box.addView(profit);box.addView(ret);box.addView(notes);
        new AlertDialog.Builder(this).setTitle(existingYear==null?"Aggiungi anno":"Modifica "+existingYear).setView(box)
                .setPositiveButton("Salva",(d,w)->{
                    Double y=num(year); if(y==null||y<1900||y>2100){toast("Anno non valido");return;}
                    int yy=(int)Math.round(y);
                    Double rr=num(ret); if(rr!=null)rr=rr/100.0;
                    if(existingYear!=null && existingYear!=yy) db.deleteAnnualHistory(existingYear);
                    db.saveAnnualHistory(yy,num(gross),num(net),num(profit),rr,notes.getText().toString());
                    toast("Storico annuale salvato");showHistory();
                }).setNegativeButton("Annulla",null).show();
    }

    void showGeneralSettings(){
        current="HOME";
        menuGrid.setVisibility(View.GONE);
        heading("Impostazioni generali","Tutti i portafogli");

        LinearLayout info=card();
        info.addView(tv("Backup completo dell'app",17,true));
        info.addView(tv("Stable Beta 3.4.21 • Test privato. Il backup comprende tutti i portafogli, le posizioni, i proventi, i PAC, i rendimenti, lo storico, i profili broker e il registro movimenti. Non dipende dal portafoglio che stavi visualizzando.",13,false));
        content.addView(info);

        LinearLayout backup=card();
        backup.addView(tv("Backup e migrazione",17,true));
        Button exp=btn("Esporta backup completo – tutti i portafogli");
        exp.setOnClickListener(v->exportCsv());
        backup.addView(exp);
        Button imp=btn("Importa / ripristina backup completo");
        imp.setOnClickListener(v->importCsv());
        backup.addView(imp);
        if(hasEmergencyBackup()){
            Button emergency=btn("Ripristina ultimo backup di sicurezza");
            emergency.setOnClickListener(v->restoreEmergencyBackup());
            backup.addView(emergency);
        }
        backup.addView(tv("Compatibile con CSV V2 / V3 / V3.1 / V3.2 / V3.3 / V3.4 / V3.4.5 / V3.4.6 / V3.4.7 / V3.4.8 / V3.4.9 / V3.4.10 / V3.4.11 / V3.4.12 / V3.4.13 / V3.4.14 / V3.4.15 / V3.4.16 / V3.4.17 / V3.4.18 / V3.4.19 / V3.4.20 / V3.4.21.",12,false));
        content.addView(backup);

        LinearLayout note=card();
        note.addView(tv("Importazione",16,true));
        note.addView(tv("Prima di sostituire i dati, il file viene verificato e viene mostrato un riepilogo dei portafogli trovati. Il ripristino avviene in transazione: se il file è vuoto, incompleto o contiene un errore, i dati già presenti restano invariati. Inoltre l'app crea automaticamente un backup di sicurezza interno prima di ogni sostituzione.",13,false));
        content.addView(note);
    }

    void showSettings(){
        heading("Impostazioni",current);
        LinearLayout legal=card();
        legal.addView(tv("Informazioni sull'app",17,true));
        legal.addView(tv("Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.",12,false));
        content.addView(legal);

        LinearLayout s=card();s.addView(tv("Parametri generali",17,true));
        EditText tax=field("Aliquota fiscale %",db.getTaxRate()*100);s.addView(tax);
        s.addView(tv("Portafoglio 2026 • Stable Beta 3.4.21\nVersione per test privato. I dati sono salvati localmente: effettua periodicamente un backup.",12,true));
        Button save=btn("Salva impostazioni");save.setOnClickListener(v->{if(num(tax)!=null)db.setSettingDouble("tax_rate",n(tax)/100);toast("Impostazioni salvate");});s.addView(save);content.addView(s);

        if(!current.equals(TOTAL) && !current.equals("HOME") && db.portfolioExists(current)){
            LinearLayout fees=card();fees.addView(tv("Commissioni e fiscalità del portafoglio",17,true));
            fees.addView(tv("Le commissioni sono specifiche del singolo broker. I valori qui impostati vengono proposti automaticamente su acquisti e vendite, ma restano modificabili per ogni operazione.",12,false));
            String buyType=db.portfolioString(current,"buy_commission_type","FISSA"),sellType=db.portfolioString(current,"sell_commission_type","FISSA");
            Spinner buyTypeSp=spinner(new String[]{"Fissa (€)","Percentuale (%)"},"PERCENTUALE".equalsIgnoreCase(buyType)?1:0);
            Spinner sellTypeSp=spinner(new String[]{"Fissa (€)","Percentuale (%)"},"PERCENTUALE".equalsIgnoreCase(sellType)?1:0);
            EditText buyVal=field("Commissione acquisto predefinita",db.portfolioDouble(current,"buy_commission_value",0));
            EditText sellVal=field("Commissione vendita predefinita",db.portfolioDouble(current,"sell_commission_value",0));
            EditText minFee=field("Commissione minima € (0 = nessun minimo)",db.portfolioDouble(current,"commission_min",0));
            EditText maxFee=field("Commissione massima € (0 = nessun massimo)",db.portfolioDouble(current,"commission_max",0));
            String regime=db.fiscalRegime(current);String[] regimes={"Non specificato","Amministrato","Dichiarativo","Altro"};int regimeIdx=0;for(int i=0;i<regimes.length;i++)if(regimes[i].equalsIgnoreCase(regime))regimeIdx=i;Spinner fiscal=spinner(regimes,regimeIdx);
            fees.addView(tv("Commissione acquisto",12,true));fees.addView(buyTypeSp);fees.addView(buyVal);
            fees.addView(tv("Commissione vendita",12,true));fees.addView(sellTypeSp);fees.addView(sellVal);fees.addView(minFee);fees.addView(maxFee);
            fees.addView(tv("Regime fiscale",12,true));fees.addView(fiscal);
            Button saveFees=btn("Salva commissioni e fiscalità");saveFees.setOnClickListener(v->{
                double bv=num(buyVal)==null?0:n(buyVal),sv=num(sellVal)==null?0:n(sellVal),mn=num(minFee)==null?0:n(minFee),mx=num(maxFee)==null?0:n(maxFee);
                if(bv<0||sv<0||mn<0||mx<0){toast("Commissioni non valide");return;}
                db.saveBrokerFinancialSettings(current,buyTypeSp.getSelectedItemPosition()==1?"PERCENTUALE":"FISSA",bv,sellTypeSp.getSelectedItemPosition()==1?"PERCENTUALE":"FISSA",sv,mn,mx,fiscal.getSelectedItem().toString());toast("Commissioni e fiscalità salvate");showSettings();
            });fees.addView(saveFees);content.addView(fees);
        }

        LinearLayout pm=card();
        if(!current.equals(TOTAL) && !current.equals("HOME") && db.portfolioExists(current)){
            pm.addView(tv("Gestione portafoglio",17,true));
            Cursor one=db.portfolios(); boolean found=false;
            while(one.moveToNext()){
                String name=one.getString(one.getColumnIndexOrThrow("name"));
                if(!name.equals(current)) continue;
                found=true;
                boolean active=one.getInt(one.getColumnIndexOrThrow("active"))==1;
                double pac=one.getDouble(one.getColumnIndexOrThrow("pac_default"));
                String profile=db.getBrokerProfile(name);
                pm.addView(tv(name+(active?"":" (archiviato)")+" • "+profile+" • PAC predefinito "+euro.format(pac)+" €",14,true));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button ren=btn("Rinomina");ren.setOnClickListener(v->renamePortfolioDialog(name));
                Button prof=btn("Broker");prof.setOnClickListener(v->brokerProfileDialog(name));
                Button arc=btn(active?"Archivia":"Riattiva");arc.setOnClickListener(v->{db.setPortfolioActive(name,!active);showSettings();});
                Button del=btn("Elimina");del.setOnClickListener(v->deletePortfolioDialog(name));
                actions.addView(ren,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(prof,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(arc,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));
                pm.addView(actions);
                break;
            }
            one.close();
            if(!found) pm.addView(tv("Portafoglio non disponibile.",13,false));
        }else{
            pm.addView(tv("Gestione portafogli",17,true));
            pm.addView(tv("Da TOTALE puoi gestire i portafogli esistenti. Per crearne uno nuovo usa + AGGIUNGI PORTAFOGLIO nella Home.",13,false));
            Cursor pc=db.portfolios();
            while(pc.moveToNext()){
                String name=pc.getString(pc.getColumnIndexOrThrow("name"));
                boolean active=pc.getInt(pc.getColumnIndexOrThrow("active"))==1;
                double pac=pc.getDouble(pc.getColumnIndexOrThrow("pac_default"));
                LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(0,dp(8),0,dp(8));
                String profile=db.getBrokerProfile(name);
                row.addView(tv(name+(active?"":" (archiviato)")+" • "+profile+" • PAC predefinito "+euro.format(pac)+" €",14,true));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button ren=btn("Rinomina");ren.setOnClickListener(v->renamePortfolioDialog(name));
                Button prof=btn("Broker");prof.setOnClickListener(v->brokerProfileDialog(name));
                Button arc=btn(active?"Archivia":"Riattiva");arc.setOnClickListener(v->{db.setPortfolioActive(name,!active);showSettings();});
                Button del=btn("Elimina");del.setOnClickListener(v->deletePortfolioDialog(name));
                actions.addView(ren,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(prof,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(arc,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));
                row.addView(actions);pm.addView(row);
            }
            pc.close();
        }
        content.addView(pm);

        LinearLayout rules=card();rules.addView(tv("Regole importanti",17,true));rules.addView(tv("• Valore titoli = valore attuale degli strumenti in portafoglio.\n• Liquidità = denaro disponibile e non investito.\n• Patrimonio totale = Valore titoli + Liquidità.\n• Se conosci solo il Patrimonio totale puoi salvarlo senza inventare la suddivisione: Valore titoli e Liquidità resteranno non inseriti.\n• Quantità × Prezzo attuale = Valore attuale della posizione.\n• Quantità × PMC = Capitale di carico della posizione.\n• Acquisti e vendite effettuati con liquidità già presente nel broker sono movimenti interni.\n• Versamenti e prelievi esterni sono solo denaro che entra o esce realmente dal broker.\n• Dividendi e cedole non sono versamenti esterni e non vanno conteggiati due volte.\n• Una vendita chiude in tutto o in parte una posizione e registra P/L realizzato, commissioni e imposte.\n• Commissioni e regime fiscale sono configurabili per ogni singolo portafoglio.\n• Tobin Tax, imposta su plusvalenza, bollo e altre imposte possono essere registrate separatamente per il conteggio annuale.\n• Il Rendimento da inizio anno si calcola automaticamente dai mesi salvati.\n• Rinomina mantiene storico, proventi, rendimento e PAC collegati.\n• Archivia conserva i dati ma esclude il portafoglio dal Totale.\n• Elimina cancella definitivamente tutti i dati di quel portafoglio.\n• Ogni portafoglio ha un profilo broker: le regole contabili restano generiche, mentre funzioni specifiche come Round up e Saveback si attivano solo per Trade Republic.\n• Se il broker non è riconosciuto viene usato il profilo Generico, senza inventare funzioni non disponibili.",14,false));content.addView(rules);
    }

    void addPortfolioDialog(){
        final boolean fromHome=current.equals("HOME");
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        EditText name=textField("Nome portafoglio","");
        Spinner profile=spinner(brokerProfiles,0);
        EditText pac=field("PAC mensile predefinito €",0.0);
        box.addView(name);box.addView(tv("Broker / profilo",12,true));box.addView(profile);box.addView(pac);
        new AlertDialog.Builder(this).setTitle("Aggiungi portafoglio").setView(box).setPositiveButton("Aggiungi",(d,w)->{
            String nme=name.getText().toString().trim();double p=num(pac)==null?0:n(pac);String selected=profile.getSelectedItem().toString();
            String prof=selected.equals("Riconoscimento automatico")?DbHelper.inferBrokerProfile(nme):(selected.equals("Altro / Generico")?"Generico":selected);
            if(db.addPortfolio(nme,p,prof)){toast("Portafoglio aggiunto • profilo "+prof);if(fromHome)showHome();else showSettings();}else toast("Nome non valido o già esistente");
        }).setNegativeButton("Annulla",null).show();
    }
    void brokerProfileDialog(String name){
        String currentProfile=db.getBrokerProfile(name);int selected=0;for(int i=1;i<brokerProfiles.length;i++){String p=brokerProfiles[i].equals("Altro / Generico")?"Generico":brokerProfiles[i];if(p.equalsIgnoreCase(currentProfile)){selected=i;break;}}
        final int initial=selected;
        new AlertDialog.Builder(this).setTitle("Profilo broker • "+name).setSingleChoiceItems(brokerProfiles,selected,null).setPositiveButton("Salva",(d,w)->{
            AlertDialog ad=(AlertDialog)d;int pos=ad.getListView().getCheckedItemPosition();if(pos<0)pos=initial;String sel=brokerProfiles[pos];String prof=sel.equals("Riconoscimento automatico")?DbHelper.inferBrokerProfile(name):(sel.equals("Altro / Generico")?"Generico":sel);db.setBrokerProfile(name,prof);toast("Profilo broker: "+prof);showSettings();
        }).setNegativeButton("Annulla",null).show();
    }
    void renamePortfolioDialog(String oldName){
        EditText name=textField("Nuovo nome",oldName);new AlertDialog.Builder(this).setTitle("Rinomina "+oldName).setView(name).setPositiveButton("Rinomina",(d,w)->{String nme=name.getText().toString().trim();if(db.renamePortfolio(oldName,nme)){if(current.equals(oldName))current=nme;toast("Portafoglio rinominato");showSettings();}else toast("Nome non valido o già esistente");}).setNegativeButton("Annulla",null).show();
    }
    void deletePortfolioDialog(String name){
        new AlertDialog.Builder(this).setTitle("Elimina portafoglio").setMessage("Eliminare definitivamente '"+name+"'? Saranno cancellati proventi, rendimenti, snapshot e PAC collegati. Per conservarli usa Archivia.").setPositiveButton("ELIMINA",(d,w)->{db.deletePortfolio(name);if(current.equals(name))current="HOME";toast("Portafoglio eliminato");showSettings();}).setNegativeButton("Annulla",null).show();
    }

    void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"Portafoglio_2026_V3421_backup.csv");startActivityForResult(i,41);}
    void importCsv(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,42);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        if(requestCode==41){try(OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write(buildCsv().getBytes(StandardCharsets.UTF_8));toast("Backup esportato");}catch(Exception e){toast("Errore export: "+e.getMessage());}}
        else if(requestCode==42){try(InputStream is=getContentResolver().openInputStream(data.getData())){ByteArrayOutputStream bo=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);pendingImport=bo.toString("UTF-8");confirmImport();}catch(Exception e){toast("Errore import: "+e.getMessage());}}
        else if(requestCode==43){readStatementFile(data.getData());}
    }

    void showStatementImportCenter(){
        current=TOTAL;menuGrid.setVisibility(View.VISIBLE);heading("Importazioni estratti conto","Tutti i portafogli");
        LinearLayout intro=card();intro.addView(tv("Aggiornamento mensile automatico",17,true));intro.addView(tv("Scegli il portafoglio e carica PDF o CSV. L’importazione aggiorna SOLO quel broker, non somma il nuovo patrimonio a quello precedente, conserva PMC e commissioni già registrati sugli ISIN esistenti e salva uno snapshot del mese. Il file viene identificato tramite impronta SHA-256 per evitare duplicati.",13,false));content.addView(intro);
        for(String b:db.portfolioNames(true)){LinearLayout c=card();c.addView(tv(b+" • "+db.getBrokerProfile(b),16,true));Button x=btn("Importa estratto conto • "+b);x.setOnClickListener(v->startStatementImport(b));c.addView(x);content.addView(c);}
        LinearLayout hist=card();hist.addView(tv("Ultimi estratti importati",17,true));Cursor h=db.statementImports(null);int shown=0;while(h.moveToNext()&&shown<8){String b=h.getString(h.getColumnIndexOrThrow("broker")),d=h.getString(h.getColumnIndexOrThrow("statement_date")),n=h.getString(h.getColumnIndexOrThrow("source_name"));Double t=getNullable(h,"total_value");hist.addView(tv((d==null||d.isEmpty()?"Data non indicata":d)+" • "+b+"\n"+(n==null?"":n)+(t==null?"":" • "+euro.format(t)+" €"),13,false));shown++;}h.close();if(shown==0)hist.addView(tv("Nessun estratto importato con la nuova funzione.",13,false));content.addView(hist);
    }

    void startStatementImport(String broker){
        if(broker==null||!db.portfolioExists(broker)){toast("Portafoglio non valido");return;}
        pendingImportPortfolio=broker;pendingDirectaImport=null;pendingStatementHash="";pendingStatementName="";openPortfolioStatement();
    }

    void choosePortfolioForPdfImport(){
        java.util.List<String> ps=db.portfolioNames(true);if(ps.isEmpty()){toast("Crea prima almeno un portafoglio");return;}
        String[] names=ps.toArray(new String[0]);int checked=0;if(!current.equals(TOTAL)&&!current.equals("HOME")){int i=ps.indexOf(current);if(i>=0)checked=i;}final int initial=checked;
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio di destinazione").setSingleChoiceItems(names,checked,null).setPositiveButton("Continua",(d,w)->{AlertDialog ad=(AlertDialog)d;int pos=ad.getListView().getCheckedItemPosition();if(pos<0)pos=initial;startStatementImport(names[pos]);}).setNegativeButton("Annulla",null).show();
    }

    void openPortfolioStatement(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","text/csv","text/comma-separated-values","text/plain"});startActivityForResult(i,43);}
    void openPortfolioPdf(){openPortfolioStatement();}

    String displayName(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}String x=uri.getLastPathSegment();return x==null?"estratto":x;
    }
    String sha256(byte[] data)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] dig=md.digest(data);StringBuilder b=new StringBuilder();for(byte x:dig)b.append(String.format(Locale.US,"%02x",x));return b.toString();}
    byte[] readAll(Uri uri)throws Exception{try(InputStream is=getContentResolver().openInputStream(uri);ByteArrayOutputStream bo=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);return bo.toByteArray();}}

    void readStatementFile(Uri uri){
        final String target=pendingImportPortfolio;if(target==null||target.isEmpty()){toast("Scegli prima il portafoglio");return;}toast("Lettura estratto in corso…");
        new Thread(()->{try{byte[] bytes=readAll(uri);String hash=sha256(bytes),name=displayName(uri);if(db.isStatementImported(target,hash)){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Estratto già importato").setMessage("Questo stesso file è già stato importato in "+target+". Nessun dato è stato modificato.").setPositiveButton("OK",null).show());return;}String mime=getContentResolver().getType(uri);boolean pdf=(mime!=null&&mime.toLowerCase(Locale.US).contains("pdf"))||name.toLowerCase(Locale.US).endsWith(".pdf");DirectaImport out;if(pdf){try(InputStream is=new ByteArrayInputStream(bytes);PDDocument doc=PDDocument.load(is)){String raw=new PDFTextStripper().getText(doc);out=parseStatementPdf(raw,target);}}else out=parseStatementCsv(new String(bytes,StandardCharsets.UTF_8),target);pendingStatementHash=hash;pendingStatementName=name;runOnUiThread(()->previewDirectaImport(out));}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Estratto non importato").setMessage(e.getMessage()+"\n\nNessun dato del portafoglio è stato modificato.").setPositiveButton("OK",null).show());}}).start();
    }

    DirectaImport parseStatementPdf(String raw,String target)throws Exception{
        String up=raw==null?"":raw.toUpperCase(Locale.ITALY);String profile=db.getBrokerProfile(target);
        if(up.contains("SITUAZIONE PATRIMONIALE")){if("Trade Republic".equalsIgnoreCase(profile))throw new Exception("Il PDF sembra Directa ma il portafoglio selezionato è Trade Republic.");return parseDirectaSituation(raw);}
        if(up.contains("TRADE REPUBLIC")||"Trade Republic".equalsIgnoreCase(profile))return parseTradeRepublicStatement(raw);
        try{return parseDirectaSituation(raw);}catch(Exception ignored){}
        throw new Exception("Formato PDF non riconosciuto. Sono supportati la Situazione Patrimoniale Directa e, in modalità beta, gli estratti/portfolio statement Trade Republic con posizioni valorizzate.");
    }

    String normalizeDate(String d){if(d==null)return "";d=d.trim();Matcher y=Pattern.compile("(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2})").matcher(d);if(y.find())return String.format(Locale.US,"%s-%02d-%02d",y.group(1),Integer.parseInt(y.group(2)),Integer.parseInt(y.group(3)));Matcher i=Pattern.compile("(\\d{1,2})[-./](\\d{1,2})[-./](\\d{4})").matcher(d);if(i.find())return String.format(Locale.US,"%s-%02d-%02d",i.group(3),Integer.parseInt(i.group(2)),Integer.parseInt(i.group(1)));return d;}

    DirectaImport parseDirectaSituation(String raw) throws Exception{
        if(raw==null||!raw.toUpperCase(Locale.ITALY).contains("SITUAZIONE PATRIMONIALE"))throw new Exception("non sembra una Situazione Patrimoniale Directa");
        DirectaImport out=new DirectaImport();out.parser="Directa PDF";String t=raw.replace('\u00A0',' ');
        Matcher dm=Pattern.compile("(?i)data\\s*Operazione\\s*(\\d{1,2}/\\d{1,2}/\\d{4})").matcher(t);if(dm.find())out.date=normalizeDate(dm.group(1));
        Matcher cm=Pattern.compile("(?i)TOTALE\\s+LIQUIDITA'\\s*:\\s*([0-9.]+,[0-9]{2})").matcher(t);if(cm.find())out.cash=parseItalian(cm.group(1));
        Pattern row=Pattern.compile("(?m)^\\s*(.+?)\\s+\\(([A-Z]{2}[A-Z0-9]{10})\\)\\s+([0-9.,]+)\\s+([0-9.,]+)\\s+([0-9.]+,[0-9]{2})\\s*$");
        Matcher rm=row.matcher(t);double sum=0;while(rm.find()){String name=rm.group(1).trim(),isin=rm.group(2).trim();Double q=parseItalian(rm.group(3)),pr=parseItalian(rm.group(4)),v=parseItalian(rm.group(5));if(q!=null&&pr!=null&&v!=null){out.positions.add(new DbHelper.Position(isin,name,q,pr,v,out.date));sum+=v;}}
        Matcher tm=Pattern.compile("(?is)TOTALE\\s+TITOLI\\s+EURO.{0,120}?([0-9.]+,[0-9]{2})").matcher(t);if(tm.find())out.printedInvested=parseItalian(tm.group(1));out.invested=out.printedInvested!=null?out.printedInvested:sum;
        if(out.date.isEmpty())throw new Exception("data estratto Directa non trovata");if(out.positions.isEmpty())throw new Exception("nessuna posizione trovata");if(out.cash==null)throw new Exception("liquidità non trovata");if(out.printedInvested!=null&&Math.abs(sum-out.printedInvested)>0.10)throw new Exception("totale titoli non coerente con le posizioni");return out;
    }

    Double parseFlexible(String s){try{if(s==null)return null;String x=s.replace("€","").replace("EUR","").replace(" ","").trim();x=x.replaceAll("[^0-9,.-]","");if(x.isEmpty())return null;int lc=x.lastIndexOf(','),ld=x.lastIndexOf('.');if(lc>=0&&ld>=0){if(lc>ld)x=x.replace(".","").replace(',','.');else x=x.replace(",","");}else if(lc>=0)x=x.replace(',','.');return Double.parseDouble(x);}catch(Exception e){return null;}}

    DirectaImport parseTradeRepublicStatement(String raw)throws Exception{
        if(raw==null||!raw.toUpperCase(Locale.ITALY).contains("TRADE REPUBLIC"))throw new Exception("non sembra un estratto Trade Republic");DirectaImport out=new DirectaImport();out.parser="Trade Republic PDF beta";String t=raw.replace('\u00A0',' ');
        Matcher dates=Pattern.compile("(\\d{1,2}[./]\\d{1,2}[./]\\d{4}|\\d{4}-\\d{1,2}-\\d{1,2})").matcher(t);String last="";while(dates.find())last=dates.group(1);out.date=normalizeDate(last);if(out.date.isEmpty())out.date=currentDate();
        Matcher cash=Pattern.compile("(?i)(?:cash(?:\\s+balance)?|saldo(?:\\s+contante)?|liquidit[aà]|disponibilit[aà])[^0-9-]{0,50}([0-9][0-9.,]*[,.][0-9]{2})").matcher(t);if(cash.find())out.cash=parseFlexible(cash.group(1));
        String[] lines=t.split("\\r?\\n");Pattern ip=Pattern.compile("([A-Z]{2}[A-Z0-9]{10})");double sum=0;
        for(int i=0;i<lines.length;i++){Matcher im=ip.matcher(lines[i]);if(!im.find())continue;String isin=im.group(1),name=lines[i].substring(0,im.start()).trim();if(name.length()<3&&i>0)name=lines[i-1].trim();StringBuilder chunk=new StringBuilder(lines[i].substring(im.end()));for(int j=1;j<=2&&i+j<lines.length;j++)chunk.append(" ").append(lines[i+j]);Matcher nm=Pattern.compile("[-+]?[0-9]+(?:[.,][0-9]+)*(?:[.,][0-9]+)?").matcher(chunk.toString());ArrayList<Double> nums=new ArrayList<>();while(nm.find()){Double v=parseFlexible(nm.group());if(v!=null&&v>=0)nums.add(v);}Double q=null,pr=null,val=null;for(int a=0;a<nums.size()&&val==null;a++)for(int b=a+1;b<nums.size()&&val==null;b++)for(int c=b+1;c<nums.size();c++){double qq=nums.get(a),pp=nums.get(b),vv=nums.get(c);if(qq>0&&pp>0&&vv>0&&Math.abs(qq*pp-vv)/Math.max(1.0,vv)<0.08){q=qq;pr=pp;val=vv;break;}}if(val==null&&nums.size()>=2){double qq=nums.get(0),vv=nums.get(nums.size()-1);if(qq>0&&vv>0){q=qq;val=vv;pr=vv/qq;}}if(q!=null&&pr!=null&&val!=null){if(name.isEmpty())name=isin;out.positions.add(new DbHelper.Position(isin,name,q,pr,val,out.date));sum+=val;}}
        out.invested=sum;Matcher total=Pattern.compile("(?i)(?:portfolio(?:\\s+value)?|valore\\s+portafoglio|totale\\s+titoli|securities)[^0-9-]{0,60}([0-9][0-9.,]*[,.][0-9]{2})").matcher(t);Double grand=total.find()?parseFlexible(total.group(1)):null;if(out.positions.isEmpty())throw new Exception("Trade Republic riconosciuto, ma le posizioni non sono leggibili automaticamente da questo formato PDF. Serve un esempio di questo estratto per adattare il parser senza rischiare valori errati.");if(out.cash==null&&grand!=null&&grand>=sum)out.cash=grand-sum;return out;
    }

    DirectaImport parseStatementCsv(String raw,String target)throws Exception{
        if(raw==null||raw.trim().isEmpty())throw new Exception("CSV vuoto");if(raw.startsWith("PORTAFOGLIO2026_"))throw new Exception("Hai selezionato un backup dell’app, non un estratto conto mensile.");String[] lines=raw.replace("\\r","").split("\\n");if(lines.length<2)throw new Exception("CSV senza righe dati");char sep=lines[0].chars().filter(ch->ch==';').count()>=lines[0].chars().filter(ch->ch==',').count()?';':',';String[] head=splitCsvSimple(lines[0],sep);Map<String,Integer> idx=new HashMap<>();for(int i=0;i<head.length;i++)idx.put(head[i].trim().toLowerCase(Locale.ITALY).replace("à","a"),i);int iIsin=findCol(idx,"isin"),iName=findCol(idx,"strumento","instrument","name","security","product"),iQty=findCol(idx,"quantita","quantity","shares","pezzi"),iPrice=findCol(idx,"prezzo","price","current price"),iValue=findCol(idx,"valore","value","market value","current value"),iDate=findCol(idx,"data","date");if(iIsin<0||iQty<0||(iPrice<0&&iValue<0))throw new Exception("CSV non riconosciuto: servono almeno le colonne ISIN, Quantità e Prezzo oppure Valore.");DirectaImport out=new DirectaImport();out.parser="CSV posizioni";double sum=0;for(int r=1;r<lines.length;r++){if(lines[r].trim().isEmpty())continue;String[] a=splitCsvSimple(lines[r],sep);String isin=cell(a,iIsin).trim();if(!isin.matches("[A-Z]{2}[A-Z0-9]{10}"))continue;Double q=parseFlexible(cell(a,iQty)),pr=iPrice>=0?parseFlexible(cell(a,iPrice)):null,val=iValue>=0?parseFlexible(cell(a,iValue)):null;if(q==null||q<=0)continue;if(val==null&&pr!=null)val=q*pr;if(pr==null&&val!=null)pr=val/q;if(pr==null||val==null)continue;String name=iName>=0?cell(a,iName):isin;if(iDate>=0&&!cell(a,iDate).trim().isEmpty())out.date=normalizeDate(cell(a,iDate));out.positions.add(new DbHelper.Position(isin,name,q,pr,val,out.date));sum+=val;}if(out.positions.isEmpty())throw new Exception("nessuna posizione valida trovata nel CSV");if(out.date.isEmpty())out.date=currentDate();out.invested=sum;return out;
    }
    int findCol(Map<String,Integer> idx,String... names){for(String n:names){for(Map.Entry<String,Integer> e:idx.entrySet())if(e.getKey().equals(n)||e.getKey().contains(n))return e.getValue();}return -1;}
    String[] splitCsvSimple(String line,char sep){return line.split(Pattern.quote(String.valueOf(sep)),-1);}
    String cell(String[] a,int i){return i>=0&&i<a.length?a[i].replace("\"","").trim():"";}
    Double parseItalian(String s){try{if(s==null)return null;String x=s.trim().replace(".","").replace(",",".");return Double.parseDouble(x);}catch(Exception e){return null;}}

    void previewDirectaImport(DirectaImport out){
        if(pendingImportPortfolio==null||pendingImportPortfolio.isEmpty()||!db.portfolioExists(pendingImportPortfolio)){toast("Portafoglio di destinazione non valido");return;}pendingDirectaImport=out;Double oldCash=db.latestCashValue(pendingImportPortfolio);Double effectiveCash=out.cash!=null?out.cash:oldCash;double total=(out.invested==null?0:out.invested)+(effectiveCash==null?0:effectiveCash);StringBuilder msg=new StringBuilder();msg.append("Portafoglio destinazione: ").append(pendingImportPortfolio).append("\n");msg.append("Formato riconosciuto: ").append(out.parser).append("\n");msg.append("Data situazione: ").append(out.date.isEmpty()?"non indicata":out.date).append("\n\n");msg.append("Posizioni trovate: ").append(out.positions.size()).append("\n");msg.append("Valore titoli: ").append(euro.format(out.invested)).append(" €\n");if(out.cash!=null)msg.append("Liquidità: ").append(euro.format(out.cash)).append(" €\n");else msg.append("Liquidità: non presente nel file — verrà mantenuto il valore già registrato").append(oldCash==null?"":" ("+euro.format(oldCash)+" €)").append("\n");msg.append("Patrimonio risultante: ").append(euro.format(total)).append(" €\n\n");msg.append("Confermando: le posizioni correnti del SOLO portafoglio selezionato vengono sostituite; il patrimonio non viene sommato al precedente; PMC e commissioni di acquisto già presenti sugli stessi ISIN vengono conservati; viene salvato/aggiornato lo snapshot del mese; proventi, PAC, movimenti, vendite e altri portafogli restano invariati. Lo stesso file non potrà essere importato due volte.");new AlertDialog.Builder(this).setTitle("Anteprima estratto conto").setMessage(msg.toString()).setPositiveButton("IMPORTA",(d,w)->confirmPortfolioPdfImport()).setNegativeButton("Annulla",null).show();
    }

    void confirmPortfolioPdfImport(){
        if(pendingDirectaImport==null||pendingImportPortfolio==null||pendingImportPortfolio.isEmpty())return;String target=pendingImportPortfolio;boolean ok=db.applyStatementImport(target,pendingDirectaImport.positions,pendingDirectaImport.invested,pendingDirectaImport.cash,pendingDirectaImport.date,"Estratto conto • "+pendingDirectaImport.parser,pendingStatementHash,pendingStatementName);if(!ok){toast("Estratto già importato: nessun dato modificato");return;}toast(target+" aggiornato: "+pendingDirectaImport.positions.size()+" posizioni • snapshot mensile salvato");current=target;pendingDirectaImport=null;pendingImportPortfolio="";pendingStatementHash="";pendingStatementName="";showDashboard();
    }

    void choosePortfolioForWealthUpdate(){
        java.util.List<String> ps=db.portfolioNames(true);
        if(ps.isEmpty()){toast("Crea prima almeno un portafoglio");return;}
        String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio").setItems(names,(d,which)->showWealthUpdateOptions(names[which])).show();
    }

    void showWealthUpdateOptions(String broker){
        final String[] opts={"INSERIMENTO MANUALE","IMPORTA DA FILE"};
        new AlertDialog.Builder(this).setTitle("Aggiorna "+broker).setItems(opts,(d,which)->{
            if(which==0)showManualPortfolioEditor(broker);
            else startStatementImport(broker);
        }).setNegativeButton("Annulla",null).show();
    }


    void showManualPortfolioEditor(String broker){
        current=broker;menuGrid.setVisibility(View.VISIBLE);heading("Aggiorna patrimonio",broker);

        LinearLayout summary=card();
        summary.addView(tv("Riepilogo patrimonio",17,true));
        summary.addView(tv("Inserisci Valore titoli e Liquidità. Il Patrimonio totale viene calcolato automaticamente e non può essere modificato manualmente.",13,false));
        Double titlesValue=db.latestInvestedValue(broker),cash=db.latestCashValue(broker);double previousTotal=db.latestPortfolioValue(broker);

        summary.addView(tv("Valore titoli",12,true));
        EditText fTitles=field("es. 103964,50",titlesValue);
        summary.addView(fTitles);

        summary.addView(tv("Liquidità",12,true));
        EditText fCash=field("es. 6040,22",cash);
        summary.addView(fCash);

        final TextView totalDisplay=tv("",16,true);
        totalDisplay.setPadding(dp(4),dp(10),dp(4),dp(10));
        summary.addView(totalDisplay);

        if(previousTotal>0 && (titlesValue==null || cash==null)){
            summary.addView(tv("Patrimonio totale precedente registrato: "+euro.format(previousTotal)+" €. Verrà sostituito dal nuovo totale automatico quando salvi Valore titoli e Liquidità.",12,false));
        }

        summary.addView(tv("Data",12,true));
        EditText fDate=textField("YYYY-MM-DD",currentDate());
        summary.addView(fDate);

        final Runnable refreshTotal=()->{
            Double tVal=num(fTitles),cVal=num(fCash);
            if(tVal!=null && cVal!=null && tVal>=0 && cVal>=0){
                totalDisplay.setText("Patrimonio totale calcolato: "+euro.format(tVal+cVal)+" €");
            }else{
                totalDisplay.setText("Patrimonio totale calcolato: inserisci Valore titoli e Liquidità");
            }
        };
        TextWatcher totalWatcher=new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){}
            @Override public void afterTextChanged(Editable e){refreshTotal.run();}
        };
        fTitles.addTextChangedListener(totalWatcher);
        fCash.addTextChangedListener(totalWatcher);
        refreshTotal.run();

        Button saveSummary=btn("SALVA RIEPILOGO");
        saveSummary.setOnClickListener(v->{
            if(invalidNumber(fTitles)||invalidNumber(fCash)){toast("Formato importo non valido. Esempi accettati: 6040,22 oppure 6.040,22");return;}
            Double tVal=num(fTitles),cVal=num(fCash);
            if(tVal==null||cVal==null){toast("Inserisci sia Valore titoli sia Liquidità. Il Patrimonio totale viene calcolato automaticamente.");return;}
            if(tVal<0||cVal<0){toast("Gli importi non possono essere negativi");return;}
            double tot=tVal+cVal;
            String date=fDate.getText().toString().trim();if(date.isEmpty())date=currentDate();
            db.savePortfolioStatus(broker,tVal,cVal,tot,date,"Inserimento manuale");
            toast("Patrimonio aggiornato: "+euro.format(tot)+" €");showManualPortfolioEditor(broker);
        });
        summary.addView(saveSummary);content.addView(summary);

        int pcnt=db.positionCount(broker);double posValue=db.sumPositionsCurrentValue(broker);Double cost=db.sumPositionsCostBasis(broker);
        LinearLayout intro=card();intro.addView(tv("Posizioni dettagliate",17,true));
        String posInfo=pcnt+" strumenti";
        if(pcnt>0)posInfo+=" • Valore attuale "+euro.format(posValue)+" €";
        if(cost!=null){double pl=posValue-cost;double plPct=Math.abs(cost)<0.000001?0:pl/cost;posInfo+="\nCapitale di carico "+euro.format(cost)+" € • Guadagno/Perdita "+euro.format(pl)+" € ("+pct.format(plPct)+")";}
        else if(pcnt>0)posInfo+="\nCompleta il PMC delle posizioni per calcolare Guadagno/Perdita.";
        intro.addView(tv(posInfo,13,false));
        intro.addView(tv("Per ogni strumento inserisci Nome, ISIN, ticker facoltativo, categoria, Quantità, PMC (prezzo medio di carico) e Prezzo attuale.",12,false));
        Button add=btn("＋ INSERISCI TITOLO");add.setOnClickListener(v->positionEditDialog(broker,null,null,null,null,null,null,null));intro.addView(add);content.addView(intro);

        Cursor c=db.positions(broker);int n=0;
        while(c.moveToNext()){
            n++;String name=c.getString(c.getColumnIndexOrThrow("instrument"));String isin=c.getString(c.getColumnIndexOrThrow("isin"));int ti=c.getColumnIndex("ticker");String ticker=ti>=0&&!c.isNull(ti)?c.getString(ti):"";if(ticker.isEmpty())ticker=knownTicker(name,isin);double q=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));int pi=c.getColumnIndex("pmc");Double pmc=pi>=0&&!c.isNull(pi)?c.getDouble(pi):null;int bfi=c.getColumnIndex("buy_fee");double buyFee=bfi>=0&&!c.isNull(bfi)?c.getDouble(bfi):0;
            double costRow=pmc==null?0:q*pmc,pl=pmc==null?0:val-costRow,plPct=pmc==null||Math.abs(costRow)<0.000001?0:pl/costRow;
            LinearLayout row=card();
            String line=name+"\n"+isin+(ticker.isEmpty()?"":" • Ticker "+ticker)+" • "+positionCategory(broker,name,isin)+"\nQuantità: "+trim(q)+" • PMC: "+(pmc==null?"non inserito":trim(pmc))+" • Prezzo attuale: "+trim(pr)+"\nValore attuale: "+euro.format(val)+" € • Commissione acquisto residua: "+euro.format(buyFee)+" €";
            if(pmc!=null)line+=" • Guadagno/Perdita: "+euro.format(pl)+" € ("+pct.format(plPct)+")";
            row.addView(tv(line,13,true));
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
            final Double fPmc=pmc;final double fQ=q,fPr=pr,fBuyFee=buyFee;final String fName=name,fIsin=isin;
            Button edit=btn("Modifica");edit.setOnClickListener(v->positionEditDialog(broker,fIsin,fName,fQ,fPmc,fPr,fIsin,fBuyFee));
            Button sell=btn("Vendi");sell.setOnClickListener(v->positionSaleDialog(broker,fIsin,fName,fQ,fPmc,fPr,fBuyFee));
            Button del=btn("Elimina");del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Elimina posizione").setMessage("Eliminare "+fName+" senza registrare una vendita? Usa Vendi se vuoi contabilizzare guadagno/perdita.").setPositiveButton("Elimina",(d,w)->{db.deletePosition(broker,fIsin);db.syncInvestedFromPositions(broker,currentDate());toast("Posizione eliminata");showManualPortfolioEditor(broker);}).setNegativeButton("Annulla",null).show());
            actions.addView(edit,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(sell,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));row.addView(actions);content.addView(row);
        }
        c.close();
        if(n==0){LinearLayout empty=card();empty.addView(tv("Nessuna posizione inserita. Puoi comunque usare il riepilogo patrimoniale sopra.",13,false));content.addView(empty);}
        Button back=btn("Torna alla Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);
    }

    void manualWealthDialog(String broker){
        showManualPortfolioEditor(broker);
    }

    void showPositionsDialog(String broker){
        showManualPortfolioEditor(broker);
    }

    void positionEditDialog(String broker,String isin,String instrument,Double quantity,Double pmc,Double price,String originalIsin,Double existingBuyFee){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        box.addView(tv("Il PMC è il prezzo medio di carico. La commissione di acquisto viene conservata separatamente e sarà attribuita proporzionalmente in caso di vendita parziale.",12,false));
        String existingTicker=originalIsin==null?"":db.positionTicker(broker,originalIsin);if(existingTicker.isEmpty()&&originalIsin!=null)existingTicker=knownTicker(instrument,isin);
        String existingCategory=originalIsin==null?"":db.positionCategory(broker,originalIsin);
        if(existingCategory.isEmpty()&&originalIsin!=null)existingCategory=inferPositionCategory(instrument,isin);
        EditText fName=textField("Nome strumento",instrument==null?"":instrument),fIsin=textField("ISIN / codice principale",isin==null?"":isin),fTicker=textField("Ticker (facoltativo)",existingTicker),fQ=field("Quantità",quantity),fPmc=field("PMC - prezzo medio di carico",pmc),fPrice=field("Prezzo attuale",price),fBuyFee=field("Commissione acquisto € (vuoto = predefinita)",existingBuyFee);
        String[] catChoices={"Riconoscimento automatico","Azioni","ETF","ETP","Certificati","Altro"};int catIdx=0;for(int i=1;i<catChoices.length;i++)if(catChoices[i].equalsIgnoreCase(existingCategory)){catIdx=i;break;}Spinner fCategory=spinner(catChoices,catIdx);
        addLabeledField(box,"Nome strumento",fName);
        addLabeledField(box,"ISIN / codice principale",fIsin);
        addLabeledField(box,"Ticker (facoltativo, es. PST)",fTicker);
        box.addView(tv("Categoria",11,true));box.addView(fCategory);
        box.addView(tv("Altro è riservato agli strumenti non contemplati nelle categorie principali, ad esempio BTP, BOT e obbligazioni.",11,false));
        addLabeledField(box,"Quantità",fQ);
        addLabeledField(box,"PMC - prezzo medio di carico",fPmc);
        addLabeledField(box,"Prezzo attuale (€ per quota)",fPrice);
        addLabeledField(box,"Commissione acquisto (€)",fBuyFee);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog ad=new AlertDialog.Builder(this).setTitle(originalIsin==null?"Inserisci titolo":"Modifica titolo").setView(scroll).setPositiveButton("Salva",null).setNegativeButton("Annulla",null).create();
        ad.setOnShowListener(dd->{
            ad.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                if(invalidNumber(fQ)||invalidNumber(fPrice)||invalidNumber(fPmc)||invalidNumber(fBuyFee)){toast("Formato numerico non valido. Usa ad esempio 10,5 oppure 10.5");return;}
                String code=fIsin.getText().toString().trim().toUpperCase(Locale.ITALY),ticker=fTicker.getText().toString().trim().toUpperCase(Locale.ITALY),name=fName.getText().toString().trim();Double q=num(fQ),p=num(fPrice),m=num(fPmc),fee=num(fBuyFee);
                if(code.isEmpty()||name.isEmpty()){toast("Inserisci almeno nome e ISIN/codice principale");return;}
                if(q==null||q<=0||p==null||p<0){toast("Quantità e Prezzo attuale non validi");return;}
                if(m!=null&&m<0){toast("PMC non valido");return;}
                String selectedCategory=catChoices[fCategory.getSelectedItemPosition()];String finalCategory=selectedCategory.equals("Riconoscimento automatico")?inferPositionCategory(name,code):selectedCategory;
                if(selectedCategory.equals("Riconoscimento automatico")&&finalCategory.equals("Altro")&&!looksLikeOtherInstrument(name)){toast("Categoria non riconosciuta automaticamente: scegli Azioni, ETF, ETP, Certificati oppure Altro.");return;}
                double gross=q*(m!=null?m:p);double buyFee=fee==null?db.defaultCommission(broker,false,gross):fee;if(buyFee<0){toast("Commissione non valida");return;}
                if(originalIsin!=null&&!originalIsin.equals(code))db.deletePosition(broker,originalIsin);
                db.savePosition(broker,new DbHelper.Position(code,name,q,m,p,q*p,currentDate(),buyFee,ticker,finalCategory));
                if(originalIsin==null && buyFee>0){int month=Calendar.getInstance().get(Calendar.MONTH)+1;db.addCost(currentDate(),month,broker,"COMMISSIONE","Acquisto",buyFee,name,code,"Commissione registrata all'aggiunta titolo");}
                db.syncInvestedFromPositions(broker,currentDate());toast("Titolo salvato in "+finalCategory);ad.dismiss();showManualPortfolioEditor(broker);
            });
        });
        ad.show();
    }

    void choosePortfolioForPositionEntry(){
        java.util.List<String> ps=db.portfolioNames(true);if(ps.isEmpty()){toast("Aggiungi prima un portafoglio");return;}String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Inserisci titolo • scegli portafoglio").setItems(names,(d,which)->{String b=names[which];current=b;positionEditDialog(b,null,null,null,null,null,null,null);}).setNegativeButton("Annulla",null).show();
    }

    void positionSaleDialog(String broker,String isin,String instrument,double quantity,Double pmc,double currentPrice,double buyFee){
        if(pmc==null){toast("Inserisci prima il PMC della posizione");return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        box.addView(tv(instrument+"\nDisponibili: "+trim(quantity)+" • PMC "+trim(pmc)+" • Commissione acquisto residua "+euro.format(buyFee)+" €",12,true));
        box.addView(tv("Compila solo commissioni e imposte effettivamente applicate. Lascia 0 se non presenti.",11,false));
        EditText fDate=textField("Data vendita YYYY-MM-DD",currentDate()),fQty=field("Quantità venduta",quantity),fPrice=field("Prezzo di vendita",currentPrice),fComm=field("Commissione vendita €",db.defaultCommission(broker,true,quantity*currentPrice)),fTax=field("Imposta plusvalenza €",0.0),fTobin=field("Tobin Tax €",0.0),fOther=field("Altre imposte €",0.0);EditText fNotes=textField("Note","");
        addLabeledField(box,"Data vendita (AAAA-MM-GG)",fDate);
        addLabeledField(box,"Quantità venduta",fQty);
        addLabeledField(box,"Prezzo di vendita (€ per quota)",fPrice);
        addLabeledField(box,"Commissione di vendita (€)",fComm);
        addLabeledField(box,"Imposta su plusvalenza (€)",fTax);
        addLabeledField(box,"Tobin Tax (€)",fTobin);
        addLabeledField(box,"Altre imposte / costi fiscali (€)",fOther);
        addLabeledField(box,"Note",fNotes);
        TextView preview=tv("",13,true);box.addView(preview);
        Button calc=btn("Calcola risultato");calc.setOnClickListener(v->{Double q=num(fQty),p=num(fPrice),co=num(fComm),ta=num(fTax),to=num(fTobin),ot=num(fOther);if(q==null||p==null){preview.setText("Inserisci quantità e prezzo");return;}double gross=q*p,cost=q*pmc,ratio=Math.min(1,q/quantity),buyAlloc=buyFee*ratio,taxes=(ta==null?0:ta)+(to==null?0:to)+(ot==null?0:ot),netPl=gross-cost-buyAlloc-(co==null?0:co)-taxes;preview.setText("Controvalore: "+euro.format(gross)+" €\nP/L lordo: "+euro.format(gross-cost)+" €\nP/L netto: "+euro.format(netPl)+" €");});box.addView(calc);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog ad=new AlertDialog.Builder(this).setTitle("Vendi posizione").setView(scroll).setPositiveButton("REGISTRA VENDITA",null).setNegativeButton("Annulla",null).create();
        ad.setOnShowListener(dd->ad.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            Double q=num(fQty),p=num(fPrice),co=num(fComm),ta=num(fTax),to=num(fTobin),ot=num(fOther);if(q==null||q<=0||q-quantity>0.0000001||p==null||p<0){toast("Quantità o prezzo non validi");return;}
            try{DbHelper.SaleResult r=db.sellPosition(broker,isin,q,p,co==null?0:co,ta==null?0:ta,to==null?0:to,ot==null?0:ot,fDate.getText().toString().trim(),fNotes.getText().toString());toast("Vendita registrata • P/L netto "+euro.format(r.plNet)+" €");ad.dismiss();showManualPortfolioEditor(broker);}catch(Exception ex){toast(ex.getMessage());}
        }));
        ad.show();
    }

    boolean backupLooksValid(String text){
        if(text==null||text.trim().length()<12)return false;
        String clean=text.replace("\r","").trim();
        if(clean.startsWith("SEZIONE;"))return clean.contains("MESE;");
        if(!clean.startsWith("PORTAFOGLIO2026_"))return false;
        return clean.contains("\nPORTFOLIO;")||clean.contains("\nINCOME;")||clean.contains("\nSNAPSHOT;")||clean.contains("\nPAC;")||clean.contains("\nPOSITION;")||clean.contains("\nSTATUS;")||clean.contains("\nMOVEMENT;")||clean.contains("\nCOST;")||clean.contains("\nTRADE;")||clean.contains("\nSTATEMENT;")||clean.contains("\nANNUAL;");
    }

    String backupSummary(String text){
        String[] lines=text==null?new String[0]:text.replace("\r","").split("\n");
        LinkedHashSet<String> portfolios=new LinkedHashSet<>();
        int incomes=0,positions=0,pacs=0,snapshots=0,movements=0,costs=0,trades=0,statements=0;
        for(String line:lines){
            if(line==null||line.trim().isEmpty())continue;
            String[] a=line.split(";",-1);
            if(a.length==0)continue;
            if(a[0].equals("PORTFOLIO")&&a.length>=2)portfolios.add(a[1]);
            else if(a[0].equals("INCOME")){incomes++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("POSITION")){positions++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("PAC")){pacs++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("SNAPSHOT")){snapshots++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("MOVEMENT")){movements++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("COST")){costs++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("TRADE")){trades++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("STATEMENT")){statements++;if(a.length>=2)portfolios.add(a[1]);}
        }
        String names=portfolios.isEmpty()?"non rilevati":android.text.TextUtils.join(", ",portfolios);
        return "Portafogli: "+names+"\nPosizioni: "+positions+" • Proventi: "+incomes+" • PAC: "+pacs+" • Snapshot: "+snapshots+"\nMovimenti: "+movements+" • Costi/imposte: "+costs+" • Operazioni chiuse: "+trades+" • Estratti registrati: "+statements;
    }

    void confirmImport(){
        if(!backupLooksValid(pendingImport)){
            new AlertDialog.Builder(this).setTitle("Backup non valido").setMessage("Il file selezionato è vuoto o non contiene una struttura di backup riconoscibile. Nessun dato è stato modificato.").setPositiveButton("OK",null).show();
            return;
        }
        String summary=backupSummary(pendingImport);
        new AlertDialog.Builder(this).setTitle("Verifica backup").setMessage(summary+"\n\nSostituisci ripristina l'intera app. Prima della sostituzione verrà creato automaticamente un backup di sicurezza interno. Se l'importazione fallisce, tutte le modifiche vengono annullate e i dati attuali restano invariati.").setPositiveButton("Sostituisci",(d,w)->importBackupSafely(true)).setNeutralButton("Aggiungi",(d,w)->importBackupSafely(false)).setNegativeButton("Annulla",null).show();
    }

    boolean hasEmergencyBackup(){return new File(getFilesDir(),"backup_pre_import.csv").exists();}

    void saveEmergencyBackup(){
        try(FileOutputStream fos=openFileOutput("backup_pre_import.csv",MODE_PRIVATE)){
            fos.write(buildCsv().getBytes(StandardCharsets.UTF_8));
        }catch(Exception ignored){}
    }

    void restoreEmergencyBackup(){
        File f=new File(getFilesDir(),"backup_pre_import.csv");
        if(!f.exists()){toast("Nessun backup di sicurezza disponibile");return;}
        try(FileInputStream is=new FileInputStream(f)){
            ByteArrayOutputStream bo=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);
            pendingImport=bo.toString("UTF-8");
            if(!backupLooksValid(pendingImport)){toast("Backup di sicurezza non valido");return;}
            new AlertDialog.Builder(this).setTitle("Backup di sicurezza").setMessage(backupSummary(pendingImport)+"\n\nVuoi ripristinare questo backup interno?").setPositiveButton("Ripristina",(d,w)->importBackupSafely(false,true)).setNegativeButton("Annulla",null).show();
        }catch(Exception e){toast("Errore lettura backup di sicurezza: "+e.getMessage());}
    }

    void importBackupSafely(boolean replace){importBackupSafely(replace,false);}

    void importBackupSafely(boolean replace,boolean emergencySource){
        if(!backupLooksValid(pendingImport)){toast("Backup non valido: nessun dato modificato");return;}
        if(replace&&!emergencySource)saveEmergencyBackup();
        android.database.sqlite.SQLiteDatabase sql=db.getWritableDatabase();
        String error=null;
        sql.beginTransaction();
        try{
            if(replace||emergencySource)db.clearTablesOnly();
            parseImportOrThrow(pendingImport);
            sql.setTransactionSuccessful();
        }catch(Exception e){error=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
        finally{sql.endTransaction();}
        if(error!=null){
            new AlertDialog.Builder(this).setTitle("Ripristino annullato").setMessage("Il backup contiene un errore e non è stato applicato. I dati presenti prima dell'operazione sono rimasti invariati.\n\nDettaglio: "+error).setPositiveButton("OK",null).show();
        }else{
            db.normalizeKnownNetIncomeModes();
            db.normalizeKnownHistoricalIncomeTypes();
            toast((replace||emergencySource)?"Backup ripristinato correttamente":"Backup aggiunto correttamente");
            showHome();
        }
    }

    String esc(String s){return s==null?"":s.replace(";",",").replace("\n"," ");}
    String val(Double d){return d==null?"":String.valueOf(d);}
    String buildCsv(){
        StringBuilder s=new StringBuilder();s.append("PORTAFOGLIO2026_V3421;10\n");s.append("SETTING;tax_rate;").append(db.getTaxRate()).append("\n");
        Cursor ports=db.portfolios();while(ports.moveToNext()){
            s.append("PORTFOLIO;").append(esc(ports.getString(ports.getColumnIndexOrThrow("name")))).append(";").append(ports.getInt(ports.getColumnIndexOrThrow("active"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("pac_default"))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("broker_profile")))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("buy_commission_type")))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("buy_commission_value"))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("sell_commission_type")))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("sell_commission_value"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("commission_min"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("commission_max"))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("fiscal_regime")))).append("\n");
        }ports.close();
        Cursor c=db.incomes(null);while(c.moveToNext()){int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";s.append("INCOME;").append(esc(c.getString(c.getColumnIndexOrThrow("date")))).append(";").append(c.getInt(c.getColumnIndexOrThrow("month"))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("broker")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("category")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("instrument")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("isin")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("income_type")))).append(";").append(c.getDouble(c.getColumnIndexOrThrow("gross"))).append(";").append(c.getDouble(c.getColumnIndexOrThrow("tax_rate"))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("notes")))).append(";").append(esc(mode)).append("\n");}c.close();
        for(String b:db.portfolioNames(false)){Cursor r=db.snapshots(b);while(r.moveToNext())s.append("SNAPSHOT;").append(esc(b)).append(";").append(r.getInt(r.getColumnIndexOrThrow("month"))).append(";").append(val(getNullable(r,"initial_value"))).append(";").append(val(getNullable(r,"final_value"))).append(";").append(val(getNullable(r,"deposits"))).append(";").append(val(getNullable(r,"withdrawals"))).append(";").append(esc(r.getString(r.getColumnIndexOrThrow("notes")))).append(";").append(val(getNullable(r,"initial_invested"))).append(";").append(val(getNullable(r,"initial_cash"))).append(";").append(val(getNullable(r,"final_invested"))).append(";").append(val(getNullable(r,"final_cash"))).append("\n");r.close();Cursor pr=db.pacs(b);while(pr.moveToNext())s.append("PAC;").append(esc(b)).append(";").append(pr.getInt(pr.getColumnIndexOrThrow("month"))).append(";").append(val(getNullable(pr,"planned"))).append(";").append(val(getNullable(pr,"external_actual"))).append(";").append(val(getNullable(pr,"internal_actual"))).append(";").append(esc(pr.getString(pr.getColumnIndexOrThrow("notes")))).append("\n");pr.close();}
        Cursor pos=db.allPositions();while(pos.moveToNext()){int bi=pos.getColumnIndex("buy_fee"),ti=pos.getColumnIndex("ticker"),ci=pos.getColumnIndex("category");double buyFee=bi>=0&&!pos.isNull(bi)?pos.getDouble(bi):0;String ticker=ti>=0&&!pos.isNull(ti)?pos.getString(ti):"",cat=ci>=0&&!pos.isNull(ci)?pos.getString(ci):"";s.append("POSITION;").append(esc(pos.getString(pos.getColumnIndexOrThrow("broker")))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("isin")))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("instrument")))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("quantity"))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("price"))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("current_value"))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("source_date")))).append(";").append(val(getNullable(pos,"pmc"))).append(";").append(buyFee).append(";").append(esc(ticker)).append(";").append(esc(cat)).append("\n");}pos.close();
        Cursor st=db.portfolioStatuses();while(st.moveToNext())s.append("STATUS;").append(esc(st.getString(st.getColumnIndexOrThrow("broker")))).append(";").append(val(getNullable(st,"invested"))).append(";").append(val(getNullable(st,"cash"))).append(";").append(esc(st.getString(st.getColumnIndexOrThrow("source_date")))).append(";").append(esc(st.getString(st.getColumnIndexOrThrow("source")))).append(";").append(val(getNullable(st,"total_value"))).append("\n");st.close();
        Cursor mv=db.allMovements();while(mv.moveToNext())s.append("MOVEMENT;").append(esc(mv.getString(mv.getColumnIndexOrThrow("date")))).append(";").append(mv.getInt(mv.getColumnIndexOrThrow("month"))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("broker")))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("movement_type")))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("flow_class")))).append(";").append(mv.getDouble(mv.getColumnIndexOrThrow("amount"))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("notes")))).append("\n");mv.close();
        Cursor costs=db.allCosts();while(costs.moveToNext())s.append("COST;").append(esc(costs.getString(costs.getColumnIndexOrThrow("date")))).append(";").append(costs.getInt(costs.getColumnIndexOrThrow("month"))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("broker")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("cost_kind")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("cost_type")))).append(";").append(costs.getDouble(costs.getColumnIndexOrThrow("amount"))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("instrument")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("isin")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("notes")))).append("\n");costs.close();
        Cursor tr=db.allTrades();while(tr.moveToNext())s.append("TRADE;").append(esc(tr.getString(tr.getColumnIndexOrThrow("date")))).append(";").append(tr.getInt(tr.getColumnIndexOrThrow("month"))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("broker")))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("trade_type")))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("isin")))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("instrument")))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("quantity"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("price"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("gross_amount"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("cost_basis"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("buy_fee_allocated"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("commission"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("taxes"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("net_amount"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("realized_pl_gross"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("realized_pl_net"))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("notes")))).append("\n");tr.close();
        Cursor si=db.allStatementImports();while(si.moveToNext())s.append("STATEMENT;").append(esc(si.getString(si.getColumnIndexOrThrow("broker")))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("statement_date")))).append(";").append(si.getInt(si.getColumnIndexOrThrow("month"))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("file_hash")))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("source_name")))).append(";").append(val(getNullable(si,"invested"))).append(";").append(val(getNullable(si,"cash"))).append(";").append(val(getNullable(si,"total_value"))).append(";").append(si.getInt(si.getColumnIndexOrThrow("positions_count"))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("imported_at")))).append("\n");si.close();
        Cursor ah=db.annualHistory();while(ah.moveToNext())s.append("ANNUAL;").append(ah.getInt(ah.getColumnIndexOrThrow("year"))).append(";").append(val(getNullable(ah,"gross_income"))).append(";").append(val(getNullable(ah,"net_income"))).append(";").append(val(getNullable(ah,"portfolio_profit"))).append(";").append(val(getNullable(ah,"return_rate"))).append(";").append(esc(ah.getString(ah.getColumnIndexOrThrow("notes")))).append("\n");ah.close();
        return s.toString();
    }

    Double parseD(String s){try{return s==null||s.trim().isEmpty()?null:Double.parseDouble(s.replace(",","."));}catch(Exception e){return null;}}
    void parseImportOrThrow(String text) throws Exception{
        String[] lines=text.replace("\r","").split("\n");
        if(lines.length==0||!backupLooksValid(text))throw new Exception("file vuoto o formato non riconosciuto");
        boolean v2=lines[0].startsWith("SEZIONE;");
        if(v2){importV2(lines);return;}
        int imported=0;
        for(int lineNo=0;lineNo<lines.length;lineNo++){
            String line=lines[lineNo];if(line.trim().isEmpty())continue;
            String[] a=line.split(";",-1);
            try{
                if(a[0].startsWith("PORTAFOGLIO2026_")){continue;}
                if(a[0].equals("SETTING")&&a.length>=3){if(a[1].equals("tax_rate")){Double x=parseD(a[2]);if(x!=null)db.setSettingDouble(a[1],x);}else if(a[1].equals("creator_name")){/* firma incorporata */}imported++;}
                else if(a[0].equals("ANNUAL")&&a.length>=7){Double yr=parseD(a[1]);if(yr!=null){db.saveAnnualHistory((int)Math.round(yr),parseD(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),a[6]);imported++;}}
                else if(a[0].equals("PORTFOLIO")&&a.length>=4){Double pac=parseD(a[3]);String prof=a.length>=5&&!a[4].trim().isEmpty()?a[4]:DbHelper.inferBrokerProfile(a[1]);if(!db.portfolioExists(a[1]))db.addPortfolio(a[1],pac==null?0:pac,prof);else{db.setPortfolioPacDefault(a[1],pac==null?0:pac);db.setBrokerProfile(a[1],prof);}db.setPortfolioActive(a[1],!a[2].equals("0"));if(a.length>=12){String bt=a[5].isEmpty()?"FISSA":a[5],st=a[7].isEmpty()?"FISSA":a[7],fr=a[11].isEmpty()?"Non specificato":a[11];db.saveBrokerFinancialSettings(a[1],bt,parseD(a[6])==null?0:parseD(a[6]),st,parseD(a[8])==null?0:parseD(a[8]),parseD(a[9])==null?0:parseD(a[9]),parseD(a[10])==null?0:parseD(a[10]),fr);}imported++;}
                else if(a[0].equals("MOVEMENT")&&a.length>=8){Double amt=parseD(a[6]);if(amt==null)throw new Exception("importo movimento non valido");db.ensurePortfolio(a[3]);db.addMovement(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],amt,a[7]);imported++;}
                else if(a[0].equals("COST")&&a.length>=10){Double amt=parseD(a[6]);if(amt==null)throw new Exception("importo costo non valido");db.ensurePortfolio(a[3]);db.addCost(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],amt,a[7],a[8],a[9]);imported++;}
                else if(a[0].equals("TRADE")&&a.length>=18){Double q=parseD(a[7]),pr=parseD(a[8]),gross=parseD(a[9]),basis=parseD(a[10]),bfa=parseD(a[11]),co=parseD(a[12]),tax=parseD(a[13]),net=parseD(a[14]),plg=parseD(a[15]),pln=parseD(a[16]);if(q==null||pr==null||gross==null||basis==null||bfa==null||co==null||tax==null||net==null||plg==null||pln==null)throw new Exception("dati operazione non validi");db.ensurePortfolio(a[3]);db.addTradeRecord(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],a[6],q,pr,gross,basis,bfa,co,tax,net,plg,pln,a[17]);imported++;}
                else if(a[0].equals("INCOME")&&a.length>=11){Double g=parseD(a[8]),tr=parseD(a[9]);if(g==null)throw new Exception("importo provento non valido");db.ensurePortfolio(a[3]);String mode=a.length>=12&&!a[11].trim().isEmpty()?a[11]:"LORDO";db.addIncome(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],a[6],a[7],g,tr==null?db.getTaxRate():tr,a[10],mode);imported++;}
                else if(a[0].equals("SNAPSHOT")&&a.length>=8){db.ensurePortfolio(a[1]);if(a.length>=12&&(parseD(a[8])!=null||parseD(a[9])!=null||parseD(a[10])!=null||parseD(a[11])!=null))db.saveSnapshotSplit(a[1],Integer.parseInt(a[2]),parseD(a[8]),parseD(a[9]),parseD(a[10]),parseD(a[11]),parseD(a[5]),parseD(a[6]),a[7]);else db.saveSnapshot(a[1],Integer.parseInt(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),parseD(a[6]),a[7]);imported++;}
                else if(a[0].equals("POSITION")&&a.length>=8){Double q=parseD(a[4]),pr=parseD(a[5]),v=parseD(a[6]),pmc=a.length>=9?parseD(a[8]):null,bf=a.length>=10?parseD(a[9]):0;String ticker=a.length>=11?a[10]:"",cat=a.length>=12?a[11]:"";if(q==null||pr==null||v==null)throw new Exception("dati posizione non validi");db.ensurePortfolio(a[1]);db.savePosition(a[1],new DbHelper.Position(a[2],a[3],q,pmc,pr,v,a[7],bf==null?0:bf,ticker,cat));imported++;}
                else if(a[0].equals("STATUS")&&a.length>=6){db.ensurePortfolio(a[1]);Double total=a.length>=7?parseD(a[6]):null;if(total!=null)db.savePortfolioStatus(a[1],parseD(a[2]),parseD(a[3]),total,a[4],a[5]);else db.savePortfolioStatus(a[1],parseD(a[2]),parseD(a[3]),a[4],a[5]);imported++;}
                else if(a[0].equals("STATEMENT")&&a.length>=11){db.ensurePortfolio(a[1]);Double inv=parseD(a[6]),cash=parseD(a[7]),tot=parseD(a[8]),cnt=parseD(a[9]);db.saveStatementImport(a[1],a[2],Integer.parseInt(a[3]),a[4],a[5],inv,cash,tot,cnt==null?0:(int)Math.round(cnt),a[10]);imported++;}
                else if(a[0].equals("PAC")&&a.length>=7){db.ensurePortfolio(a[1]);db.savePac(a[1],Integer.parseInt(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),a[6]);imported++;}
                else if(a[0].startsWith("PORTAFOGLIO2026_")){/* intestazione */}
                else if(!a[0].trim().isEmpty())throw new Exception("tipo record non riconosciuto: "+a[0]);
            }catch(Exception row){throw new Exception("riga "+(lineNo+1)+": "+row.getMessage());}
        }
        if(imported==0)throw new Exception("nessun dato importabile trovato");
    }

    int monthIndex(String name){for(int i=0;i<months.length;i++)if(months[i].equalsIgnoreCase(name))return i+1;return 0;}
    void importV2(String[] lines){
        for(int i=1;i<lines.length;i++){String[] a=lines[i].split(";",-1);if(a.length<13||!a[0].equals("MESE"))continue;int m=monthIndex(a[1]);if(m==0)continue;String date="2026-"+String.format(Locale.US,"%02d",m)+"-28";String[] cats={"Azioni","ETF","ETP","Certificati"};for(int j=0;j<4;j++){Double g=parseD(a[2+j]);if(g!=null&&g!=0){String type=(j==0||j==1)?"Dividendo":(j==2?"Distribuzione":"Cedola");db.addIncome(date,m,DbHelper.DIRECTA,cats[j],"Import V2","",type,g,db.getTaxRate(),"STORICO AGGREGATO DIRECTA - Importato da V2; data tecnica, non data effettiva di accredito");}}db.saveSnapshot(DbHelper.DIRECTA,m,parseD(a[7]),parseD(a[8]),parseD(a[9]),parseD(a[10]),a[12]);}
        for(int m=1;m<=12;m++)db.savePac(DbHelper.DIRECTA,m,db.getPacDefault(DbHelper.DIRECTA),null,null,"Import V2");
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    interface MonthClickListener { void onMonthClick(int month); }

    public class ChartView extends View {
        double[] data; boolean line; String unit; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); MonthClickListener monthClick;
        public ChartView(Context c,double[] d,boolean l,String u){this(c,d,l,u,null);}
        public ChartView(Context c,double[] d,boolean l,String u,MonthClickListener listener){super(c);data=d;line=l;unit=u;monthClick=listener;p.setTypeface(android.graphics.Typeface.DEFAULT);setPadding(dp(8),dp(10),dp(8),dp(8));setClickable(listener!=null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();p.setColor(Color.rgb(220,224,228));p.setStrokeWidth(dp(1));c.drawLine(dp(28),h-dp(30),w-dp(8),h-dp(30),p);double max=0,min=0;for(double v:data)if(!Double.isNaN(v)){max=Math.max(max,v);min=Math.min(min,v);}double range=max-min;if(range<0.0001)range=1;float left=dp(32),right=w-dp(10),top=dp(15),bottom=h-dp(32),step=(right-left)/12f;
            if(line){p.setColor(Color.rgb(31,126,209));p.setStrokeWidth(dp(3));Path path=new Path();boolean started=false;for(int i=0;i<12;i++){double v=data[i];if(Double.isNaN(v)||v==0&&max>0&&i>0)continue;float x=left+step*(i+0.5f),y=(float)(bottom-(v-min)/range*(bottom-top));if(!started){path.moveTo(x,y);started=true;}else path.lineTo(x,y);c.drawCircle(x,y,dp(3),p);}c.drawPath(path,p);}else{for(int i=0;i<12;i++){double v=data[i];if(Double.isNaN(v))continue;float x=left+step*i+dp(2),bw=step-dp(4);double zeroPos=(0-min)/range;float y0=(float)(bottom-zeroPos*(bottom-top));float y=(float)(bottom-(v-min)/range*(bottom-top));p.setColor(v>=0?Color.rgb(31,126,209):Color.rgb(198,65,65));c.drawRect(x,Math.min(y,y0),x+bw,Math.max(y,y0),p);}}
            p.setColor(Color.rgb(70,78,86));p.setTextSize(dp(9));for(int i=0;i<12;i+=2)c.drawText(months[i].substring(0,3),left+step*i,bottom+dp(18),p);p.setTextSize(dp(9));c.drawText(unit+" max "+shortNum(max),dp(4),dp(11),p);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(monthClick==null)return super.onTouchEvent(e);
            if(e.getAction()==android.view.MotionEvent.ACTION_UP){float left=dp(32),right=getWidth()-dp(10),step=(right-left)/12f;int idx=(int)((e.getX()-left)/step);if(e.getX()>=left&&e.getX()<=right&&idx>=0&&idx<12){performClick();monthClick.onMonthClick(idx+1);return true;}}
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}

        String shortNum(double x){if(Double.isNaN(x))return "-";if(Math.abs(x)>=1000)return String.format(Locale.ITALY,"%.1fk",x/1000.0);return String.format(Locale.ITALY,"%.1f",x);}
    }
}
