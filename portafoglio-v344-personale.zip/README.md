# Portafoglio 2026 V3.4.4 Personale

Versione tecnica 3.4.4 - versionCode 46.

## Novità principali V3.4.4
- aggiornamento del patrimonio direttamente dalla Home;
- inserimento manuale di capitale investito, liquidità e patrimonio totale;
- possibilità di salvare anche solo il patrimonio totale come valore “da separare”;
- importazione PDF resa una modalità opzionale dell’aggiornamento patrimonio, senza riferimento al broker nell’interfaccia;
- gestione manuale delle singole posizioni per ogni portafoglio;
- campi posizione: nome strumento, ISIN/ticker, quantità, PMC e prezzo attuale;
- controvalore automatico = quantità × prezzo attuale;
- capitale di carico = quantità × PMC;
- plus/minusvalenza teorica in euro e percentuale quando il PMC è disponibile;
- il valore delle posizioni può aggiornare automaticamente il capitale investito del portafoglio;
- archivio posizioni accessibile dalla Dashboard del singolo portafoglio;
- backup CSV V3.4.4 aggiornato con PMC e patrimonio totale corrente;
- migrazione database V4 → V5 senza cancellare i dati esistenti.

## Funzioni già mantenute
- più portafogli separati e TOTALE aggregato;
- capitale investito, liquidità e patrimonio totale separati;
- cedole/dividendi, PAC, rendimento mensile e storico annuale;
- gestione portafogli dalla Home e gestione del singolo portafoglio nelle sue Impostazioni;
- importazione PDF “Situazione Patrimoniale” con anteprima e scelta del portafoglio di destinazione;
- compatibilità con backup precedenti V2/V3/V3.1/V3.2/V3.3/V3.4.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

L’app resta uno strumento locale di registrazione e analisi e non fornisce raccomandazioni di investimento.
