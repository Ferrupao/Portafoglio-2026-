# Portafoglio 2026 V3.4.11 Personale

Versione tecnica **3.4.11** - versionCode **53**.

## Novità V3.4.11 - vendite, P/L, commissioni e fiscalità
- ogni posizione ha ora il comando **Vendi** oltre a Modifica ed Elimina;
- supporto alla **vendita totale o parziale**: la quantità residua resta in portafoglio con lo stesso PMC;
- calcolo automatico di **controvalore**, costo di carico, **P/L realizzato lordo** e **P/L realizzato netto**;
- la vendita aggiorna la liquidità quando questa è conosciuta e conserva l'operazione nello **Storico operazioni chiuse**;
- la commissione di acquisto può essere associata alla posizione e viene attribuita proporzionalmente nelle vendite parziali;
- ogni portafoglio ha proprie **commissioni predefinite di acquisto e vendita**, fisse (€) oppure percentuali (%), con eventuale minimo e massimo;
- la commissione proposta resta modificabile sulla singola operazione;
- ogni portafoglio ha un campo **Regime fiscale**: Non specificato, Amministrato, Dichiarativo o Altro;
- nuovo registro **Costi e imposte** con conteggio annuale separato;
- imposte registrabili: **Tobin Tax, imposta su plusvalenza, imposta di bollo, ritenuta estera, imposta su interessi, altre imposte**;
- Dashboard con **Commissioni pagate 2026**, **Imposte pagate 2026**, **P/L realizzato lordo/netto** e **P/L non realizzato**;
- nei Proventi è possibile indicare **Importo lordo** oppure **Importo già netto**: un importo già netto non viene tassato una seconda volta;
- etichetta aggiornata a **Proventi lordi da inizio anno**;
- il Totale aggregato usa anche le posizioni come fallback quando manca uno snapshot patrimoniale, evitando viste globali vuote quando i titoli sono già presenti;
- backup CSV V3.4.11 esteso a commissioni/fiscalità, costi, imposte, commissione acquisto della posizione e operazioni chiuse;
- migrazione automatica dalla V3.4.10 senza cancellare i dati esistenti.

## Motore multi-broker mantenuto
- profilo broker separato dal nome del portafoglio;
- riconoscimento automatico di Trade Republic, Directa, Fineco, Interactive Brokers, DEGIRO, Scalable Capital, eToro e profilo Generico;
- Trade Republic mantiene Round up, Saveback e Pagamenti carta come funzioni specifiche;
- backup completo disponibile solo nelle **Impostazioni generali** e riferito a tutti i portafogli.

## Regole contabili
Ogni euro deve avere una sola natura: capitale esterno, movimento interno, rendimento/premio, commissione, imposta oppure movimento escluso. Dividendi e cedole non diventano nuovo capitale quando vengono reinvestiti. Una vendita non equivale a un prelievo: il controvalore torna in liquidità e solo il P/L rappresenta il risultato economico.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.
