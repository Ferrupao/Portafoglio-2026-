# Portafoglio 2026 V3.2 — versione definitiva

Revisione tecnica: **3.2.4** — versionCode **36**.

Ultimi ritocchi:
- sezione rinominata in **Storico risultati annuali**;
- rimosso il separatore `|` prima del rendimento;
- firma fissa e incorporata nel codice: **by Paolo Ferrucci**.

Restano attive tutte le funzioni collaudate:
- gestione dinamica dei portafogli;
- Directa / Trade Republic / Totale;
- cedole e dividendi;
- rendimento mensile;
- PAC con distinzione tra capitale esterno e liquidità interna;
- storico annuale;
- grafici;
- backup e importazione CSV.

La firma non è modificabile dall'interfaccia, dal database o dai backup.
