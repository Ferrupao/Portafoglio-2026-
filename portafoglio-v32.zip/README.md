# Portafoglio 2026 V3.2 — versione definitiva con avvertenza

Revisione tecnica: **3.2.5** — versionCode **37**.

Dicitura aggiunta nella Home e nelle Impostazioni:

> Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.

Restano invariati:
- firma fissa **by Paolo Ferrucci**;
- storico risultati annuali;
- gestione dinamica dei portafogli;
- cedole/dividendi;
- rendimento;
- PAC con distinzione capitale interno/esterno;
- grafici;
- backup/importazione CSV.

La firma resta incorporata nel codice e non modificabile dall'app.
