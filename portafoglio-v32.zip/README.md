# Portafoglio 2026 V3.2.3 — firma incorporata nel codice

Firma ufficiale:

**by Paolo Ferrucci**

In questa revisione la firma:
- è scritta direttamente nel codice sorgente della Home;
- non esiste come impostazione dell'app;
- non è salvata nel database;
- non viene esportata o importata nei backup CSV;
- non può essere cambiata dall'interfaccia dell'APK.

Per cambiare la firma è necessario modificare il progetto sorgente e generare una nuova build dell'app.

Restano tutte le funzioni della V3.2:
- portafogli dinamici;
- storico guadagni annuali;
- cedole/dividendi;
- rendimento;
- PAC evoluto;
- distinzione liquidità interna/esterna;
- backup CSV.

Versione tecnica: 3.2.3 — versionCode 35.
