# Portafoglio 2026 V3.2.6 — versione per uso personale e distribuzione

Modifiche definitive:
- rimossa la firma grande `by Paolo Ferrucci` dalla parte alta della Home;
- la firma resta nel riquadro informativo in basso;
- lo storico annuale di una nuova installazione parte vuoto;
- nessun utente che installa l'APK riceve i dati personali 2025 del creatore;
- gli anni storici possono essere aggiunti, modificati ed eliminati;
- una cancellazione non viene ricreata automaticamente;
- se durante una modifica si cambia anche l'anno, la vecchia voce viene rimossa correttamente;
- resta l'avvertenza che l'app è uno strumento di registrazione e analisi e non fornisce consulenza.

Versione tecnica: 3.2.6 — versionCode 38.
