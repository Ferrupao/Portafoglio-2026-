# Portafoglio 2026 V3.1

Versione con gestione dinamica dei portafogli.

- nessun limite applicativo fisso al numero di portafogli
- aggiungi / rinomina / archivia / elimina
- rinomina conserva i dati collegati
- archivia esclude dal Totale senza cancellare
- elimina richiede conferma e cancella i dati del portafoglio
- proventi mensili automatici nella schermata Rendimento
- PAC interno distinto dai versamenti esterni
- backup CSV V3.1 e import V2/V3/V3.1
