# Portafoglio 2026 V3.4.2 Personale

Versione tecnica 3.4.2 - versionCode 44.

## Novità V3.4
- importazione PDF “Situazione Patrimoniale” Directa;
- anteprima obbligatoria prima dell’importazione;
- riconoscimento automatico di data, ISIN, strumento, quantità, prezzo, controvalore, totale titoli e liquidità;
- archivio locale delle posizioni importate, consultabile dalla Dashboard;
- Dashboard aggiornata dal PDF senza alterare cedole, PAC, rendimento mensile o storico annuale;
- capitale investito, liquidità e patrimonio totale restano separati;
- backup CSV V3.4 include anche posizioni e stato patrimoniale;
- compatibilità con backup precedenti V2/V3/V3.1/V3.2/V3.3.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

Il parser V3.4 fase 1 è stato progettato sul formato reale Directa “Situazione Patrimoniale” fornito come file di test.


## Correzione V3.4.1
- l'importazione PDF non è più legata al portafoglio Directa;
- prima dell'importazione viene sempre chiesto il portafoglio di destinazione;
- il PDF Directa può quindi aggiornare qualunque portafoglio creato dall'utente;
- l'ultimo import mostrato nelle Impostazioni è quello del portafoglio attualmente selezionato;
- il portafoglio TOTALE resta aggregato e non è una destinazione di importazione.


## Correzione V3.4.2
- pulsante “+ Aggiungi portafoglio” direttamente nella Home;
- creazione di un portafoglio senza dover entrare prima in Directa o in un altro portafoglio;
- nella vista TOTALE, se alcuni portafogli non hanno ancora la separazione investito/liquidità, i valori parziali sono indicati come “noti”;
- nuovo riquadro “Patrimonio da separare” con importo e nomi dei portafogli da completare;
- patrimonio totale invariato e sempre aggregato sui portafogli attivi.
