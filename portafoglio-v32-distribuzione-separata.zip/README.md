# Portafoglio 2026 V3.2 — DISTRIBUZIONE SEPARATA

Questa variante è pensata per essere installata accanto alla versione personale.

## Identità applicazione
- applicationId personale precedente: `it.portafoglio2026.v32`
- applicationId distribuzione: `it.portafoglio2026.v32.distribuzione`
- nome app: **Portafoglio 2026 Distribuzione**
- versione tecnica: **3.2.8**
- versionCode: **40**

## Comportamento
La versione Distribuzione:
- usa un database separato da quello della tua app personale;
- non sovrascrive la tua installazione personale;
- può essere installata contemporaneamente sullo stesso telefono;
- parte vuota per i nuovi utenti;
- non contiene i tuoi dati finanziari personali;
- mantiene la firma ideatore nel riquadro informativo in basso;
- mantiene l'avvertenza sull'uso come strumento di registrazione e analisi.

## Dati iniziali
Nuova installazione:
- un solo portafoglio neutro `Portafoglio 1`;
- patrimonio 0;
- PAC 0;
- nessun provento;
- nessuno storico annuale;
- nessun dato Directa o Trade Republic.

Le due app sono indipendenti: eliminare o modificare dati nella Distribuzione non modifica la versione personale.
