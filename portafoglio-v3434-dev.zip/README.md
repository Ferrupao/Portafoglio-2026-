# Portafoglio 2026 — V3.4.34 DEV

Aggiornamento centrato su storico patrimonio ordinato e Performance con separazione Lordo / Costi-tasse / Netto.

## Novità V3.4.34 DEV
- Storico patrimonio: date sempre ordinate cronologicamente, nessun punto tecnico futuro e asse Y più preciso (es. 110,1k invece di etichette tutte uguali).
- La curva usa la distanza temporale reale tra le date e il tocco seleziona il punto più vicino.
- Restano le tre viste **PATRIMONIO / PERFORMANCE € / PERFORMANCE %** e gli snapshot giornalieri automatici.
- Performance Giorno/Mese/Anno: il valore principale resta **lordo**; se esistono commissioni, costi o tasse compare un riepilogo compatto **Lordo / Costi-tasse / Netto**.
- Il lordo non viene mai ridotto: il netto è mostrato separatamente.
- Anti-duplicazione import e regole colore/grassetto restano attive.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `76`
- versionName: `3.4.34-dev`
- DB_VERSION: `11`
- DB invariato rispetto alla V3.4.33 (`DB_VERSION 11`); nessuna nuova migrazione dati.
- Aggiornamento installabile sopra V3.4.33 con la stessa chiave di firma.
