# Portafoglio 2026 V3.4.8 Personale

Versione tecnica 3.4.8 - versionCode 50.

## Correzione principale V3.4.8
- nel riepilogo patrimoniale manuale l'utente inserisce solo **Valore titoli** e **Liquidità**;
- **Patrimonio totale = Valore titoli + Liquidità** viene calcolato automaticamente;
- il Patrimonio totale non è più un campo modificabile, quindi un vecchio totale salvato non può restare per errore insieme a nuovi valori;
- se esiste un vecchio patrimonio totale senza dettaglio, viene mostrato solo come informazione e sarà sostituito al salvataggio del nuovo riepilogo;
- i campi sono etichettati chiaramente anche quando contengono già un valore;
- restano accettati i formati italiani `6040,22` e `6.040,22`;
- il salvataggio richiede Valore titoli e Liquidità entrambi validi e non negativi;
- il totale viene salvato insieme alle due componenti nello stesso aggiornamento.

## Funzioni mantenute
- portafogli multipli;
- proventi, PAC, rendimento mensile e da inizio anno;
- posizioni con quantità, PMC e prezzo attuale;
- importazione situazione patrimoniale da PDF;
- backup e migrazione CSV;
- firma ideatore incorporata nel codice: by Paolo Ferrucci.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.
