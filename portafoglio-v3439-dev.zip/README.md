# Portafoglio 2026 — V3.4.39 DEV

Aggiornamento dedicato alla chiusura annuale e allo storico patrimoniale.

## Novità V3.4.39 DEV

- Nello Storico annuale **Capitale iniziale 01/01** e **Capitale finale 31/12** sono le prime due voci.
- Aggiunta la voce separata **Perdita / minus registrata**, senza doppio conteggio nel risultato lordo.
- **Recupero fiscale minus**, tasse residue, risultato complessivo e rendimento annuale sono distinti.
- Il rendimento annuale usa capitale iniziale/finale e neutralizza i flussi esterni classificati nell'app.
- Nuovo comando **Chiudi anno**: congela il dato annuale e registra la data di chiusura.
- Alla chiusura, il capitale finale dell'anno passa automaticamente come capitale iniziale dell'anno successivo.
- Un anno chiuso non è modificabile finché non viene usato **Riapri anno**.
- Backup completo aggiornato con i nuovi campi annuali.

## Compatibilità

- applicationId: `it.portafoglio2026.v32`
- versionCode: `81`
- versionName: `3.4.39-dev`
- DB_VERSION: `13`
- Migrazione automatica da DB 12: i dati esistenti restano conservati; i nuovi campi annuali vengono aggiunti senza cancellare lo storico.
