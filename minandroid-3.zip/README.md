# Portafoglio 2026 — Android

App personale per inserire:
- cedole e dividendi mensili;
- valore iniziale/finale del portafoglio;
- versamenti e prelievi esterni;
- rendimento mensile e cumulato;
- dati IncomeShares;
- aliquota fiscale;
- backup CSV.

## Compilazione automatica dell'APK con GitHub

Non serve Android Studio sul PC.

1. Crea/apri il repository GitHub `Portafoglio2026`.
2. Carica **il contenuto della cartella `Portafoglio2026_Android`**, non la cartella esterna.
3. Controlla che nel repository si vedano, tra gli altri:
   - `app/`
   - `.github/workflows/build-apk.yml`
   - `build.gradle`
   - `settings.gradle`
4. Apri la scheda **Actions** su GitHub.
5. Se richiesto, abilita GitHub Actions.
6. Apri il workflow **Build Android APK** e premi **Run workflow**.
7. Quando il workflow diventa verde, aprilo.
8. In fondo alla pagina, nella sezione **Artifacts**, scarica `Portafoglio2026-APK`.
9. Estrai lo ZIP scaricato: dentro trovi `app-debug.apk`.
10. Sul telefono Android consenti, se richiesto, l'installazione da fonti sconosciute per l'app con cui apri l'APK.

## Nota
La build usa Java 17 e Gradle 8.7 su GitHub Actions.
