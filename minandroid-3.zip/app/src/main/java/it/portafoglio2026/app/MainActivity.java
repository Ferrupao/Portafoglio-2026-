package it.portafoglio2026.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;

public class MainActivity extends Activity {
    DbHelper db;
    LinearLayout content;
    TextView title;
    final String[] months={"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"};
    final DecimalFormat euro = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.ITALY));
    final DecimalFormat pct = new DecimalFormat("0.00%", DecimalFormatSymbols.getInstance(Locale.ITALY));

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db=new DbHelper(this);
        buildShell();
        showDashboard();
    }

    TextView tv(String text,int size,boolean bold){
        TextView v=new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(Color.rgb(31,41,55));
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setPadding(dp(4),dp(6),dp(4),dp(6)); return v;
    }

    Button nav(String t){
        Button b=new Button(this); b.setText(t); b.setAllCaps(false); b.setTextSize(12);
        b.setPadding(dp(4),0,dp(4),0);
        return b;
    }

    void buildShell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        title=tv("Portafoglio 2026",22,true); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER_VERTICAL);
        title.setBackgroundColor(Color.rgb(16,42,67)); title.setPadding(dp(18),dp(15),dp(18),dp(15));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(64)));

        ScrollView sc=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(12),dp(12),dp(88));
        sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setBackgroundColor(Color.WHITE);
        Button d=nav("Dashboard"), c=nav("Cedole"), r=nav("Rendimento"), i=nav("Income"), s=nav("Impostazioni");
        d.setOnClickListener(v->showDashboard()); c.setOnClickListener(v->showCoupons()); r.setOnClickListener(v->showReturns());
        i.setOnClickListener(v->showIncome()); s.setOnClickListener(v->showSettings());
        for(Button x:new Button[]{d,c,r,i,s}) nav.addView(x,new LinearLayout.LayoutParams(0,dp(66),1));
        root.addView(nav);
        setContentView(root);
    }

    LinearLayout card(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(12),dp(14),dp(12));
        l.setBackgroundResource(it.portafoglio2026.app.R.drawable.card);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); l.setLayoutParams(p);
        return l;
    }

    void heading(String s){ title.setText(s); content.removeAllViews(); }
    TextView kpi(String label,String value){
        TextView v=tv(label+"\n"+value,19,true); v.setGravity(Gravity.CENTER); v.setPadding(dp(8),dp(12),dp(8),dp(12)); v.setBackgroundResource(R.drawable.card);
        return v;
    }

    void showDashboard(){
        heading("Dashboard 2026");
        double tax=db.getTaxRate(), total=0, stocks=0, etf=0, etp=0, cert=0;
        int monthsWithData=0;
        Cursor c=db.coupons();
        while(c.moveToNext()){
            double s=c.getDouble(c.getColumnIndexOrThrow("stocks"));
            double e=c.getDouble(c.getColumnIndexOrThrow("etf"));
            double p=c.getDouble(c.getColumnIndexOrThrow("etp"));
            double ce=c.getDouble(c.getColumnIndexOrThrow("cert"));
            double calc=s+e+p+ce;
            Double declared=c.isNull(c.getColumnIndexOrThrow("declared"))?null:c.getDouble(c.getColumnIndexOrThrow("declared"));
            double use=(declared!=null && declared>0)?declared:calc;
            if(use>0){ monthsWithData++; total+=use; stocks+=s; etf+=e; etp+=p; cert+=ce; }
        } c.close();

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(kpi("Proventi lordi YTD",euro.format(total)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        row.addView(kpi("Netto stimato",euro.format(total*(1-tax))+" €"),new LinearLayout.LayoutParams(0,-2,1));
        content.addView(row);
        content.addView(kpi("Media mensile", monthsWithData==0?"-":euro.format(total/monthsWithData)+" €"));

        LinearLayout breakdown=card(); breakdown.addView(tv("Ripartizione proventi",17,true));
        addBar(breakdown,"Azioni",stocks,total);
        addBar(breakdown,"ETF",etf,total);
        addBar(breakdown,"ETP",etp,total);
        addBar(breakdown,"Certificati",cert,total);
        content.addView(breakdown);

        LinearLayout perf=card(); perf.addView(tv("Rendimento portafoglio",17,true));
        double cumulative=1.0; boolean any=false;
        Cursor rc=db.returns();
        while(rc.moveToNext()){
            Double r=calcReturn(rc);
            if(r!=null){ cumulative*=1+r; any=true; }
        } rc.close();
        perf.addView(tv("Rendimento cumulato: "+(any?pct.format(cumulative-1):"da compilare"),16,false));
        perf.addView(tv("Formula: Modified Dietz semplificato, come nel file Excel.",13,false));
        content.addView(perf);

        Button exp=new Button(this); exp.setText("Esporta backup CSV"); exp.setAllCaps(false); exp.setOnClickListener(v->exportCsv());
        content.addView(exp);
    }

    void addBar(LinearLayout parent,String label,double v,double total){
        double p=total==0?0:v/total;
        parent.addView(tv(label+": "+euro.format(v)+" €  ("+pct.format(p)+")",14,false));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000); bar.setProgress((int)Math.round(p*1000)); parent.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));
    }

    EditText field(String hint, Double val){
        EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextSize(16); e.setBackgroundResource(R.drawable.input_bg);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        if(val!=null && Math.abs(val)>0.0000001)e.setText(String.valueOf(val));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.setMargins(0,dp(5),0,dp(5)); e.setLayoutParams(p);
        return e;
    }

    Double num(EditText e){
        String s=e.getText().toString().trim().replace(",",".");
        if(s.isEmpty())return null;
        try{return Double.parseDouble(s);}catch(Exception ex){return null;}
    }
    double n(EditText e){ Double v=num(e); return v==null?0:v; }

    void showCoupons(){
        heading("Cedole e dividendi");
        Spinner sp=new Spinner(this); ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months); sp.setAdapter(a); content.addView(sp);
        LinearLayout form=card(); content.addView(form);
        final EditText[] fs=new EditText[5];
        TextView result=tv("",16,true);
        Runnable load=()->{
            form.removeAllViews(); int m=sp.getSelectedItemPosition()+1;
            Cursor c=db.couponForMonth(m);
            double s=0,e=0,p=0,ce=0; Double dec=null;
            if(c.moveToFirst()){
                s=c.getDouble(c.getColumnIndexOrThrow("stocks")); e=c.getDouble(c.getColumnIndexOrThrow("etf"));
                p=c.getDouble(c.getColumnIndexOrThrow("etp")); ce=c.getDouble(c.getColumnIndexOrThrow("cert"));
                if(!c.isNull(c.getColumnIndexOrThrow("declared"))) dec=c.getDouble(c.getColumnIndexOrThrow("declared"));
            } c.close();
            form.addView(tv(months[m-1],18,true));
            fs[0]=field("Azioni €",s); fs[1]=field("ETF €",e); fs[2]=field("ETP €",p); fs[3]=field("Certificati €",ce); fs[4]=field("Totale dichiarato (facoltativo)",dec);
            for(EditText x:fs)form.addView(x);
            Button save=new Button(this); save.setText("Salva mese"); save.setAllCaps(false);
            save.setOnClickListener(v->{
                Double declared=num(fs[4]); db.saveCoupon(m,n(fs[0]),n(fs[1]),n(fs[2]),n(fs[3]),declared);
                double calc=n(fs[0])+n(fs[1])+n(fs[2])+n(fs[3]); double use=declared!=null?declared:calc; double tax=db.getTaxRate();
                result.setText("Totale: "+euro.format(use)+" €   |   Netto stimato: "+euro.format(use*(1-tax))+" €");
                Toast.makeText(this,"Dati salvati",Toast.LENGTH_SHORT).show();
            });
            form.addView(save); form.addView(result);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){load.run();}
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
    }

    void showReturns(){
        heading("Rendimento mensile");
        Spinner sp=new Spinner(this); sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months)); content.addView(sp);
        LinearLayout form=card(); content.addView(form);

        Runnable load=()->{
            form.removeAllViews(); int m=sp.getSelectedItemPosition()+1;
            Double ini=null,fin=null,dep=null,wd=null; String notes="";
            Cursor c=db.returnForMonth(m);
            if(c.moveToFirst()){
                ini=getNullable(c,"initial_value"); fin=getNullable(c,"final_value"); dep=getNullable(c,"deposits"); wd=getNullable(c,"withdrawals");
                int ni=c.getColumnIndexOrThrow("notes"); notes=c.isNull(ni)?"":c.getString(ni);
            } c.close();

            final EditText fIni=field("Valore iniziale conto €",ini), fFin=field("Valore finale conto €",fin),
                    fDep=field("Versamenti esterni €",dep), fWd=field("Prelievi esterni €",wd);
            EditText fNotes=new EditText(this); fNotes.setHint("Note"); fNotes.setText(notes); fNotes.setBackgroundResource(R.drawable.input_bg); fNotes.setMinHeight(dp(60));
            form.addView(tv(months[m-1],18,true)); form.addView(fIni); form.addView(fFin); form.addView(fDep); form.addView(fWd); form.addView(fNotes);
            TextView calc=tv("",16,true);
            Button save=new Button(this); save.setText("Calcola e salva"); save.setAllCaps(false);
            save.setOnClickListener(v->{
                db.saveReturn(m,num(fIni),num(fFin),num(fDep),num(fWd),fNotes.getText().toString());
                Double r=calcReturnValues(num(fIni),num(fFin),num(fDep),num(fWd));
                double gross=getCouponGross(m), flow=(num(fDep)==null?0:num(fDep))-(num(fWd)==null?0:num(fWd));
                Double denom=num(fIni)==null?null:num(fIni)+0.5*flow;
                double net=gross*(1-db.getTaxRate());
                String ys=(denom==null||denom==0)?"-":pct.format(gross/denom);
                String yn=(denom==null||denom==0)?"-":pct.format(net/denom);
                calc.setText("Rendimento mese: "+(r==null?"-":pct.format(r))+"\nYield proventi lordo: "+ys+"\nYield proventi netto: "+yn);
                Toast.makeText(this,"Rendimento salvato",Toast.LENGTH_SHORT).show();
            });
            form.addView(save); form.addView(calc);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){load.run();}
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
    }

    Double getNullable(Cursor c,String col){ int i=c.getColumnIndexOrThrow(col); return c.isNull(i)?null:c.getDouble(i); }

    Double calcReturn(Cursor c){
        return calcReturnValues(getNullable(c,"initial_value"),getNullable(c,"final_value"),getNullable(c,"deposits"),getNullable(c,"withdrawals"));
    }

    Double calcReturnValues(Double ini,Double fin,Double dep,Double wd){
        if(ini==null||fin==null)return null;
        double flow=(dep==null?0:dep)-(wd==null?0:wd);
        double denom=ini+0.5*flow;
        if(denom==0)return null;
        return (fin-ini-flow)/denom;
    }

    double getCouponGross(int month){
        Cursor c=db.couponForMonth(month); double out=0;
        if(c.moveToFirst()){
            double calc=c.getDouble(c.getColumnIndexOrThrow("stocks"))+c.getDouble(c.getColumnIndexOrThrow("etf"))+
                    c.getDouble(c.getColumnIndexOrThrow("etp"))+c.getDouble(c.getColumnIndexOrThrow("cert"));
            int di=c.getColumnIndexOrThrow("declared");
            out=(!c.isNull(di)&&c.getDouble(di)>0)?c.getDouble(di):calc;
        } c.close(); return out;
    }

    void showIncome(){
        heading("IncomeShares");
        Cursor c=db.income();
        double invested=0, dividends=0;
        while(c.moveToNext()){
            String name=c.getString(c.getColumnIndexOrThrow("name"));
            double inv=c.getDouble(c.getColumnIndexOrThrow("invested")), q=c.getDouble(c.getColumnIndexOrThrow("qty")),
                    pmc=c.getDouble(c.getColumnIndexOrThrow("pmc")), div=c.getDouble(c.getColumnIndexOrThrow("dividends"));
            invested+=inv; dividends+=div;
            LinearLayout x=card();
            x.addView(tv(name,17,true));
            x.addView(tv("Capitale: "+euro.format(inv)+" €   •   Q.tà: "+q+"   •   PMC: "+pmc,14,false));
            x.addView(tv("Dividendi cumulati: "+euro.format(div)+" €   •   Yield: "+pct.format(inv==0?0:div/inv),14,false));
            content.addView(x);
        } c.close();
        content.addView(kpi("Totale IncomeShares","Capitale "+euro.format(invested)+" €  |  Dividendi "+euro.format(dividends)+" €"));
    }

    void showSettings(){
        heading("Impostazioni");
        LinearLayout x=card(); x.addView(tv("Aliquota fiscale stimata",17,true));
        EditText rate=field("es. 26",db.getTaxRate()*100); x.addView(rate);
        Button save=new Button(this); save.setText("Salva aliquota"); save.setAllCaps(false);
        save.setOnClickListener(v->{ Double r=num(rate); if(r!=null){db.setTaxRate(r/100.0);Toast.makeText(this,"Aliquota aggiornata",Toast.LENGTH_SHORT).show();}});
        x.addView(save); content.addView(x);
        LinearLayout help=card(); help.addView(tv("Regole di inserimento",17,true));
        help.addView(tv("• Valore conto = titoli + liquidità.\n• Nei versamenti/prelievi indica solo flussi da/verso l'esterno.\n• Gli spostamenti tra liquidità e titoli dello stesso conto non sono flussi esterni.\n• Cedole e dividendi sono mostrati separatamente e non vengono sommati due volte al rendimento.",14,false));
        content.addView(help);
    }

    void exportCsv(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/csv"); i.putExtra(Intent.EXTRA_TITLE,"Portafoglio_2026_backup.csv");
        startActivityForResult(i,41);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==41 && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            try(OutputStream os=getContentResolver().openOutputStream(data.getData())){
                String csv=buildCsv(); os.write(csv.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this,"Backup esportato",Toast.LENGTH_LONG).show();
            }catch(Exception e){Toast.makeText(this,"Errore export: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
    }

    String buildCsv(){
        StringBuilder s=new StringBuilder();
        s.append("SEZIONE;MESE;AZIONI;ETF;ETP;CERTIFICATI;TOTALE_DICHIARATO;VALORE_INIZIALE;VALORE_FINALE;VERSAMENTI;PRELIEVI;RENDIMENTO;NOTE\n");
        for(int m=1;m<=12;m++){
            double st=0,e=0,p=0,ce=0; String dec="";
            Cursor c=db.couponForMonth(m);
            if(c.moveToFirst()){st=c.getDouble(1);e=c.getDouble(2);p=c.getDouble(3);ce=c.getDouble(4);if(!c.isNull(5))dec=String.valueOf(c.getDouble(5));}
            c.close();
            Double ini=null,fin=null,dep=null,wd=null; String note="";
            Cursor r=db.returnForMonth(m);
            if(r.moveToFirst()){ini=getNullable(r,"initial_value");fin=getNullable(r,"final_value");dep=getNullable(r,"deposits");wd=getNullable(r,"withdrawals");int ni=r.getColumnIndexOrThrow("notes");note=r.isNull(ni)?"":r.getString(ni).replace(";"," ");}
            r.close();
            Double rr=calcReturnValues(ini,fin,dep,wd);
            s.append("MESE;").append(months[m-1]).append(";").append(st).append(";").append(e).append(";").append(p).append(";").append(ce).append(";").append(dec).append(";")
                    .append(ini==null?"":ini).append(";").append(fin==null?"":fin).append(";").append(dep==null?"":dep).append(";").append(wd==null?"":wd).append(";")
                    .append(rr==null?"":rr).append(";").append(note).append("\n");
        }
        return s.toString();
    }
}
