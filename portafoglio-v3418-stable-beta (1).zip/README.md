# Portafoglio 2026 V3.4.18 Stable Beta

Versione tecnica **3.4.18** - versionCode **60**.

## Novità V3.4.18
- la sezione **Cedole** viene rinominata **Proventi**;
- classificazione esplicita dei proventi: **Cedole**, **Dividendi**, **Distribuzioni**, **Interessi** e **Altri proventi**;
- la voce **Cedola** è riservata ai **Certificati**; per gli altri strumenti l'app invita a usare Dividendo, Distribuzione o Interesse;
- aggiunta la categoria **Liquidità** nel modulo Proventi, utile per gli interessi sul cash;
- nuovo riquadro **Proventi del mese corrente** con totale del mese e totale annuale;
- nuovo **elenco gennaio-dicembre** con lordo/netto, stato "netto da completare" e numero di movimenti;
- toccando un mese nell'elenco si apre il relativo dettaglio;
- il grafico **Proventi mese per mese** è interattivo: toccando una barra si apre direttamente il dettaglio del mese;
- anche il grafico Proventi nella Dashboard è navigabile verso il mese selezionato;
- dettaglio mensile con suddivisione per tipo di provento e, nel Totale, per portafoglio;
- ogni singolo provento del mese è apribile per vedere data, broker, tipo, categoria, strumento, ISIN, lordo/netto e note;
- correzione della **media mensile proventi**: nel 2026 usa i mesi trascorsi dell'anno, quindi a settembre divide per 9 sia nel singolo portafoglio sia nel Totale;
- mantenuta la gestione dei proventi Directa con **netto da completare** quando imposte/netto non sono noti;
- mantenute tutte le funzioni V3.4.17 di importazione estratti conto: anteprima, sostituzione del solo broker, snapshot mensile, conservazione PMC/commissioni e controllo duplicati SHA-256;
- backup completo identificato come **PORTAFOGLIO2026_V3418** e nome file suggerito V3418;
- stessa firma permanente e stesso `applicationId`, quindi aggiornamento sopra V3.4.17 senza disinstallazione.

## Regola terminologica dei proventi
- **Cedola**: certificati.
- **Dividendo**: azioni ed ETF quando il pagamento è un dividendo/distribuzione assimilata.
- **Distribuzione**: ETP e altri strumenti income quando il pagamento non va chiamato dividendo.
- **Interesse**: liquidità e altri interessi.
- **Altro provento**: casi residui.

## Dati mensili storici
I vecchi proventi recuperati come importi cumulativi/aggregati restano attribuiti al mese in cui erano stati registrati. L'app li segnala; la precisione mese per mese aumenta con i nuovi movimenti registrati/importati.

## Firma stabile
Il progetto usa la stessa chiave release permanente già configurata nei GitHub Actions Secrets. La chiave privata non deve essere pubblicata.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria o servizi di intermediazione.
