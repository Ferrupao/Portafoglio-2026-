# Portafoglio 2026 V3.4.19 Stable Beta

Versione tecnica **3.4.19** - versionCode **61** - database **9**.

## Novità V3.4.19

- corregge la classificazione dei proventi storici aggregati Directa già presenti:
  - Azioni → **Dividendi**;
  - ETF → **Dividendi**;
  - ETP → **Distribuzioni**;
  - Certificati → **Cedole**;
- la composizione mensile usa ora le categorie corrette invece di concentrare gli aggregati in “Altri proventi”;
- i vecchi importi cumulativi/aggregati Directa vengono marcati **Storico aggregato**;
- per questi dati la data viene esplicitamente indicata come **data tecnica**, non necessariamente come data effettiva di accredito;
- la normalizzazione viene eseguita sia all’aggiornamento del database sia dopo il ripristino di vecchi backup;
- corretto anche l’import V2: Azioni/ETF = Dividendo, ETP = Distribuzione, Certificati = Cedola;
- mantiene tutte le funzioni V3.4.18: media mensile YTD corretta, grafico mensile cliccabile, dettaglio mese, import estratti, controllo duplicati e snapshot mensili.

## Aggiornamento

Mantiene lo stesso `applicationId` e la stessa pipeline di firma delle Stable Beta precedenti. È progettata per essere installata sopra la V3.4.18 senza cancellare i dati.

Il backup CSV generato dalla versione è identificato come **PORTAFOGLIO2026_V3419**.
