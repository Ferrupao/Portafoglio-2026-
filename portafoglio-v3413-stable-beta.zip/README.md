# Portafoglio 2026 V3.4.13 Stable Beta

Versione tecnica **3.4.13** - versionCode **55**.

## Obiettivo
Prima versione Stable Beta pensata per test privati con amici e tester. Nessun nome o cognome personale compare nell'interfaccia, nei backup o nella documentazione dell'app.

## Novità V3.4.13
- branding neutro: **Portafoglio 2026 • Stable Beta 3.4.13 • Test privato**;
- nessun dato patrimoniale personale pre-caricato nelle nuove installazioni;
- i profili iniziali Directa e Trade Republic partono con PAC predefinito a **0 €**;
- pulsante **Titoli** con elenco generale, ricerca per nome/ISIN, filtri per categoria, aperte/chiuse e ordinamento;
- categorie della **Ripartizione proventi** cliccabili per aprire direttamente i titoli della categoria;
- scheda titolo con quantità, PMC, prezzo, valore, P/L, proventi, modifica e vendita;
- vendita totale/parziale con P/L realizzato lordo/netto, commissioni e imposte;
- commissioni e fiscalità configurabili per portafoglio;
- registro commissioni/imposte e supporto Tobin Tax, bollo, imposta plusvalenza, ritenuta estera e altre imposte;
- correzione della **media mensile proventi**: usa il periodo effettivamente coperto dai dati, non solo il numero di mesi con movimenti;
- se netto/imposte sono incompleti, la Dashboard mostra **da completare** invece di presentare un netto fittizio;
- riquadro **Dati da completare** con conteggio PMC mancanti e stato del rendimento YTD;
- backup CSV **V3.4.13** compatibile con le versioni precedenti fino alla V3.4.12;
- ripristino transazionale con backup di sicurezza interno prima di una sostituzione.

## Firma stabile
Il progetto è predisposto per una build **release firmata con chiave permanente** tramite variabili d'ambiente/GitHub Actions Secrets. La chiave privata non va inserita nel repository.

Variabili richieste:
- `PORTAFOGLIO_KEYSTORE_FILE`
- `PORTAFOGLIO_KEYSTORE_PASSWORD`
- `PORTAFOGLIO_KEY_ALIAS`
- `PORTAFOGLIO_KEY_PASSWORD`

L'applicationId resta `it.portafoglio2026.v32` per mantenere la continuità dell'app.

## Nota dati
Il PMC, le imposte storiche e gli snapshot mensili non vengono inventati: se mancano, l'app li segnala come dati da completare. Un backup V3.4.12 può essere ripristinato con **SOSTITUISCI**.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.
