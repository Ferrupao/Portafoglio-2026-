# Portafoglio 2026 — V3.4.43 DEV

## Novità V3.4.43 DEV — Storico annuale automatico rifinito
- Il Resoconto annuale è di sola lettura: nessun campo economico viene compilato manualmente nello Storico.
- Per ogni portafoglio e per il Totale vengono calcolati automaticamente titoli a fine anno, liquidità residua, patrimonio totale e relative percentuali.
- Bonifici, versamenti e trasferimenti di denaro non vengono mostrati nel resoconto storico annuale.
- Dividendi e cedole già incassati/netti non subiscono una seconda applicazione automatica del 26%.
- Risultato annuale automatico: proventi incassati − perdite/minus registrate + recuperi fiscali riconosciuti − tasse/costi aggiuntivi non già inclusi.
- Rendimento annuale automatico su base di capitale ponderata: versamenti e prelievi registrati vengono neutralizzati internamente in base alla data, ma non compaiono nel resoconto annuale.
- Stato anno dinamico: anno corrente IN CORSO, anni precedenti DA CHIUDERE, anni chiusi CHIUSO.
- Pulsante “Ricalcola automaticamente” per rigenerare lo storico dopo importazioni o correzioni dei dati originari.
- Chiusura anno: il patrimonio finale totale e dei singoli portafogli viene riportato automaticamente come base iniziale dell’anno successivo.
- I dati storici già presenti (incluso il 2025) restano disponibili come fallback. Se manca una separazione affidabile tra titoli e liquidità, l’app mostra “—” e una nota invece di inventare valori.
- Le percentuali restano solo dove utili: titoli, liquidità, peso del portafoglio e rendimento annuale.
- Directa/Trade Republic mostrano risultato e rendimento solo quando esistono dati economici reali attribuibili al singolo portafoglio; eliminati i falsi 0,00 €.
- Backup e database restano compatibili: nessuna migrazione aggiuntiva e nessuna cancellazione dati.

## Versione tecnica
- versionCode: `85`
- versionName: `3.4.43-dev`
- DB_VERSION: `16`
- applicationId: `it.portafoglio2026.v32`
