# Portafoglio 2026 — V3.4.31 DEV

Aggiornamento UI concentrato su leggibilità, gerarchia dei colori e uso rapido su smartphone.

## Novità V3.4.31 DEV
- Testo principale dell'app in blu scuro e grassetto; eliminato il nero dalle schermate principali.
- Verde riservato a proventi, premi/Saveback, plus e valori positivi.
- Rosso riservato a commissioni, tasse, costi, minus e valori negativi.
- Grafico Composizione patrimonio multicolore: Certificati ambra, ETF azzurro, ETP viola, Azioni blu brillante, Liquidità argento.
- Legenda del patrimonio resa responsive per evitare il taglio di “Certificati”, importi e percentuali.
- Proventi: categorie, mesi e testo descrittivo in blu scuro; solo importi e percentuali in verde.
- Movimenti classificati: riepilogo su righe separate, valori a zero nascosti, Premio/Saveback in verde, costi/esclusi in rosso.
- P/L realizzato lordo ora in grassetto e con valore verde/rosso in base al segno.
- Campi di inserimento e selettori uniformati al blu scuro.
- Database invariato: nessuna migrazione necessaria.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `73`
- versionName: `3.4.31-dev`
- DB_VERSION: `10` invariato
- Aggiornamento installabile sopra V3.4.30 senza disinstallazione, usando la stessa chiave di firma.
