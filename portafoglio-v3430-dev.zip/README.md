# Portafoglio 2026 — V3.4.30 DEV

Aggiornamento UI orientato a semplicità, coerenza visiva e uso rapido su smartphone.

## Novità V3.4.30 DEV
- Interfaccia più essenziale: rimossi i testi esplicativi permanenti dalle principali schermate.
- Informazioni e regole spostate in finestre richiamabili solo quando servono.
- Identità grafica uniformata al blu scuro di Portafoglio 2026; rimossi verde/giallo/azzurro usati come colori decorativi.
- Verde e rosso restano riservati ai valori finanziari positivi e negativi.
- Pulsanti di inserimento/azione non usano più il verde decorativo.
- Asset allocation aggiornata con una palette di sole tonalità blu/grigio-blu.
- Performance: rimossa la spiegazione permanente; aggiunto un solo pulsante informazioni.
- Performance Giorno/Mese/Anno: nessun `0,00 €` in assenza di movimenti; positivi verdi, negativi rossi.
- Corretto il taglio del totale nelle viste Mese e Anno usando contenitori ad altezza dinamica.
- Vista Giorno sempre legata alla data scelta nel calendario, senza fallback all'ultima operazione.
- Vista Anno con soli mesi che hanno movimenti e drill-down Anno → Mese → Giorno.
- Storico aggregato senza data mensile resta nel totale annuo ed è spiegato solo aprendo `ⓘ`.
- Database invariato: nessuna migrazione necessaria.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `72`
- versionName: `3.4.30-dev`
- DB_VERSION: `10` invariato
- Aggiornamento installabile sopra V3.4.29 senza disinstallazione, usando la stessa chiave di firma.
