package it.portafoglio2026.v3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "portafoglio2026_v3.db";
    public static final int DB_VERSION = 1;

    public static final String DIRECTA = "Directa";
    public static final String TR = "Trade Republic";

    public DbHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)");
        db.execSQL("CREATE TABLE income_records ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, category TEXT, instrument TEXT, isin TEXT, income_type TEXT, gross REAL, tax_rate REAL, net REAL, notes TEXT)");
        db.execSQL("CREATE TABLE snapshots ("+
                "broker TEXT, month INTEGER, initial_value REAL, final_value REAL, deposits REAL, withdrawals REAL, notes TEXT, PRIMARY KEY(broker,month))");
        db.execSQL("CREATE TABLE pac_records ("+
                "broker TEXT, month INTEGER, planned REAL, external_actual REAL, internal_actual REAL, notes TEXT, PRIMARY KEY(broker,month))");

        putSetting(db,"tax_rate","0.26");
        putSetting(db,"year","2026");
        putSetting(db,"pac_directa","1131");
        putSetting(db,"pac_tr","183");

        // Storico Directa importato dalla V2 / prospetto 2026 già utilizzato dall'utente.
        insertIncome(db,"2026-01-31",1,DIRECTA,"Azioni","Storico aggregato","","Dividendo",29.21,0.26,"Gennaio 2026");
        insertIncome(db,"2026-01-31",1,DIRECTA,"ETF","Storico aggregato","","Distribuzione ETF",37.09,0.26,"Gennaio 2026");
        insertIncome(db,"2026-01-31",1,DIRECTA,"ETP","Storico aggregato","","Distribuzione ETP",272.03,0.26,"Gennaio 2026");
        insertIncome(db,"2026-01-31",1,DIRECTA,"Certificati","Storico aggregato","","Cedola",897.96,0.26,"Gennaio 2026");

        insertMonth(db,2,0,72.14,943.11,1219.31);
        insertMonth(db,3,36.08,63.20,455.87,616.03);
        insertMonth(db,4,91.80,123.74,398.41,616.03);
        insertMonth(db,5,70.80,226.12,520.20,616.03);
        insertMonth(db,6,542.76,352.93,727.15,616.03);
        insertMonth(db,7,269.45,89.06,572.04,584.78);
        insertMonth(db,8,0,28.16,571.40,435.55);

        // Ultimo snapshot noto, usato solo come base iniziale modificabile.
        insertSnapshot(db,DIRECTA,8,null,110454.0,null,null,"Snapshot iniziale al 31/08/2026");
        insertSnapshot(db,TR,8,null,770.94,null,null,"Snapshot iniziale al 02/09/2026");

        for(int m=1;m<=12;m++){
            insertPac(db,DIRECTA,m,1131.0,null,null,"PAC Directa - finanziamento interno/esterno da compilare");
            insertPac(db,TR,m,183.0,183.0,0.0,"PAC Trade Republic programmato");
        }
    }

    private void insertMonth(SQLiteDatabase db,int month,double stocks,double etf,double etp,double cert){
        String date="2026-"+(month<10?"0":"")+month+"-28";
        if(stocks!=0) insertIncome(db,date,month,DIRECTA,"Azioni","Storico aggregato","","Dividendo",stocks,0.26,"");
        if(etf!=0) insertIncome(db,date,month,DIRECTA,"ETF","Storico aggregato","","Distribuzione ETF",etf,0.26,"");
        if(etp!=0) insertIncome(db,date,month,DIRECTA,"ETP","Storico aggregato","","Distribuzione ETP",etp,0.26,"");
        if(cert!=0) insertIncome(db,date,month,DIRECTA,"Certificati","Storico aggregato","","Cedola",cert,0.26,"");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    private void putSetting(SQLiteDatabase db,String k,String v){
        ContentValues cv=new ContentValues(); cv.put("k",k); cv.put("v",v); db.insert("settings",null,cv);
    }

    private void insertIncome(SQLiteDatabase db,String date,int month,String broker,String category,String instrument,String isin,String type,double gross,double tax,String notes){
        ContentValues cv=new ContentValues();
        cv.put("date",date); cv.put("month",month); cv.put("broker",broker); cv.put("category",category); cv.put("instrument",instrument); cv.put("isin",isin); cv.put("income_type",type);
        cv.put("gross",gross); cv.put("tax_rate",tax); cv.put("net",gross*(1.0-tax)); cv.put("notes",notes);
        db.insert("income_records",null,cv);
    }

    private void insertSnapshot(SQLiteDatabase db,String broker,int month,Double initial,Double fin,Double dep,Double wd,String notes){
        ContentValues cv=new ContentValues(); cv.put("broker",broker); cv.put("month",month);
        putNullable(cv,"initial_value",initial); putNullable(cv,"final_value",fin); putNullable(cv,"deposits",dep); putNullable(cv,"withdrawals",wd); cv.put("notes",notes);
        db.insert("snapshots",null,cv);
    }

    private void insertPac(SQLiteDatabase db,String broker,int month,Double planned,Double ext,Double in,String notes){
        ContentValues cv=new ContentValues(); cv.put("broker",broker); cv.put("month",month); putNullable(cv,"planned",planned); putNullable(cv,"external_actual",ext); putNullable(cv,"internal_actual",in); cv.put("notes",notes);
        db.insert("pac_records",null,cv);
    }

    private static void putNullable(ContentValues cv,String key,Double v){ if(v==null) cv.putNull(key); else cv.put(key,v); }

    public double getSettingDouble(String key,double def){
        Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{key});
        double out=def; if(c.moveToFirst()) try{out=Double.parseDouble(c.getString(0));}catch(Exception ignored){} c.close(); return out;
    }
    public void setSettingDouble(String key,double val){
        ContentValues cv=new ContentValues(); cv.put("v",String.valueOf(val));
        int n=getWritableDatabase().update("settings",cv,"k=?",new String[]{key});
        if(n==0){cv.put("k",key);getWritableDatabase().insert("settings",null,cv);}
    }
    public double getTaxRate(){return getSettingDouble("tax_rate",0.26);}    
    public double getPacDefault(String broker){return broker.equals(TR)?getSettingDouble("pac_tr",183):getSettingDouble("pac_directa",1131);}    

    public long addIncome(String date,int month,String broker,String category,String instrument,String isin,String type,double gross,double tax,String notes){
        ContentValues cv=new ContentValues(); cv.put("date",date);cv.put("month",month);cv.put("broker",broker);cv.put("category",category);cv.put("instrument",instrument);cv.put("isin",isin);cv.put("income_type",type);cv.put("gross",gross);cv.put("tax_rate",tax);cv.put("net",gross*(1-tax));cv.put("notes",notes);
        return getWritableDatabase().insert("income_records",null,cv);
    }
    public void deleteIncome(long id){getWritableDatabase().delete("income_records","id=?",new String[]{String.valueOf(id)});}    
    public Cursor incomes(String broker){
        if(broker==null) return getReadableDatabase().rawQuery("SELECT * FROM income_records ORDER BY date DESC,id DESC",null);
        return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE broker=? ORDER BY date DESC,id DESC",new String[]{broker});
    }
    public Cursor incomesForMonth(String broker,int month){
        if(broker==null) return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE month=? ORDER BY date,id",new String[]{String.valueOf(month)});
        return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE broker=? AND month=? ORDER BY date,id",new String[]{broker,String.valueOf(month)});
    }
    public double sumIncome(String broker,String field){
        String sql=broker==null?"SELECT COALESCE(SUM("+field+"),0) FROM income_records":"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE broker=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double sumIncomeMonth(String broker,int month,String field){
        String sql=broker==null?"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE month=?":"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE broker=? AND month=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?new String[]{String.valueOf(month)}:new String[]{broker,String.valueOf(month)}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double sumCategory(String broker,String category){
        String sql=broker==null?"SELECT COALESCE(SUM(gross),0) FROM income_records WHERE category=?":"SELECT COALESCE(SUM(gross),0) FROM income_records WHERE broker=? AND category=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?new String[]{category}:new String[]{broker,category}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public int monthsWithIncome(String broker){
        String sql=broker==null?"SELECT COUNT(DISTINCT month) FROM income_records WHERE gross<>0":"SELECT COUNT(DISTINCT month) FROM income_records WHERE broker=? AND gross<>0";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker}); int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x;
    }

    public void saveSnapshot(String broker,int month,Double initial,Double fin,Double dep,Double wd,String notes){
        ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);putNullable(cv,"initial_value",initial);putNullable(cv,"final_value",fin);putNullable(cv,"deposits",dep);putNullable(cv,"withdrawals",wd);cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("snapshots",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor snapshot(String broker,int month){return getReadableDatabase().rawQuery("SELECT * FROM snapshots WHERE broker=? AND month=?",new String[]{broker,String.valueOf(month)});}    
    public Cursor snapshots(String broker){return getReadableDatabase().rawQuery("SELECT * FROM snapshots WHERE broker=? ORDER BY month",new String[]{broker});}
    public double latestPortfolioValue(String broker){
        Cursor c=getReadableDatabase().rawQuery("SELECT final_value FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }

    public void savePac(String broker,int month,Double planned,Double ext,Double in,String notes){
        ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);putNullable(cv,"planned",planned);putNullable(cv,"external_actual",ext);putNullable(cv,"internal_actual",in);cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("pac_records",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor pac(String broker,int month){return getReadableDatabase().rawQuery("SELECT * FROM pac_records WHERE broker=? AND month=?",new String[]{broker,String.valueOf(month)});}    
    public Cursor pacs(String broker){return getReadableDatabase().rawQuery("SELECT * FROM pac_records WHERE broker=? ORDER BY month",new String[]{broker});}
    public double sumPacExternal(String broker){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(external_actual),0) FROM pac_records WHERE broker=?",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }

    public void clearTablesOnly(){
        SQLiteDatabase db=getWritableDatabase(); db.delete("income_records",null,null); db.delete("snapshots",null,null); db.delete("pac_records",null,null);
    }

    public void clearAllUserData(){
        SQLiteDatabase db=getWritableDatabase(); db.delete("income_records",null,null); db.delete("snapshots",null,null); db.delete("pac_records",null,null);
        for(int m=1;m<=12;m++){insertPac(db,DIRECTA,m,getPacDefault(DIRECTA),null,null,"");insertPac(db,TR,m,getPacDefault(TR),getPacDefault(TR),0.0,"");}
    }
}
