# Portafoglio 2026 V3

App Android offline per gestione mensile di Directa e Trade Republic.

Funzioni principali:
- Home con Directa / Trade Republic / Totale
- Dashboard con patrimonio, proventi, media e rendimento YTD
- Inserimento cedole/dividendi con lordo, tassazione e netto automatico
- Rendimento mensile con Modified Dietz semplificato sui soli flussi esterni
- PAC con distinzione tra capitale esterno e reinvestimento interno
- Storico mensile e grafici
- Backup CSV V3 e importazione backup V2/V3
- Database SQLite locale

La V3 usa applicationId `it.portafoglio2026.v3`, quindi può essere installata accanto alla V2 senza sovrascriverla. Per migrare i dati: esportare il CSV dalla V2 e importarlo dalla V3.
