# Portafoglio 2026 — V3.4.29 DEV

Aggiornamento della schermata **Performance** orientato all'uso reale su smartphone e alla navigazione temporale in stile Directa.

## Novità V3.4.29 DEV
- Titolo generale semplificato in **Performance**: eliminata la dicitura "Performance lorda" come intestazione della schermata e dai pulsanti di accesso.
- Vista **Giorno** collegata al calendario: all'apertura usa la data odierna, consente selezione diretta della data e navigazione giorno precedente/successivo.
- Nessun ritorno automatico all'ultima operazione registrata: una data senza movimenti resta selezionata ma non mostra alcun importo.
- Regola unica per **Giorno / Mese / Anno**: non viene mai mostrato `0,00 €`; i campi senza movimenti restano vuoti.
- Valori positivi in **verde** e negativi in **rosso**.
- Vista **Mese** con mese/anno selezionabili, frecce avanti/indietro e soltanto le date che hanno movimenti effettivi.
- Vista **Anno** scorrevole mese per mese in stile Directa: compaiono soltanto i mesi con movimenti; ogni mese mostra il totale se diverso da zero ed è cliccabile per entrare nel dettaglio mensile.
- Navigazione coerente **Anno → Mese → Giorno**.
- Gli storici aggregati senza data reale continuano a contribuire soltanto al totale annuale 2026 e non vengono attribuiti artificialmente a giorni o mesi.
- Database invariato: nessuna migrazione necessaria.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `71`
- versionName: `3.4.29-dev`
- DB_VERSION: `10` invariato
- Aggiornamento installabile sopra V3.4.28 senza disinstallazione.
