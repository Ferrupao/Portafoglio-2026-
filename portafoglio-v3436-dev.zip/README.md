# Portafoglio 2026 — V3.4.35 DEV

Aggiornamento centrato su storico patrimonio ordinato e Performance con separazione Lordo / Costi-tasse / Netto.

## Novità V3.4.35 DEV

- Performance € e Performance % ricostruite subito dai movimenti datati già presenti.
- I grafici non dipendono più da almeno due snapshot giornalieri per diventare utili.
- Lo storico aggregato senza data continua a contribuire al totale annuo, ma non viene distribuito artificialmente su giorni o mesi.
- Nella Performance annua, se la copertura fiscale è incompleta, compaiono “Costi/tasse noti” e “Netto noto”.
- Patrimonio e snapshot giornalieri restano separati dalla performance.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `76`
- versionName: `3.4.35-dev`
- DB_VERSION: `11`
- DB invariato rispetto alla V3.4.33 (`DB_VERSION 11`); nessuna nuova migrazione dati.
- Aggiornamento installabile sopra V3.4.33 con la stessa chiave di firma.
