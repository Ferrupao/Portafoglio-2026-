# Portafoglio 2026 V3.4.20 Stable Beta

Versione tecnica **3.4.20** - versionCode **62** - database **10**.

## Novità V3.4.20

- nuovo pulsante **Cerca titolo** dalla home per cercare in tutti i portafogli;
- pulsanti **Cerca titolo** e **Inserisci titolo** direttamente dentro ogni singolo portafoglio;
- ricerca unica e immediata per **nome, ISIN o ticker**;
- aggiunto il campo **Ticker** alle posizioni, conservato anche nei backup;
- aggiunta una **categoria salvata per ogni titolo**, con priorità sulla classificazione automatica;
- **Poste Italiane – IT0003796171** viene riconosciuta automaticamente come **Azioni**;
- la categoria **Altro** è residuale ed è destinata a strumenti non contemplati nelle categorie principali, ad esempio BTP, BOT e obbligazioni;
- se il riconoscimento automatico non riesce a identificare una nuova posizione, l'app chiede di scegliere esplicitamente Azioni, ETF, ETP, Certificati o Altro invece di archiviarla silenziosamente in Altro;
- l'importazione degli estratti conserva ticker e categoria già registrati per lo stesso ISIN, oltre a PMC e commissioni;
- backup CSV aggiornato a **PORTAFOGLIO2026_V3420** e compatibile con i backup precedenti.

## Compatibilità

Mantiene lo stesso `applicationId` e la stessa pipeline di firma delle Stable Beta precedenti. È progettata per essere installata sopra la V3.4.19 senza cancellare i dati.

Le nuove installazioni restano prive di dati patrimoniali personali pre-caricati.
