# Portafoglio 2026 — V3.4.33 DEV

Aggiornamento centrato su storico patrimonio, leggibilità dei titoli e import mensili senza duplicazioni.

## Novità V3.4.33 DEV
- Titoli e schede strumenti: testo principale blu scuro e grassetto; P/L positivo verde, P/L negativo rosso; proventi verdi.
- Storico patrimonio ridisegnato con curva/area più morbida e identità Portafoglio 2026.
- Tre viste separate: **PATRIMONIO**, **PERFORMANCE €**, **PERFORMANCE %**.
- L'ultimo punto di **PATRIMONIO** coincide sempre con il Patrimonio totale corrente della Home.
- La **PERFORMANCE** include proventi, P/L realizzato lordo e P/L non realizzato noto, senza trasformare versamenti/prelievi esterni in rendimento.
- I proventi non vengono sommati una seconda volta al patrimonio: se sono già nella liquidità, restano conteggiati una sola volta nel valore reale.
- Snapshot giornalieri automatici per costruire nel tempo una curva reale; i vecchi snapshot mensili restano utilizzabili come base storica.
- Import CSV movimenti con riconciliazione anti-duplicati riga per riga: broker + data + tipo + importo + ISIN/strumento.
- Lo stesso file continua a essere bloccato anche tramite hash SHA-256.
- Backup completo esteso agli snapshot giornalieri.

## Compatibilità
- applicationId: `it.portafoglio2026.v32`
- versionCode: `75`
- versionName: `3.4.33-dev`
- DB_VERSION: `11`
- Migrazione automatica da DB 10: viene aggiunta solo la tabella `daily_snapshots`; i dati esistenti restano invariati.
- Aggiornamento installabile sopra V3.4.32 con la stessa chiave di firma.
