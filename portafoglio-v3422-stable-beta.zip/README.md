# Portafoglio 2026 V3.4.22 Beta Test

Versione tecnica **3.4.22** - versionCode **64** - database **10**.

## Novità V3.4.22 – restyling UI/UX fintech

- nuova palette **navy / bianco / blu / verde**, card arrotondate e gerarchia visiva più moderna;
- nuova **barra di navigazione inferiore**: Home, Portafogli, Cerca, Proventi, Altro;
- Home riorganizzata: **Panoramica → Azioni rapide → Scegli portafoglio → Analisi → Gestione**;
- **Cerca titolo** e **Inserisci titolo** rimangono le azioni più evidenti;
- dashboard portafoglio riorganizzata: **Riepilogo → Posizioni e comandi → Analisi → Grafici**;
- ricerca titoli più pulita, con campo **nome / ISIN / ticker**, filtri a pillola e nota chiara sulla categoria **Altro**;
- risultati titoli in card compatte con nome, ticker/ISIN, categoria, broker, valore e pulsante Apri titolo;
- sezione **Proventi** riorganizzata con riepilogo mese/anno, grafico mensile, composizione e lista mesi;
- la categoria **Altro** resta residuale per BTP, BOT, obbligazioni e strumenti non contemplati;
- nessuna modifica alla logica contabile o ai dati: il database resta **10**.

## Compatibilità

Mantiene lo stesso `applicationId` e la stessa pipeline di firma permanente. È progettata per essere installata sopra la V3.4.21 senza cancellare i dati.

Backup CSV aggiornato a **PORTAFOGLIO2026_V3422** e compatibile con i backup precedenti.
