# Portafoglio 2026 — V3.4.42 DEV

## Novità V3.4.42 DEV
- Resoconto annuale Totale = somma di tutti i portafogli attivi.
- Stato anno dinamico: anno corrente IN CORSO, anni precedenti DA CHIUDERE/CHIUSO.
- Dividendi e cedole annuali trattati come importi incassati: nessuna seconda applicazione automatica del 26%.
- Formula annuale: dividendi/cedole incassati − perdita/minus + recupero fiscale − tasse/costi aggiuntivi non già inclusi.
- Correzione flussi: versamenti/prelievi non vengono mai dedotti dalla differenza fra capitale iniziale e finale.
- Migrazione DB16 ripara il vecchio caso in cui l’intera variazione patrimoniale era stata scambiata per aumento di capitale.
- Rendimento patrimoniale calcolato solo dopo verifica dei flussi esterni reali; se mancano, l’app mostra DA INSERIRE/VERIFICARE e impedisce la chiusura.
- Tutte le percentuali sono calcolate automaticamente.
- Chiusura anno: capitale finale totale e dei singoli portafogli riportato automaticamente all’anno successivo.
- Backup completo compatibile con i dati annuali e il dettaglio per portafoglio.

## Versione tecnica
- versionCode: `84`
- versionName: `3.4.42-dev`
- DB_VERSION: `16`
- applicationId: `it.portafoglio2026.v32`
