# Aggiornamento V3.4.42 DEV — Chiusura annuale e flussi esterni

## Aggiornamento V3.4.42 DEV — Storico annuale automatico

- 🟢 Nessun campo economico manuale nello Storico annuale.
- 🟢 Bonifici, versamenti e trasferimenti non vengono mostrati nel resoconto annuale.
- 🟢 Fotografia automatica di fine anno: titoli, liquidità residua e patrimonio totale, per portafoglio e totale.
- 🟢 Percentuali automatiche: titoli, liquidità, peso portafoglio e rendimento annuale.
- 🟢 Proventi già netti/incassati non subiscono una seconda tassazione al 26%.
- 🟢 Perdita/minus da operazioni registrate, recupero fiscale riconosciuto dai movimenti e costi/imposte alimentano automaticamente il risultato; i valori storici già salvati restano disponibili come fallback.
- 🟢 Rendimento annuale = risultato complessivo / capitale iniziale disponibile, senza usare i bonifici come guadagno.
- 🟢 Chiusura anno automatica e riporto del patrimonio finale come capitale iniziale dell'anno successivo.


- ✅ Capitale iniziale e capitale finale restano in testa.
- ✅ Versamenti/aumenti di capitale e prelievi separati e neutralizzati nel rendimento.
- ✅ Variazione patrimonio mostrata come dato neutro, non come guadagno.
- ✅ Risultato investimenti in euro calcolato automaticamente da capitale e flussi.
- ✅ Rendimento annuale automatico con ponderazione temporale dei flussi datati (Modified Dietz); quota non datata ponderata a metà anno.
- ✅ Tutte le percentuali calcolate dall’app, nessun input percentuale manuale.
- ✅ Tasse annuali basate sui movimenti fiscali noti; rimossa la stima automatica fissa del 26%.
- ✅ Form annuale con etichette permanenti e anteprima live dei calcoli.
- ✅ Backup annuale esteso a versamenti e prelievi.

# Roadmap MASTER – Portafoglio 2026

**Stato aggiornato con V3.4.42 DEV**


## V3.4.38 DEV
- ✅ Storico mensile: colorazione positiva/negativa applicata alla singola voce anche quando Lordo e Netto hanno lo stesso importo.
- ✅ Netto mensile: se non risultano imposte e il netto storico è assente, viene ricostruito dal lordo invece di mostrare 0,00 €.
- ✅ Storico annuale automatico: risultato lordo, recupero fiscale minusvalenze, tasse stimate/residue, risultato complessivo e rendimento %.
- ✅ Recupero fiscale minusvalenze separato e sommato al risultato complessivo secondo la logica concordata.
- ✅ Backup aggiornato per conservare i nuovi campi annuali.

## V3.4.37 DEV

- ✅ Quotazioni certificati protette: uso del **BID/denaro** quando il book è disponibile; nessun aggiornamento automatico con ultimo contratto/prezzo di riferimento potenzialmente obsoleto.
- ✅ Protezione anti-anomalia sui certificati: scarti estremi rispetto al prezzo già presente non vengono applicati automaticamente.
- ✅ Storico mensile: **Lordo / Netto / Netto noto / Rendimento** verdi se positivi e rossi se negativi; Patrimonio e PAC restano neutri.
- ✅ Righe 0,00 € inutili nello Storico non vengono più mostrate quando non c’è un risultato finanziario da rappresentare.
- ✅ Storico annuale: proventi, P/L e rendimento con la stessa semantica verde/rosso.
- ✅ Prezzo titolo mostrato con formato monetario completo (es. 79,20 €).

## V3.4.36 DEV

- ✅ Nuova identità grafica dark fintech coerente in tutta l’app: navy profondo, card blu, testo chiaro, verde/rosso solo per significato finanziario.
- ✅ Movimenti uniformati: Round up = **CAPITALE PROPRIO** (neutro), Saveback = **PREMIO** (verde), costi/commissioni/tasse in rosso.
- ✅ Storico Performance: distinzione esplicita tra **curva datata**, **storico aggregato non datato** e **Performance YTD complessiva** senza inventare date.
- ✅ Quotazioni automatiche gratuite: tentativo una volta al giorno e pulsante manuale **Aggiorna**, senza API key o abbonamenti; fonte pubblica Borsa Italiana/Euronext.
- ✅ Aggiornamento prezzo → valore posizione → P/L non realizzato → valore titoli/patrimonio → snapshot giornaliero.
- ✅ Protezione fallback: se una quotazione non viene trovata, il prezzo già presente non viene sovrascritto.
- ✅ Normalizzazione ISIN anomali (es. prefisso interno prima dell’ISIN reale) per la ricerca quotazioni.


## V3.4.35 DEV

- Performance € / % ricostruita dai movimenti datati già presenti, senza attendere nuovi snapshot.
- Storico aggregato non datato conservato nel totale annuo senza attribuzione artificiale a giorni o mesi.
- Performance annua: etichette “Costi/tasse noti” e “Netto noto” quando la copertura fiscale non è completa.


## V3.4.34 DEV

- Storico patrimonio: correzione ordine cronologico, eliminazione punti futuri e asse Y con maggiore precisione.
- Performance Giorno/Mese/Anno: lordo invariato; Costi/tasse e Netto mostrati separatamente quando presenti.
- Storico patrimonio separato in **PATRIMONIO / PERFORMANCE € / PERFORMANCE %**.
- Ultimo valore patrimonio sincronizzato con il totale corrente della Home.
- Performance con proventi inclusi, P/L realizzato lordo e P/L non realizzato noto; versamenti/prelievi esterni non sono rendimento.
- Snapshot giornalieri automatici e backup dedicato.
- Import CSV movimenti con riconciliazione riga per riga anti-duplicati.
- Schede titoli: testo blu scuro in grassetto, proventi verdi, P/L verde/rosso.

Principio guida: Portafoglio 2026 è un gestore semplice e intuitivo del portafoglio personale. Il centro dell'app è la contabilità di titoli, patrimonio, proventi, tasse, costi, acquisti, vendite e plus/minusvalenze. Le quotazioni servono soltanto ad aggiornare il valore del patrimonio e il P/L.

| Area | Stato | Situazione attuale / obiettivo |
|---|---|---|
| Multi-portafoglio / multi-broker | ✅ Fatto | Directa e Trade Republic separati, con totale complessivo |
| Titoli / liquidità / patrimonio | ✅ Fatto / evoluzione | Gestione del patrimonio e delle posizioni realmente possedute |
| Titoli / Posizioni | ✅ Fatto / evoluzione | Ricerca nome/ISIN/ticker; categorie principali; broker e totale |
| Dettaglio titolo | 🟡 Da completare | Quantità, PMC, valore, P/L, proventi, storico operazioni, tasse/costi collegati |
| Quotazioni automatiche | ✅ V3.4.37 DEV / evoluzione | Aggiornamento gratuito da Borsa Italiana/Euronext per valore patrimonio/P&L; fallback al prezzo esistente se non disponibile |
| Vendite e P/L realizzato | 🟡 In evoluzione | Vendita totale/parziale, commissioni, imposte, lordo e netto |
| Codifica colori | ✅ V3.4.37 DEV | Proventi/plus/risultati positivi verdi; costi/tasse/minus/perdite rossi |
| Performance | 🔵 V3.4.32 DEV | Giorno con calendario reale; Mese/Anno selezionabili; Anno scorrevole mese per mese; nessun 0,00 €; solo periodi con movimenti; verde positivo e rosso negativo; storici aggregati senza data reale solo nel totale annuo |
| Proventi | 🟡 Priorità centrale | Cedole, dividendi, distribuzioni, interessi e altri proventi con lordo/tasse/netto |
| Classificazione automatica proventi | ✅ Presente | Certificati→Cedola; Azioni→Dividendo; ETF/ETP→Distribuzione; Liquidità→Interesse |
| Netto noto YTD | 🔵 V3.4.32 DEV | Se lo storico fiscale è incompleto, mostra solo il netto noto e la copertura del lordo |
| Proventi mese per mese | 🟡 In evoluzione | Totale mensile/annuale, lordo/netto, grafico e dettaglio mese |
| Contabilità fiscale semplificata | 🟡 In evoluzione | Imposte trattenute, imposte vendite, Tobin Tax, bollo/altre imposte |
| Costi e commissioni | 🟡 In evoluzione | Costi separati da proventi/rendimento; configurazione per broker |
| Operazioni / Movimenti | ✅ Presente / evoluzione | Acquisti, vendite, movimenti, commissioni, imposte e storico |
| Composizione patrimonio | ✅ V3.4.36 DEV | Semicerchio blu scuro, palette blu/grigio-blu, categorie cliccabili con importo e percentuale |
| Grafici secondari | ✅ Compatti | In fondo alle schermate come corredo |
| Importazione estratti conto | 🟡 In sviluppo | PDF broker → posizioni, patrimonio e progressiva automazione dei movimenti |
| Snapshot mensili broker | 🟡 In sviluppo | Aggiornamento broker senza sommare erroneamente vecchie posizioni |
| Controllo duplicati import | 🟡 In sviluppo | Evitare doppie importazioni dello stesso estratto |
| Storico estratti / patrimonio | 🟡 Previsto | Conservare storico mensile anche quando lo snapshot corrente viene aggiornato |
| PAC | 🟡 Da integrare meglio | Gestione PAC e riconoscimento più automatico dagli acquisti/import |
| Copertura PAC con proventi | 🟡 Previsto | Confrontare proventi netti incassati e versamenti PAC |
| Storico annuale | 🟡 Presente in parte | Lordo, netto, tasse, utile/perdita e rendimento anno per anno |
| Backup / ripristino | ✅ Presente / da testare | Backup completo e aggiornamenti in-place |
| Migrazione database | 🟡 Controllo continuo | Nessuna perdita dati tra versioni |
| Semplicità e UX smartphone | ✅ V3.4.36 DEV / evoluzione | Pochi passaggi, caratteri leggibili, pulsanti chiari, automazione |
| Nome commerciale / identità | 🔵 Fase successiva | Dopo verifica disponibilità |
| Beta test | 🔵 In corso | Tester su V3.4.23; sviluppo DEV sul telefono principale |
| QA commerciale | 🔵 Prima della pubblicazione | Installazione, backup, import, contabilità, usabilità, crash |
| Multi-broker esteso | 🔵 Successivo | Solo dopo robustezza Directa/Trade Republic |
| Versione Pro / monetizzazione | 🔵 Successivo | Dopo automazione, affidabilità, sicurezza e onboarding |

## Fuori roadmap
News, segnali operativi, RSI/indicatori, screener, idee di trading e raccomandazioni di acquisto/vendita non sono il centro del prodotto.


### V3.4.32 DEV
Interfaccia semplificata: meno spiegazioni permanenti, blu scuro coerente, verde/rosso solo per semantica finanziaria, Performance con totali non tagliati e info su richiesta.

### V3.4.32 DEV
- Regola tipografica: testo principale blu scuro e grassetto; niente nero nelle schermate principali.
- Semantica colori: verde positivo/proventi/premi; rosso costi/tasse/perdite.
- Asset allocation multicolore e legenda responsive.
- Proventi e Movimenti ripuliti con gerarchia colore coerente.


## V3.4.32 DEV
- Performance tabs mobile-safe: GIORNO/MESE/ANNO sempre leggibili su una riga.
- Nuovo Storico patrimonio personalizzato: linea/area interattiva, palette asset allocation, periodi YTD/1M/6M/1A/MAX, vista €/% e tooltip.
- Regole colore/tipografia consolidate: blu scuro bold neutro, verde positivo/proventi, rosso costi/tasse/negativi.


## V3.4.42 DEV — correzione chiusura annuale
- Dividendi/cedole annuali come importi incassati.
- Minus/perdite sottratte prima del recupero fiscale.
- Flussi esterni mai derivati dalla variazione patrimonio; chiusura bloccata finché non sono verificati.
- Migrazione DB16 del caso legacy V3.4.40/V3.4.41.
- Passaggio automatico del capitale finale all’anno successivo preservato per Totale e singoli portafogli.
