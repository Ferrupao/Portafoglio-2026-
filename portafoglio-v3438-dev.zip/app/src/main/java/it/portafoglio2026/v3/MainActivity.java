package it.portafoglio2026.v3;

import android.app.*;
import android.os.Bundle;
import android.os.Build;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Settings;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    DbHelper db;
    LinearLayout content, menuGrid, bottomNav;
    TextView title, subtitle, navHome, navPortfolios, navOperations, navIncome, navMore;
    String current = "HOME";
    final String TOTAL = "Totale";
    final String[] months={"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"};
    final String[] categories={"Azioni","ETF","ETP","Certificati","Altro"};
    final String[] incomeCategories={"Azioni","ETF","ETP","Certificati","Liquidità","Altro"};
    final String[] incomeTypes={"Dividendo","Cedola","Distribuzione","Interesse","Altro provento"};
    final String[] brokerProfiles={"Riconoscimento automatico","Trade Republic","Directa","Fineco","Interactive Brokers","DEGIRO","Scalable Capital","eToro","Altro / Generico"};
    final String[] genericMovementTypes={"Versamento personale","Prelievo","Trasferimento interno","PAC","Acquisto","Vendita","Altro"};
    final String[] tradeRepublicMovementTypes={"Versamento personale","Prelievo","Trasferimento interno","PAC","Acquisto","Vendita","Round up","Saveback","Pagamento carta (escluso dall’analisi)","Altro"};
    final DecimalFormat euro = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.ITALY));
    final DecimalFormat pct = new DecimalFormat("0.00%", DecimalFormatSymbols.getInstance(Locale.ITALY));
    String pendingImport="";
    DirectaImport pendingDirectaImport;
    String pendingImportPortfolio="";
    String pendingStatementHash="", pendingStatementName="";

    final int C_NAVY=Color.rgb(5,43,79);
    final int C_BLUE=Color.rgb(52,132,244);
    final int C_GREEN=Color.rgb(38,222,148);
    final int C_RED=Color.rgb(255,79,88);
    final int C_BG=Color.rgb(3,32,61);
    final int C_TEXT=Color.rgb(244,249,255);
    final int C_MUTED=Color.rgb(183,207,231);
    final int C_LINE=Color.rgb(35,83,128);
    final int C_NAV_INACTIVE=Color.rgb(215,231,247);
    final int C_DARK_SURFACE=Color.rgb(6,47,87);
    final int C_DARK_ROW=Color.rgb(11,70,116);
    final int C_DARK_MUTED=Color.rgb(199,220,239);
    final int C_GOLD=Color.rgb(231,166,31);
    final int C_PURPLE=Color.rgb(139,84,226);
    final int C_CYAN=Color.rgb(18,176,218);

    static class ImportedIncome {
        String date="",category="Altro",instrument="",isin="",type="Altro provento",notes=""; double gross=0;
    }
    static class ImportedCost {
        String date="",kind="COMMISSIONE",type="Altro costo",instrument="",isin="",notes=""; double amount=0;
    }
    static class ImportedMovement {
        String date="",type="Movimento",flowClass="INTERNO",notes=""; double amount=0;
    }
    static class DirectaImport {
        String date=""; Double cash=null, invested=null, printedInvested=null; String parser="";
        boolean positionsAuthoritative=true;
        List<DbHelper.Position> positions=new ArrayList<>();
        List<ImportedIncome> incomes=new ArrayList<>();
        List<ImportedCost> costs=new ArrayList<>();
        List<ImportedMovement> movements=new ArrayList<>();
    }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        PDFBoxResourceLoader.init(getApplicationContext());
        db=new DbHelper(this);
        db.normalizeKnownNetIncomeModes();
        db.normalizeKnownHistoricalIncomeTypes();
        db.captureDailySnapshot(currentDate());
        buildShell();
        showHome();
        maybeAutoRefreshQuotes();
    }

    TextView tv(String text,int size,boolean bold){
        TextView v=new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(C_TEXT);
        v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        v.setPadding(dp(4),dp(6),dp(4),dp(6));
        v.setLineSpacing(0f,1.08f);
        return v;
    }

    Button btn(String text){
        Button b=new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(16); b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(50)); b.setTextColor(C_TEXT);
        b.setBackgroundResource(R.drawable.btn_secondary); b.setElevation(0f);
        b.setPadding(dp(10),dp(6),dp(10),dp(6));
        return b;
    }


    Button primaryBtn(String text){Button b=btn(text);b.setTextColor(Color.WHITE);b.setBackgroundResource(R.drawable.btn_primary);return b;}
    Button successBtn(String text){return primaryBtn(text);}
    Button ghostBtn(String text){Button b=btn(text);b.setBackgroundResource(R.drawable.btn_ghost);b.setTextColor(C_TEXT);return b;}
    TextView muted(String text,int size){TextView v=tv(text,size,false);v.setTextColor(C_MUTED);v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.NORMAL);return v;}
    Button infoBtn(){Button b=ghostBtn("ⓘ");b.setTextSize(16);b.setMinHeight(dp(44));b.setPadding(dp(4),0,dp(4),0);return b;}
    TextView sectionTitle(String text){TextView v=tv(text,19,true);v.setPadding(dp(2),dp(2),dp(2),dp(8));return v;}
    void gap(ViewGroup p,int h){Space sp=new Space(this);if(p instanceof LinearLayout && ((LinearLayout)p).getOrientation()==LinearLayout.HORIZONTAL)p.addView(sp,new LinearLayout.LayoutParams(dp(h),1));else p.addView(sp,new LinearLayout.LayoutParams(1,dp(h)));}
    LinearLayout hrow(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    TextView badge(String text){TextView v=tv(text,11,true);v.setTextColor(C_TEXT);v.setGravity(Gravity.CENTER);v.setBackgroundResource(R.drawable.badge);v.setPadding(dp(10),dp(4),dp(10),dp(4));return v;}
    TextView kpi(String label,String value){
        TextView v=tv(label+"\n"+value,17,true);v.setGravity(Gravity.START);v.setPadding(dp(12),dp(12),dp(12),dp(12));v.setBackgroundResource(R.drawable.card_soft);v.setMinHeight(dp(76));return v;
    }
    TextView kpiPrimary(String label,String value){
        TextView v=tv(label+"\n"+value,19,true);v.setGravity(Gravity.START);v.setPadding(dp(12),dp(11),dp(12),dp(11));v.setBackgroundResource(R.drawable.card_soft);v.setMinHeight(dp(82));return v;
    }
    TextView kpiValueColor(String label,String value,int valueColor){
        String full=label+"\n"+value;SpannableString span=new SpannableString(full);int start=label.length()+1;
        if(start<full.length())span.setSpan(new ForegroundColorSpan(valueColor),start,full.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView v=tv("",17,true);v.setText(span);v.setGravity(Gravity.START);v.setPadding(dp(12),dp(12),dp(12),dp(12));v.setBackgroundResource(R.drawable.card_soft);v.setMinHeight(dp(78));return v;
    }
    TextView kpiSigned(String label,Double value){
        if(value==null)return kpi(label,"PMC mancanti");
        return kpiValueColor(label,euro.format(value)+" €",value>0?C_GREEN:(value<0?C_RED:C_TEXT));
    }
    TextView signedText(String text,double value,int size,boolean bold){
        TextView v=tv(text,size,bold);v.setTextColor(value>0?C_GREEN:(value<0?C_RED:C_TEXT));return v;
    }
    TextView financeText(String text,int size,int amountColor,boolean colorPercentages){
        SpannableString span=new SpannableString(text);
        Matcher am=Pattern.compile("[-+]?\\d[\\d.,]*\\s*€").matcher(text);
        while(am.find())span.setSpan(new ForegroundColorSpan(amountColor),am.start(),am.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if(colorPercentages){
            Matcher pm=Pattern.compile("[-+]?\\d[\\d.,]*%").matcher(text);
            while(pm.find())span.setSpan(new ForegroundColorSpan(amountColor),pm.start(),pm.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        TextView v=tv("",size,true);v.setText(span);return v;
    }
    TextView financeTextSigned(String label,double value,int size){
        return financeText(label+euro.format(value)+" €",size,value>0?C_GREEN:(value<0?C_RED:C_TEXT),false);
    }
    TextView financePercentText(String label,double value,int size){
        String text=label+pct.format(value);SpannableString span=new SpannableString(text);int start=label.length();if(start<text.length())span.setSpan(new ForegroundColorSpan(value>0?C_GREEN:(value<0?C_RED:C_TEXT)),start,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);TextView v=tv("",size,true);v.setText(span);return v;
    }
    void colorExactValue(SpannableString sp,String text,String token,int color){int at=text.indexOf(token);if(at>=0)sp.setSpan(new ForegroundColorSpan(color),at,at+token.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
    void colorValueAfterLabel(SpannableString sp,String text,String label,String token,int color){int l=text.indexOf(label);if(l<0)return;int at=text.indexOf(token,l+label.length());if(at>=0)sp.setSpan(new ForegroundColorSpan(color),at,at+token.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
    TextView historyMonthFinanceText(double value,double gross,double net,boolean incomplete,double knownNet,double taxes,double pac,Double r){
        StringBuilder sb=new StringBuilder();sb.append("Patrimonio: ").append(value==0?"-":euro.format(value)+" €");
        double shownNet=incomplete?knownNet:net;String netLabel=incomplete?"Netto noto":"Netto";
        if(!incomplete&&Math.abs(gross)>0.0001&&Math.abs(shownNet)<0.0001)shownNet=gross-Math.max(0,taxes);
        if(Math.abs(gross)>0.0001||Math.abs(shownNet)>0.0001)sb.append("\nLordo: ").append(euro.format(gross)).append(" € | ").append(netLabel).append(": ").append(euro.format(shownNet)).append(" €");
        if(Math.abs(pac)>0.0001)sb.append("\nPAC programmato: ").append(euro.format(pac)).append(" €");
        sb.append("\nRendimento: ").append(r==null?"-":pct.format(r));
        String text=sb.toString();SpannableString sp=new SpannableString(text);
        if(Math.abs(gross)>0.0001)colorValueAfterLabel(sp,text,"Lordo: ",euro.format(gross)+" €",gross>0?C_GREEN:C_RED);
        if(Math.abs(shownNet)>0.0001)colorValueAfterLabel(sp,text,netLabel+": ",euro.format(shownNet)+" €",shownNet>0?C_GREEN:C_RED);
        if(r!=null){String rt=pct.format(r);colorValueAfterLabel(sp,text,"Rendimento: ",rt,r>0?C_GREEN:(r<0?C_RED:C_TEXT));}
        TextView v=tv("",14,true);v.setText(sp);return v;
    }
    TextView historyAnnualFinanceText(String text,Double grossIncome,Double netIncome,Double profit,Double rate,Double recovery,Double taxes,Double overall){
        SpannableString sp=new SpannableString(text);
        if(grossIncome!=null)colorValueAfterLabel(sp,text,"Proventi lordi: ",euro.format(grossIncome)+" €",grossIncome>0?C_GREEN:(grossIncome<0?C_RED:C_TEXT));
        if(netIncome!=null)colorValueAfterLabel(sp,text,"Proventi netti stimati: ",euro.format(netIncome)+" €",netIncome>0?C_GREEN:(netIncome<0?C_RED:C_TEXT));
        if(profit!=null)colorValueAfterLabel(sp,text,"Risultato lordo: ",euro.format(profit)+" €",profit>0?C_GREEN:(profit<0?C_RED:C_TEXT));
        if(recovery!=null&&Math.abs(recovery)>0.0001)colorValueAfterLabel(sp,text,"Recupero fiscale minus: ",euro.format(recovery)+" €",C_GREEN);
        if(taxes!=null&&Math.abs(taxes)>0.0001)colorValueAfterLabel(sp,text,"Tasse stimate/residue: ",euro.format(taxes)+" €",C_RED);
        if(overall!=null)colorValueAfterLabel(sp,text,"Risultato complessivo: ",euro.format(overall)+" €",overall>0?C_GREEN:(overall<0?C_RED:C_TEXT));
        if(profit!=null&&profit<0)colorValueAfterLabel(sp,text,"Minusvalenza generata: ",euro.format(Math.abs(profit))+" €",C_RED);
        if(rate!=null){String rt=pct.format(rate);colorValueAfterLabel(sp,text,"Rendimento: ",rt,rate>0?C_GREEN:(rate<0?C_RED:C_TEXT));}
        TextView v=tv("",13,true);v.setText(sp);return v;
    }
    double annualAutoTaxes(Double result,Double recovery){if(result==null||result<=0.0001)return 0;double rec=recovery==null?0:recovery;if(rec>0.0001)return 0;return result*db.getTaxRate();}
    Double inferAnnualStartingCapital(int year){if(year!=2026)return null;double total=0;boolean found=false;for(String b:db.portfolioNames(true)){Cursor c=db.snapshot(b,1);if(c.moveToFirst()){Double x=getNullable(c,"initial_value");if(x==null){Double inv=getNullable(c,"initial_invested"),cash=getNullable(c,"initial_cash");if(inv!=null||cash!=null)x=(inv==null?0:inv)+(cash==null?0:cash);}if(x!=null&&x>0){total+=x;found=true;}}c.close();}return found?total:null;}
    TextView positionFinanceText(String text,double pl,double income,int size){
        SpannableString span=new SpannableString(text);
        String plText=euro.format(pl)+" €",incomeText=euro.format(income)+" €";
        int p1=text.indexOf("P/L "+plText);if(p1>=0){int start=p1+4;span.setSpan(new ForegroundColorSpan(pl>0?C_GREEN:(pl<0?C_RED:C_TEXT)),start,start+plText.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
        int p2=text.lastIndexOf("Proventi "+incomeText);if(p2>=0){int start=p2+9;span.setSpan(new ForegroundColorSpan(C_GREEN),start,start+incomeText.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
        TextView v=tv("",size,true);v.setText(span);v.setTextColor(C_TEXT);return v;
    }
    TextView positionDetailFinanceText(String text,Double pl,double income,int size){
        SpannableString span=new SpannableString(text);
        if(pl!=null){String x=euro.format(pl)+" €";int at=text.indexOf("P/L non realizzato: "+x);if(at>=0){int st=at+"P/L non realizzato: ".length();span.setSpan(new ForegroundColorSpan(pl>0?C_GREEN:(pl<0?C_RED:C_TEXT)),st,st+x.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}}
        String inc=euro.format(income)+" €";int ai=text.lastIndexOf("Proventi 2026 attribuiti: "+inc);if(ai>=0){int st=ai+"Proventi 2026 attribuiti: ".length();span.setSpan(new ForegroundColorSpan(C_GREEN),st,st+inc.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
        TextView v=tv("",size,true);v.setText(span);return v;
    }
    TextView portfolioCompareText(String broker,double value,double income){
        String valueText=euro.format(value)+" €",incomeText=euro.format(income)+" €";String text=broker+" • "+valueText+" • proventi "+incomeText;SpannableString span=new SpannableString(text);int start=text.lastIndexOf(incomeText);if(start>=0)span.setSpan(new ForegroundColorSpan(C_GREEN),start,start+incomeText.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);TextView v=tv("",13,true);v.setText(span);v.setPadding(dp(4),dp(7),dp(4),dp(7));return v;
    }
    void setToggleStyle(Button b,boolean active){b.setBackgroundResource(active?R.drawable.btn_primary:R.drawable.btn_ghost);b.setTextColor(Color.WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setSingleLine(true);}
    String movementFlowDisplay(String flow,String type){
        if("INTERNO".equalsIgnoreCase(flow) && type!=null && type.toLowerCase(Locale.ITALY).contains("round up"))return "CAPITALE PROPRIO";
        return flow==null?"":flow;
    }
    TextView movementText(String date,String broker,String type,String flow,double amount){
        String displayFlow=movementFlowDisplay(flow,type);
        String text=date+" • "+broker+"\n"+type+" • "+displayFlow+" • "+euro.format(amount)+" €";
        SpannableString span=new SpannableString(text);
        int semantic=C_TEXT;
        if("PREMIO".equalsIgnoreCase(flow))semantic=C_GREEN;
        else if("COSTO".equalsIgnoreCase(flow)||"ESCLUSO".equalsIgnoreCase(flow))semantic=C_RED;
        else if("INTERNO".equalsIgnoreCase(flow))semantic=Color.rgb(116,190,255);
        int secondLine=text.indexOf('\n')+1;
        if(secondLine>0)span.setSpan(new ForegroundColorSpan(semantic),secondLine,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView v=tv("",13,true);v.setText(span);v.setPadding(dp(4),dp(8),dp(4),dp(8));v.setLineSpacing(0f,1.12f);return v;
    }
    String incomeTypeForCategory(String category){
        if(category==null)return "Altro provento";
        if(category.equalsIgnoreCase("Certificati"))return "Cedola";
        if(category.equalsIgnoreCase("Azioni"))return "Dividendo";
        if(category.equalsIgnoreCase("ETF")||category.equalsIgnoreCase("ETP"))return "Distribuzione";
        if(category.equalsIgnoreCase("Liquidità"))return "Interesse";
        return "Altro provento";
    }
    LinearLayout portfolioRow(String name,double value){
        LinearLayout row=hrow();row.setPadding(dp(12),dp(9),dp(10),dp(9));row.setBackgroundResource(R.drawable.card_soft);
        TextView icon=badge(name.length()>0?name.substring(0,1).toUpperCase(Locale.ITALY):"P");row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(38)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);TextView n=tv(name,15,true);n.setPadding(dp(8),0,0,0);TextView val=muted(value==0?"Patrimonio da inserire":euro.format(value)+" €",12);val.setPadding(dp(8),0,0,0);mid.addView(n);mid.addView(val);row.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        TextView che=tv("›",24,true);che.setTextColor(C_BLUE);row.addView(che,new LinearLayout.LayoutParams(dp(30),-2));
        return row;
    }
    TextView navItem(String icon,String label){
        TextView v=tv(icon+"\n"+label,11,true);v.setGravity(Gravity.CENTER);v.setTextColor(C_NAV_INACTIVE);v.setPadding(dp(2),dp(6),dp(2),dp(5));v.setLineSpacing(0f,1.0f);v.setMaxLines(2);v.setClickable(true);v.setFocusable(true);return v;
    }
    void setNavActive(String key){
        TextView[] items={navHome,navPortfolios,navIncome,navOperations,navMore};
        String[] keys={"HOME","PORTFOLIO","INCOME","OPERATIONS","MORE"};
        for(int i=0;i<items.length;i++){
            TextView v=items[i];if(v==null)continue;
            v.setBackgroundColor(Color.TRANSPARENT);v.setTextColor(C_NAV_INACTIVE);v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
            if(keys[i].equals(key)){v.setBackgroundResource(R.drawable.nav_active);v.setTextColor(C_NAVY);v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);} 
        }
    }
    void choosePortfolioDashboard(){
        java.util.List<String> ps=db.portfolioNames(true);if(ps.isEmpty()){toast("Aggiungi prima un portafoglio");return;}
        ArrayList<String> opts=new ArrayList<>(ps);opts.add(TOTAL);String[] a=opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Apri portafoglio").setItems(a,(d,w)->{setPortfolio(a[w]);showDashboard();}).show();
    }
    void showMoreScreen(){
        String scope=current.equals("HOME")?"Tutti i portafogli":current;
        heading("Altro",scope);setNavActive("MORE");
        LinearLayout quickBackup=card();quickBackup.addView(sectionTitle("Backup dati"));Button quickExport=btn("Esporta backup completo");quickExport.setOnClickListener(v->exportCsv());quickBackup.addView(quickExport);content.addView(quickBackup);
        if(current.equals("HOME")){
            LinearLayout manage=card();manage.addView(sectionTitle("Gestione portafogli"));
            Button add=ghostBtn("＋ Aggiungi portafoglio");add.setOnClickListener(v->addPortfolioDialog());manage.addView(add);
            Button upd=ghostBtn("Aggiorna patrimonio");upd.setOnClickListener(v->choosePortfolioForWealthUpdate());manage.addView(upd);
            Button imp=ghostBtn("Importa estratto conto");imp.setOnClickListener(v->showStatementImportCenter());manage.addView(imp);content.addView(manage);
            LinearLayout safety=card();safety.addView(sectionTitle("Dati e sicurezza"));Button settings=ghostBtn("Impostazioni");settings.setOnClickListener(v->showGeneralSettings());safety.addView(settings);Button beta=ghostBtn("Novità DEV 3.4.38");beta.setOnClickListener(v->showBetaNotes());safety.addView(beta);Button appInfo=ghostBtn("Informazioni app");appInfo.setOnClickListener(v->showAppInfo());safety.addView(appInfo);content.addView(safety);
        }else{
            LinearLayout tools=card();tools.addView(sectionTitle("Strumenti portafoglio"));
            Button dashboard=ghostBtn("Dashboard");dashboard.setOnClickListener(v->showDashboard());tools.addView(dashboard);Button perf=primaryBtn("Performance");perf.setOnClickListener(v->showPerformance(1,Calendar.getInstance().get(Calendar.MONTH)+1,null));tools.addView(perf);
            
            Button pac=ghostBtn("PAC");pac.setOnClickListener(v->showPac());tools.addView(pac);
            Button hist=ghostBtn("Storico");hist.setOnClickListener(v->showHistory());tools.addView(hist);
            Button settings=ghostBtn("Impostazioni");settings.setOnClickListener(v->showSettings());tools.addView(settings);content.addView(tools);
        }
    }

    void showMoreMenu(){
        if(current.equals("HOME")){
            String[] a={"Esporta backup completo","Aggiungi portafoglio","Aggiorna patrimonio","Importa estratto conto","Impostazioni","Novità DEV","Avvertenza"};
            new AlertDialog.Builder(this).setTitle("Altro").setItems(a,(d,w)->{
                if(w==0)exportCsv();else if(w==1)addPortfolioDialog();else if(w==2)choosePortfolioForWealthUpdate();else if(w==3)showStatementImportCenter();else if(w==4)showGeneralSettings();else if(w==5)showBetaNotes();
                else new AlertDialog.Builder(this).setTitle("Avvertenza").setMessage("Portafoglio 2026 registra e analizza dati finanziari. Non fornisce consulenza finanziaria né raccomandazioni di investimento.").setPositiveButton("Chiudi",null).show();
            }).show();
        }else{
            String[] a={"Dashboard","Performance","Rendimento","PAC","Storico","Impostazioni"};
            new AlertDialog.Builder(this).setTitle(current+" • Altro").setItems(a,(d,w)->{if(w==0)showDashboard();else if(w==1)showPerformance(1,Calendar.getInstance().get(Calendar.MONTH)+1,null);else if(w==2)showReturns();else if(w==3)showPac();else if(w==4)showHistory();else showSettings();}).show();
        }
    }
    void showBetaNotes(){
        new AlertDialog.Builder(this).setTitle("DEV 3.4.38")
            .setMessage("Storico corretto: tutti i risultati positivi/negativi sono colorati per singola riga, i valori neutri restano bianchi e il Netto non resta a 0 quando mancano solo imposte. Storico annuale: inserisci i dati di base e l’app calcola automaticamente tasse stimate/residue, risultato complessivo e rendimento quando il capitale iniziale è disponibile. Aggiunto Recupero fiscale minusvalenze.")
            .setPositiveButton("Chiudi",null).show();
    }
    void showAppInfo(){
        new AlertDialog.Builder(this).setTitle("Portafoglio 2026")
            .setMessage("Gestione e contabilità del portafoglio personale. Non fornisce consulenza finanziaria, segnali di trading o raccomandazioni di investimento. I dati restano salvati localmente sul dispositivo.")
            .setPositiveButton("Chiudi",null).show();
    }

    void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(C_BG);
        getWindow().setStatusBarColor(C_NAVY);getWindow().setNavigationBarColor(C_NAVY);
        if(Build.VERSION.SDK_INT>=30){root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets x=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(0,x.top,0,x.bottom);return insets;});}else root.setFitsSystemWindows(true);

        LinearLayout top=hrow();top.setPadding(dp(10),dp(4),dp(12),dp(4));top.setBackgroundColor(C_NAVY);
        TextView home=tv("⌂",25,true);home.setGravity(Gravity.CENTER);home.setTextColor(Color.WHITE);home.setBackgroundResource(R.drawable.top_home);home.setOnClickListener(v->showHome());top.addView(home,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setGravity(Gravity.CENTER_VERTICAL);titles.setPadding(dp(10),0,0,0);
        title=tv("Portafoglio 2026",20,true);title.setTextColor(Color.WHITE);title.setPadding(0,0,0,0);
        subtitle=tv("",11,false);subtitle.setTextColor(Color.rgb(210,226,244));subtitle.setPadding(0,0,0,0);
        titles.addView(title);titles.addView(subtitle);top.addView(titles,new LinearLayout.LayoutParams(0,dp(56),1));root.addView(top,new LinearLayout.LayoutParams(-1,dp(64)));

        menuGrid=new LinearLayout(this);menuGrid.setVisibility(View.GONE);

        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setClipToPadding(false);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(12),dp(12),dp(22));sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        bottomNav=hrow();bottomNav.setBackgroundResource(R.drawable.nav_bg);bottomNav.setPadding(dp(6),dp(5),dp(6),dp(6));bottomNav.setElevation(dp(10));
        navHome=navItem("⌂","Home");navHome.setOnClickListener(v->showHome());
        navPortfolios=navItem("▣","Portafoglio");navPortfolios.setOnClickListener(v->{if(current.equals("HOME"))setPortfolio(TOTAL);showPositionsList("Tutti");});
        navIncome=navItem("▥","Proventi");navIncome.setOnClickListener(v->{if(current.equals("HOME"))setPortfolio(TOTAL);showIncome();});
        navOperations=navItem("↕","Movimenti");navOperations.setOnClickListener(v->{if(current.equals("HOME"))setPortfolio(TOTAL);showOperations();});
        navMore=navItem("☰","Altro");navMore.setOnClickListener(v->showMoreScreen());
        for(TextView n:new TextView[]{navHome,navPortfolios,navIncome,navOperations,navMore}){LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(68),1);np.setMargins(dp(3),dp(4),dp(3),dp(4));bottomNav.addView(n,np);}
        root.addView(bottomNav,new LinearLayout.LayoutParams(-1,dp(84)));
        setContentView(root);setNavActive("HOME");root.requestApplyInsets();
    }

    void navigate(String name){
        if(name.equals("Dashboard")) showDashboard(); else if(name.equals("Titoli")) showPositionsList("Tutti"); else if(name.equals("Proventi")) showIncome(); else if(name.equals("Rendimento")) showReturns();
        else if(name.equals("PAC")) showPac(); else if(name.equals("Storico")) showHistory(); else showSettings();
    }

    void heading(String main,String sub){
        title.setText(main); subtitle.setText(sub); content.removeAllViews();
        if(main.equals("Portafoglio 2026"))setNavActive("HOME");
        else if(main.equals("Dashboard")||main.equals("Performance")||main.contains("Cerca titolo")||main.contains("Titoli / Posizioni"))setNavActive("PORTFOLIO");
        else if(main.startsWith("Proventi"))setNavActive("INCOME");
        else if(main.equals("Operazioni")||main.equals("Storico"))setNavActive("OPERATIONS");
        else setNavActive("MORE");
    }
    void setPortfolio(String p){current=p;menuGrid.setVisibility(View.GONE);subtitle.setText(p);}
    String brokerFilter(){return current.equals(TOTAL)?null:current;}

    LinearLayout card(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(13),dp(14),dp(13));l.setBackgroundResource(R.drawable.card);l.setElevation(dp(3));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));l.setLayoutParams(p);return l;
    }

    LinearLayout darkCard(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(13),dp(14),dp(13));
        GradientDrawable bg=new GradientDrawable();bg.setColor(C_DARK_SURFACE);bg.setCornerRadius(dp(18));bg.setStroke(dp(1),Color.rgb(39,78,98));l.setBackground(bg);l.setElevation(dp(3));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));l.setLayoutParams(p);return l;
    }
    TextView darkText(String text,int size,boolean bold){TextView v=tv(text,size,bold);v.setTextColor(Color.WHITE);return v;}
    TextView darkMuted(String text,int size){TextView v=tv(text,size,false);v.setTextColor(C_DARK_MUTED);return v;}

    void showHome(){
        db.captureDailySnapshot(currentDate());
        current="HOME";menuGrid.setVisibility(View.GONE);java.util.List<String> ps=db.portfolioNames(true);
        heading("Portafoglio 2026","DEV 3.4.38 • "+ps.size()+" portafogli attivi");
        double gross=db.sumIncomeActive("gross"),totalValue=db.latestPortfolioValueAllActive();
        int unseparatedCount=db.unseparatedPortfolioCountActive();
        Double titlesValue=unseparatedCount==0?db.latestInvestedValueAllActive():db.knownInvestedValueAllActive();
        Double cash=unseparatedCount==0?db.latestCashValueAllActive():db.knownCashValueAllActive();
        String titlesText=totalValue==0?"non inserito":(titlesValue==null?"non inserito":euro.format(titlesValue)+" €");
        String cashText=totalValue==0?"non inserita":(cash==null?"non inserita":euro.format(cash)+" €");

        double incomeTaxes=db.sumIncomeTaxesActive();Double totalPl=unrealizedPl(null);boolean netIncomplete=db.hasIncompleteNetActive();
        LinearLayout overview=card();overview.addView(sectionTitle("Panoramica"));
        LinearLayout r1=hrow();
        TextView patrimonioKpi=kpiPrimary("Patrimonio totale",totalValue==0?"non inserito":euro.format(totalValue)+" €");
        r1.addView(patrimonioKpi,new LinearLayout.LayoutParams(0,-2,1));gap(r1,6);
        TextView plKpi=kpiSigned("P/L non realizzato",totalPl);
        plKpi.setClickable(true);plKpi.setFocusable(true);plKpi.setOnClickListener(v->{if(totalPl==null)showMissingPmcPositions();else{setPortfolio(TOTAL);showPositionsList("Tutti");}});
        r1.addView(plKpi,new LinearLayout.LayoutParams(0,-2,1));overview.addView(r1);
        gap(overview,6);LinearLayout r2=hrow();r2.addView(kpiValueColor("Proventi lordi YTD",euro.format(gross)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));gap(r2,6);r2.addView(kpiValueColor("Tasse proventi YTD",euro.format(incomeTaxes)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));overview.addView(r2);
        gap(overview,6);LinearLayout r3=hrow();r3.addView(kpi("Valore titoli",titlesText),new LinearLayout.LayoutParams(0,-2,1));gap(r3,6);r3.addView(kpi("Liquidità",cashText),new LinearLayout.LayoutParams(0,-2,1));overview.addView(r3);
        if(netIncomplete)overview.addView(muted("Netto YTD parziale.",11));
        content.addView(overview);

        addPortfolioCompositionCard(null,totalValue,cash);
        addQuoteUpdateCard();

        LinearLayout primary=card();primary.addView(sectionTitle("Azioni rapide"));
        LinearLayout ar=hrow();Button search=primaryBtn("⌕  Cerca titolo");search.setOnClickListener(v->{setPortfolio(TOTAL);showPositionsList("Tutti");});Button insert=successBtn("＋  Inserisci titolo");insert.setOnClickListener(v->choosePortfolioForPositionEntry());
        ar.addView(search,new LinearLayout.LayoutParams(0,dp(56),1));gap(ar,6);ar.addView(insert,new LinearLayout.LayoutParams(0,dp(56),1));primary.addView(ar);content.addView(primary);

        LinearLayout choose=card();choose.addView(sectionTitle("Scegli portafoglio"));
        for(String name:ps){LinearLayout row=portfolioRow(name,db.latestPortfolioValue(name));row.setOnClickListener(v->{setPortfolio(name);showDashboard();});choose.addView(row,new LinearLayout.LayoutParams(-1,-2));gap(choose,6);}
        LinearLayout total=portfolioRow("Totale",totalValue);total.setOnClickListener(v->{setPortfolio(TOTAL);showDashboard();});choose.addView(total);content.addView(choose);

        if(unseparatedCount>0){java.util.List<String> pending=new ArrayList<>();for(String b:ps)if(!db.isPortfolioFullySeparated(b)&&db.latestPortfolioValue(b)!=0)pending.add(b);LinearLayout note=card();note.addView(sectionTitle("Dati da completare"));note.addView(muted("Da completare: "+android.text.TextUtils.join(", ",pending)+". Il patrimonio totale resta comunque disponibile.",12));content.addView(note);}

        LinearLayout analysis=card();analysis.addView(sectionTitle("Riepilogo storico"));Double ytd=calcYtdReturn(null);
        if(ytd==null)analysis.addView(muted("Rendimento reale: disponibile quando snapshot e flussi sono completi.",12));else analysis.addView(kpi("Rendimento da inizio anno",pct.format(ytd)));
        Cursor ah=db.annualHistory();int shown=0;StringBuilder hist=new StringBuilder();while(ah.moveToNext()&&shown<3){int yr=ah.getInt(ah.getColumnIndexOrThrow("year"));Double gi=getNullable(ah,"gross_income"),pp=getNullable(ah,"portfolio_profit"),rr=getNullable(ah,"return_rate");if(hist.length()>0)hist.append("\n");hist.append(yr);if(gi!=null)hist.append(" • proventi ").append(euro.format(gi)).append(" €");if(pp!=null)hist.append(" • P/L ").append(euro.format(pp)).append(" €");if(rr!=null)hist.append(" • ").append(pct.format(rr));shown++;}ah.close();analysis.addView(muted(shown==0?"Storico anni precedenti: nessun dato inserito.":hist.toString(),12));Button perf=primaryBtn("Performance  ›");perf.setOnClickListener(v->{setPortfolio(TOTAL);showPerformance(1,Calendar.getInstance().get(Calendar.MONTH)+1,null);});analysis.addView(perf);content.addView(analysis);
        
    }

    void quickEntry(){
        final java.util.List<String> ps=db.portfolioNames(true); if(ps.isEmpty()){toast("Aggiungi prima un portafoglio");return;}
        final String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio").setItems(names,(d,which)->{
            String broker=names[which]; setPortfolio(broker);
            final String[] opts={"Provento","Aggiorna patrimonio","Rendimento mensile","PAC"};
            new AlertDialog.Builder(this).setTitle(broker+" – Altre operazioni rapide").setItems(opts,(d2,x)->{if(x==0)showIncome();else if(x==1)showWealthUpdateOptions(broker);else if(x==2)showReturns();else showPac();}).show();
        }).show();
    }

    void showDashboard(){
        if(current.equals("HOME")){showHome();return;}heading("Dashboard",current);
        String broker=brokerFilter();double gross=broker==null?db.sumIncomeActive("gross"):db.sumIncome(broker,"gross"),net=broker==null?db.sumIncomeActive("net"):db.sumIncome(broker,"net");int nmonths=ytdMonthsElapsed();
        double value=current.equals(TOTAL)?db.latestPortfolioValueAllActive():db.latestPortfolioValue(current);boolean totalView=current.equals(TOTAL);int unseparatedCount=totalView?db.unseparatedPortfolioCountActive():0;
        Double titlesValue=totalView?(unseparatedCount==0?db.latestInvestedValueAllActive():db.knownInvestedValueAllActive()):db.latestInvestedValue(current);Double cash=totalView?(unseparatedCount==0?db.latestCashValueAllActive():db.knownCashValueAllActive()):db.latestCashValue(current);
        String titlesText=value==0?"non inserito":(titlesValue==null?"non inserito":euro.format(titlesValue)+" €"),cashText=value==0?"non inserita":(cash==null?"non inserita":euro.format(cash)+" €");

        LinearLayout summary=card();summary.addView(sectionTitle("Riepilogo portafoglio"));LinearLayout r1=hrow();r1.addView(kpi("Valore titoli",titlesText),new LinearLayout.LayoutParams(0,-2,1));gap(r1,6);r1.addView(kpi("Liquidità",cashText),new LinearLayout.LayoutParams(0,-2,1));summary.addView(r1);gap(summary,6);LinearLayout r2=hrow();r2.addView(kpi("Patrimonio totale",value==0?"non inserito":euro.format(value)+" €"),new LinearLayout.LayoutParams(0,-2,1));gap(r2,6);r2.addView(kpiValueColor("Proventi lordi YTD",euro.format(gross)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));summary.addView(r2);Button perf=primaryBtn("Performance  ›");perf.setOnClickListener(v->showPerformance(1,Calendar.getInstance().get(Calendar.MONTH)+1,null));summary.addView(perf);content.addView(summary);

        if(!current.equals(TOTAL)){
            int pcnt=db.positionCount(current);LinearLayout pos=card();pos.addView(sectionTitle("Posizioni"));String sd=db.statusDate(current);double posValue=db.sumPositionsCurrentValue(current);Double cost=db.sumPositionsCostBasis(current);String details=pcnt+" strumenti"+(sd.isEmpty()?"":" • aggiornamento "+sd);if(pcnt>0)details+="\nValore attuale titoli: "+euro.format(posValue)+" €";if(cost!=null){double pl=posValue-cost;double pr=Math.abs(cost)<0.000001?0:pl/cost;details+="\nP/L: "+euro.format(pl)+" € ("+pct.format(pr)+")";}else if(pcnt>0)details+="\nCompleta il PMC per calcolare il P/L.";pos.addView(muted(details,12));
            LinearLayout a1=hrow();Button s1=primaryBtn("⌕ Cerca titolo");s1.setOnClickListener(v->showPositionsList("Tutti"));Button s2=successBtn("＋ Inserisci titolo");s2.setOnClickListener(v->positionEditDialog(current,null,null,null,null,null,null,null));a1.addView(s1,new LinearLayout.LayoutParams(0,dp(56),1));gap(a1,6);a1.addView(s2,new LinearLayout.LayoutParams(0,dp(56),1));pos.addView(a1);gap(pos,6);
            LinearLayout a2=hrow();Button imp=ghostBtn("Importa estratto conto");imp.setOnClickListener(v->startStatementImport(current));Button manual=ghostBtn("Aggiornamento manuale");manual.setOnClickListener(v->showManualPortfolioEditor(current));a2.addView(imp,new LinearLayout.LayoutParams(0,dp(54),1));gap(a2,6);a2.addView(manual,new LinearLayout.LayoutParams(0,dp(54),1));pos.addView(a2);
            if(pcnt>0){gap(pos,8);pos.addView(tv("Principali posizioni",14,true));Cursor c=db.positions(current);int k=0;while(c.moveToNext()&&k<3){String name=c.getString(c.getColumnIndexOrThrow("instrument"));double val=c.getDouble(c.getColumnIndexOrThrow("current_value"));TextView line=tv(name+"\n"+euro.format(val)+" €",12,false);line.setBackgroundResource(R.drawable.list_row);line.setPadding(dp(10),dp(8),dp(10),dp(8));pos.addView(line);gap(pos,4);k++;}c.close();}
            content.addView(pos);
        }else{
            LinearLayout actions=card();actions.addView(sectionTitle("Azioni rapide"));LinearLayout r=hrow();Button se=primaryBtn("⌕ Cerca titolo");se.setOnClickListener(v->showPositionsList("Tutti"));Button ins=successBtn("＋ Inserisci titolo");ins.setOnClickListener(v->choosePortfolioForPositionEntry());r.addView(se,new LinearLayout.LayoutParams(0,dp(56),1));gap(r,6);r.addView(ins,new LinearLayout.LayoutParams(0,dp(56),1));actions.addView(r);content.addView(actions);
        }

        boolean netIncomplete=broker==null?db.hasIncompleteNetActive():db.hasIncompleteNet(broker);double knownNet=broker==null?db.sumKnownNetActive():db.sumKnownNet(broker);double commissions=db.sumCosts(broker,"COMMISSIONE"),otherTaxes=db.sumCosts(broker,"IMPOSTA"),incomeTaxes=broker==null?db.sumIncomeTaxesActive():db.sumIncomeTaxes(broker),realGross=db.sumRealized(broker,"realized_pl_gross"),realNet=db.sumRealized(broker,"realized_pl_net");Double unreal=unrealizedPl(broker),ytd=calcYtdReturn(broker);
        LinearLayout analysis=card();analysis.addView(sectionTitle("Contabilità"));LinearLayout ar1=hrow();ar1.addView(kpiValueColor(netIncomplete?"Netto noto proventi":"Proventi netti",euro.format(netIncomplete?knownNet:net)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));gap(ar1,6);ar1.addView(kpiValueColor("Tasse registrate",euro.format(incomeTaxes)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));analysis.addView(ar1);gap(analysis,6);LinearLayout ar2=hrow();ar2.addView(kpiValueColor("Commissioni 2026",euro.format(commissions)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));gap(ar2,6);ar2.addView(kpiValueColor("Altre imposte 2026",euro.format(otherTaxes)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));analysis.addView(ar2);gap(analysis,6);TextView unrealKpi=kpiSigned("P/L non realizzato",unreal);unrealKpi.setClickable(true);unrealKpi.setFocusable(true);unrealKpi.setOnClickListener(v->{if(unreal==null)showMissingPmcPositions();else showPositionsList("Tutti");});analysis.addView(unrealKpi);gap(analysis,6);analysis.addView(kpiSigned("P/L realizzato netto",realNet));analysis.addView(financeTextSigned("P/L realizzato lordo: ",realGross,13));if(ytd!=null)analysis.addView(financePercentText("Rendimento YTD: ",ytd,12));if(netIncomplete)analysis.addView(muted("Netto proventi parziale.",11));content.addView(analysis);

        int missingPmc=broker==null?db.missingPmcCountActive():db.missingPmcCount(broker);if(missingPmc>0||netIncomplete||ytd==null){LinearLayout todo=card();todo.addView(sectionTitle("Dati da completare"));String msg="";if(missingPmc>0)msg+="• PMC mancanti: "+missingPmc+"\n";if(netIncomplete)msg+="• Proventi netti/imposte incompleti\n";if(ytd==null)msg+="• Rendimento YTD: servono snapshot/flussi completi";todo.addView(muted(msg.trim(),12));if(missingPmc>0){Button complete=ghostBtn("Apri Titoli e completa PMC");complete.setOnClickListener(v->showMissingPmcPositions());todo.addView(complete);}content.addView(todo);}

        LinearLayout breakdown=card();breakdown.addView(sectionTitle("Composizione proventi"));for(String cat:categories)addBar(breakdown,cat,broker==null?db.sumCategoryActive(cat):db.sumCategory(broker,cat),gross);content.addView(breakdown);

        if(totalView&&unseparatedCount>0){java.util.List<String> pending=new ArrayList<>();for(String b:db.portfolioNames(true))if(!db.isPortfolioFullySeparated(b)&&db.latestPortfolioValue(b)!=0)pending.add(b);LinearLayout info=card();info.addView(sectionTitle("Completa i dati"));info.addView(muted("Da completare: "+android.text.TextUtils.join(", ",pending)+".",12));content.addView(info);}
        if(current.equals(TOTAL)){LinearLayout split=card();split.addView(sectionTitle("Confronto portafogli"));for(String b:db.portfolioNames(true))split.addView(portfolioCompareText(b,db.latestPortfolioValue(b),db.sumIncome(b,"gross")));content.addView(split);}

        LinearLayout chart=card();chart.addView(sectionTitle("Proventi mese per mese"));chart.addView(new ChartView(this,monthlyIncome(broker),false,"€",m->showIncomeMonth(m)),new LinearLayout.LayoutParams(-1,dp(118)));content.addView(chart);
        addPortfolioHistoryCard(broker);
    }

    void addPortfolioCompositionCard(String broker,double totalValue,Double cashValue){
        LinkedHashMap<String,Double> parts=portfolioComposition(broker,cashValue);
        LinearLayout box=darkCard();
        box.addView(darkText(broker==null?"Composizione patrimonio totale":"Composizione patrimonio",20,true));
        
        DonutChartView donut=new DonutChartView(this,parts,totalValue,label->openPortfolioPart(label),()->openTotalPortfolioDashboard());
        box.addView(donut,new LinearLayout.LayoutParams(-1,dp(190)));
        for(Map.Entry<String,Double> e:parts.entrySet()){
            if(e.getValue()<=0 && Math.abs(totalValue)>0.0001) continue;
            box.addView(legendRowDark(colorForPart(e.getKey()),e.getKey(),e.getValue(),totalValue));gap(box,5);
        }
        content.addView(box);
    }

    interface DonutPartClickListener { void onPartClick(String label); }

    void openPortfolioPart(String label){
        if("Liquidità".equals(label)){showLiquidityBreakdown();return;}
        setPortfolio(TOTAL);
        showPositionsList(label);
    }

    void openTotalPortfolioDashboard(){
        setPortfolio(TOTAL);
        showDashboard();
    }

    void showMissingPmcPositions(){
        current=TOTAL;heading("PMC da completare","Posizioni aperte");setNavActive("PORTFOLIO");
        LinearLayout intro=card();intro.addView(sectionTitle("P/L non realizzato • PMC mancanti"));content.addView(intro);
        int count=0;
        for(String b:db.portfolioNames(true)){
            Cursor c=db.positions(b);
            while(c.moveToNext()){
                int pi=c.getColumnIndex("pmc");if(pi>=0&&!c.isNull(pi))continue;
                count++;String isin=c.getString(c.getColumnIndexOrThrow("isin")),name=c.getString(c.getColumnIndexOrThrow("instrument"));double q=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));
                LinearLayout item=card();item.addView(tv(name,15,true));item.addView(muted(b+" • "+isin+"\nQuantità "+trim(q)+" • Prezzo "+trim(pr)+" • Valore "+euro.format(val)+" €\nPMC: non inserito",12));Button edit=ghostBtn("Completa PMC  ›");edit.setOnClickListener(v->showPositionDetail(b,isin));item.addView(edit);content.addView(item);
            }c.close();
        }
        if(count==0){LinearLayout ok=card();ok.addView(tv("Tutti i PMC risultano presenti.",14,true));content.addView(ok);}
        Button back=ghostBtn("← Torna alla Home");back.setOnClickListener(v->showHome());content.addView(back);
    }

    void showLiquidityBreakdown(){
        current=TOTAL;heading("Liquidità","Totale");setNavActive("PORTFOLIO");
        LinearLayout c=card();c.addView(sectionTitle("Liquidità per portafoglio"));
        double total=0;boolean any=false;
        for(String b:db.portfolioNames(true)){
            Double x=db.latestCashValue(b);
            if(x==null)continue;
            any=true; total+=x;
            LinearLayout row=hrow();TextView n=tv(b,14,true);row.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView v=tv(euro.format(x)+" €",14,true);v.setGravity(Gravity.END);row.addView(v);c.addView(row);
        }
        if(!any)c.addView(muted("Liquidità non ancora separata nei portafogli.",13));
        else{gap(c,6);TextView tt=tv("Totale liquidità   "+euro.format(total)+" €",15,true);tt.setGravity(Gravity.END);c.addView(tt);}
        content.addView(c);
        Button back=ghostBtn("← Torna alla Home");back.setOnClickListener(v->showHome());content.addView(back);
    }

    LinkedHashMap<String,Double> portfolioComposition(String broker,Double cashValue){
        LinkedHashMap<String,Double> map=new LinkedHashMap<>();
        map.put("Certificati",0d);map.put("ETF",0d);map.put("ETP",0d);map.put("Azioni",0d);map.put("Liquidità", cashValue==null?0d:Math.max(0,cashValue));
        if(broker==null){
            for(String b:db.portfolioNames(true)) accumulatePortfolioComposition(map,b);
        }else accumulatePortfolioComposition(map,broker);
        return map;
    }

    void accumulatePortfolioComposition(LinkedHashMap<String,Double> map,String broker){
        Cursor c=db.positions(broker);
        while(c.moveToNext()){
            String instrument=c.getString(c.getColumnIndexOrThrow("instrument"));
            String isin=c.getString(c.getColumnIndexOrThrow("isin"));
            double currentValue=c.getDouble(c.getColumnIndexOrThrow("current_value"));
            String finalCategory=positionCategory(broker,instrument,isin);
            if(finalCategory==null || !map.containsKey(finalCategory)) finalCategory="Azioni";
            map.put(finalCategory,map.get(finalCategory)+currentValue);
        }
        c.close();
    }

    int colorForPart(String key){
        if("Certificati".equals(key)) return Color.rgb(216,155,43);
        if("ETF".equals(key)) return Color.rgb(47,128,237);
        if("ETP".equals(key)) return Color.rgb(142,91,217);
        if("Azioni".equals(key)) return Color.rgb(0,166,214);
        return Color.rgb(183,192,204);
    }

    LinearLayout legendRow(int color,String label,double value,double total){
        LinearLayout row=hrow();
        row.setPadding(dp(2),dp(4),dp(2),dp(4));row.setMinimumHeight(dp(52));
        row.setClickable(true);row.setFocusable(true);row.setBackgroundResource(R.drawable.list_row);
        row.setOnClickListener(v->openPortfolioPart(label));
        View dot=new View(this); dot.setBackground(makeDot(color));row.addView(dot,new LinearLayout.LayoutParams(dp(13),dp(13)));gap(row,7);
        TextView l=tv(label,14,true);l.setSingleLine(true);row.addView(l,new LinearLayout.LayoutParams(0,-2,1));
        double pctValue=total<=0?0:(value/total);TextView amt=tv(euro.format(value)+" €",14,true);amt.setSingleLine(true);amt.setGravity(Gravity.END);row.addView(amt);gap(row,6);
        TextView pctv=muted(pct.format(pctValue),13);pctv.setSingleLine(true);pctv.setGravity(Gravity.END);row.addView(pctv,new LinearLayout.LayoutParams(dp(72),-2));
        TextView che=tv("›",19,true);che.setTextColor(C_BLUE);che.setGravity(Gravity.CENTER);row.addView(che,new LinearLayout.LayoutParams(dp(22),-2));return row;
    }
    LinearLayout legendRowDark(int color,String label,double value,double total){
        LinearLayout row=hrow();row.setPadding(dp(7),dp(8),dp(6),dp(8));row.setMinimumHeight(dp(60));row.setClickable(true);row.setFocusable(true);row.setOnClickListener(v->openPortfolioPart(label));
        GradientDrawable bg=new GradientDrawable();bg.setColor(C_DARK_ROW);bg.setCornerRadius(dp(12));row.setBackground(bg);
        View stripe=new View(this);stripe.setBackgroundColor(color);row.addView(stripe,new LinearLayout.LayoutParams(dp(5),dp(42)));gap(row,7);
        TextView l=darkText(label,14,true);l.setSingleLine(true);l.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);row.addView(l,new LinearLayout.LayoutParams(dp(104),-2));
        TextView amt=darkText(euro.format(value)+" €",14,true);amt.setSingleLine(true);amt.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);row.addView(amt,new LinearLayout.LayoutParams(0,-2,1));gap(row,5);
        TextView pctv=darkMuted(pct.format(total<=0?0:value/total),12);pctv.setSingleLine(true);pctv.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);row.addView(pctv,new LinearLayout.LayoutParams(dp(62),-2));
        TextView che=darkText("›",19,true);che.setGravity(Gravity.CENTER);row.addView(che,new LinearLayout.LayoutParams(dp(18),-2));return row;
    }

    GradientDrawable makeDot(int color){
        GradientDrawable d=new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    void addBar(LinearLayout parent,String label,double v,double total){
        double p=total==0?0:v/total;
        LinearLayout hit=new LinearLayout(this); hit.setOrientation(LinearLayout.VERTICAL); hit.setPadding(dp(2),dp(2),dp(2),dp(4));
        TextView line=financeText(label+": "+euro.format(v)+" €  ("+pct.format(p)+")",14,C_GREEN,true);
        hit.addView(line);
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(1000); bar.setProgress((int)Math.round(p*1000)); hit.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));
        hit.setClickable(true); hit.setFocusable(true); hit.setOnClickListener(vw->showPositionsList(label));
        parent.addView(hit,new LinearLayout.LayoutParams(-1,-2));
    }

    String positionCategory(String broker,String name,String isin){
        String stored=db.positionCategory(broker,isin);
        if(isMainPositionCategory(stored)) return stored;
        return inferPositionCategory(name,isin);
    }

    boolean isMainPositionCategory(String c){
        if(c==null)return false;
        for(String x:categories)if(x.equalsIgnoreCase(c.trim()))return true;
        return false;
    }

    boolean looksLikeOtherInstrument(String name){
        String n=(name==null?"":name).toUpperCase(Locale.ITALY);
        return n.contains("BTP")||n.contains("BOT")||n.contains("CCT")||n.contains("OBBLIG")||n.contains(" BOND")||n.contains("TREASURY")||n.contains("BUND")||n.contains("GOVERNMENT BOND")||n.contains("TITOLO DI STATO");
    }

    String inferPositionCategory(String name,String isin){
        String n=(name==null?"":name).toUpperCase(Locale.ITALY);
        String i=(isin==null?"":isin).toUpperCase(Locale.ITALY);
        if(looksLikeOtherInstrument(name)) return "Altro";
        if(n.startsWith("EFG EXP")||n.startsWith("LQ EXP")||n.startsWith("CIT EXP")||n.startsWith("MRX EXP")||n.startsWith("VON EXP")||n.contains("CERTIFICATE")||n.contains("CERTIFICATO")) return "Certificati";
        if(n.contains("INCOMESHARES")||n.contains(" ETP")||n.contains(" ETC")||n.contains("PHYSICAL GOLD")) return "ETP";
        if(n.contains("ETF")||n.contains("UCITS")||n.contains("ISHARES")||n.contains("VANECK")||n.contains("AMUNDI")||n.contains("SPDR")||n.contains("VANGUARD")||n.contains("FIDELITY")||n.contains("WISDOMTREE")||n.contains("REX TECH")||n.contains("EQUITY PREMIUM INCOME")||n.contains("WORLD EQUITY HIGH INCOME")||n.contains("REX CRYPTO")) return "ETF";
        if(i.equals("IT0005218380")||i.equals("IT0003128367")||i.equals("IT0000072618")||i.equals("IT0003856405")||i.equals("IT0005366767")||i.equals("IT0003796171")||i.equals("KYG651631007")||i.equals("US5494982029")||i.equals("US84615Q1031")||n.contains("POSTE ITALIANE")||n.contains("BANCO BPM")||n.equals("ENEL")||n.contains("INTESA SANPAOLO")||n.equals("LEONARDO")||n.equals("NEXI")) return "Azioni";
        return "Altro";
    }


    String knownTicker(String name,String isin){
        String n=(name==null?"":name).toUpperCase(Locale.ITALY),i=(isin==null?"":isin).toUpperCase(Locale.ITALY);
        if(i.equals("IT0003796171")||n.contains("POSTE ITALIANE"))return "PST";
        if(i.equals("IT0005218380")||n.contains("BANCO BPM"))return "BAMI";
        if(i.equals("IT0003128367")||n.equals("ENEL"))return "ENEL";
        if(i.equals("IT0000072618")||n.contains("INTESA SANPAOLO"))return "ISP";
        if(i.equals("IT0003856405")||n.equals("LEONARDO"))return "LDO";
        if(i.equals("IT0005366767")||n.equals("NEXI"))return "NEXI";
        if(i.equals("KYG651631007")||n.contains("JOBY AVIATION"))return "JOBY";
        if(i.equals("US5494982029")||n.contains("LUCID GROUP"))return "LCID";
        return "";
    }

    static class PositionRow {
        String broker,isin,ticker,name,cat,date; double qty,price,value; Double pmc; double pl;
        PositionRow(String b,String i,String t,String n,String c,double qu,Double pm,double pr,double va,String d){
            broker=b; isin=i; ticker=t==null?"":t; name=n; cat=c; qty=qu; pmc=pm; price=pr; value=va; date=d; pl=pm==null?0:va-qu*pm;
        }
    }

    void showPositionsList(String initialCategory){
        if(current.equals("HOME")){showHome();return;}heading(current.equals(TOTAL)?"Cerca titolo":"Titoli / Posizioni",current);
        final String[] category={initialCategory==null?"Tutti":initialCategory},state={"Aperte"},order={"Valore"};
        LinearLayout controls=card();controls.addView(sectionTitle(current.equals(TOTAL)?"Trova investimenti":"Cerca in "+current));
        EditText search=textField("Cerca per nome, ISIN o ticker","");controls.addView(search);Button insert=successBtn("＋ Inserisci titolo");insert.setOnClickListener(v->{if(current.equals(TOTAL))choosePortfolioForPositionEntry();else positionEditDialog(current,null,null,null,null,null,null,null);});controls.addView(insert);
        LinearLayout cats1=hrow();for(String c:new String[]{"Tutti","Azioni","ETF"}){Button b=ghostBtn(c);b.setTextSize(12);b.setOnClickListener(v->{category[0]=c;showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});cats1.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));}controls.addView(cats1);gap(controls,4);
        LinearLayout cats2=hrow();for(String c:new String[]{"ETP","Certificati","Altro"}){Button b=ghostBtn(c);b.setTextSize(12);b.setOnClickListener(v->{category[0]=c;showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});cats2.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));}controls.addView(cats2);
        
        LinearLayout options=hrow();Button open=ghostBtn("Aperte");open.setOnClickListener(v->{state[0]="Aperte";showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});Button closed=ghostBtn("Chiuse");closed.setOnClickListener(v->{state[0]="Chiuse";showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());});Button sort=ghostBtn("Ordina");sort.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Ordina per").setItems(new String[]{"Valore","P/L","Nome"},(d,w)->{order[0]=new String[]{"Valore","P/L","Nome"}[w];showPositionsListFiltered(category[0],state[0],order[0],search.getText().toString());}).show());options.addView(open,new LinearLayout.LayoutParams(0,dp(42),1));options.addView(closed,new LinearLayout.LayoutParams(0,dp(42),1));options.addView(sort,new LinearLayout.LayoutParams(0,dp(42),1));controls.addView(options);content.addView(controls);addQuoteUpdateCard();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int a,int b,int c){}public void onTextChanged(CharSequence x,int a,int b,int c){showPositionsListFiltered(category[0],state[0],order[0],x.toString());}public void afterTextChanged(Editable e){}});showPositionsListFiltered(category[0],state[0],order[0],"");
    }

    void showPositionsListFiltered(String category,String state,String order,String query){
        while(content.getChildCount()>1)content.removeViewAt(1);String q=(query==null?"":query.trim().toUpperCase(Locale.ITALY));ArrayList<PositionRow> rows=new ArrayList<>();
        if(state.equals("Aperte")){java.util.List<String> brokers=current.equals(TOTAL)?db.portfolioNames(true):java.util.Arrays.asList(current);for(String b:brokers){Cursor c=db.positions(b);while(c.moveToNext()){String name=c.getString(c.getColumnIndexOrThrow("instrument")),isin=c.getString(c.getColumnIndexOrThrow("isin"));int ti=c.getColumnIndex("ticker");String ticker=ti>=0&&!c.isNull(ti)?c.getString(ti):"";if(ticker.isEmpty())ticker=knownTicker(name,isin);String cat=positionCategory(b,name,isin);if(!category.equals("Tutti")&&!cat.equals(category))continue;if(!q.isEmpty()&&!name.toUpperCase(Locale.ITALY).contains(q)&&!isin.toUpperCase(Locale.ITALY).contains(q)&&!ticker.toUpperCase(Locale.ITALY).contains(q))continue;double qty=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));int pi=c.getColumnIndex("pmc");Double pmc=pi>=0&&!c.isNull(pi)?c.getDouble(pi):null;String date=c.getString(c.getColumnIndexOrThrow("source_date"));rows.add(new PositionRow(b,isin,ticker,name,cat,qty,pmc,pr,val,date));}c.close();}}
        else{Cursor c=db.closedSales(current.equals(TOTAL)?null:current);while(c.moveToNext()){String b=c.getString(c.getColumnIndexOrThrow("broker")),name=c.getString(c.getColumnIndexOrThrow("instrument")),isin=c.getString(c.getColumnIndexOrThrow("isin"));String cat=positionCategory(b,name,isin);if(!category.equals("Tutti")&&!cat.equals(category))continue;if(!q.isEmpty()&&!name.toUpperCase(Locale.ITALY).contains(q)&&!isin.toUpperCase(Locale.ITALY).contains(q))continue;double qty=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("gross_amount"));Double pmc=null;double cost=c.getDouble(c.getColumnIndexOrThrow("cost_basis"));if(qty>0)pmc=cost/qty;rows.add(new PositionRow(b,isin,"",name,cat,qty,pmc,pr,val,c.getString(c.getColumnIndexOrThrow("date"))));}c.close();}
        if(order.equals("Nome"))Collections.sort(rows,(a,b)->a.name.compareToIgnoreCase(b.name));else if(order.equals("P/L"))Collections.sort(rows,(a,b)->Double.compare(b.pl,a.pl));else Collections.sort(rows,(a,b)->Double.compare(b.value,a.value));
        TextView head=tv((category.equals("Tutti")?"Tutti i titoli":category)+" • "+state+" • "+rows.size()+" risultati",14,true);head.setPadding(dp(4),dp(4),dp(4),dp(10));content.addView(head);
        if(rows.isEmpty()){LinearLayout empty=card();empty.addView(muted("Nessun titolo trovato con questi filtri.",13));content.addView(empty);return;}
        for(PositionRow r:rows){LinearLayout item=card();LinearLayout top=hrow();LinearLayout nameBox=new LinearLayout(this);nameBox.setOrientation(LinearLayout.VERTICAL);TextView nm=tv(r.name,16,true);nm.setPadding(0,0,0,0);nameBox.addView(nm);String id=(r.ticker.isEmpty()?"":r.ticker+"  |  ")+r.isin;TextView ids=tv(id,11,true);ids.setPadding(0,0,0,0);nameBox.addView(ids);top.addView(nameBox,new LinearLayout.LayoutParams(0,-2,1));TextView val=tv(euro.format(r.value)+" €",14,true);val.setGravity(Gravity.END);top.addView(val);item.addView(top);LinearLayout tags=hrow();tags.addView(badge(r.cat));if(current.equals(TOTAL)){gap(tags,4);tags.addView(badge(r.broker));}item.addView(tags);double income=db.sumIncomeForInstrument(r.broker,r.isin);String body="Q.tà "+trim(r.qty)+" • PMC "+(r.pmc==null?"non inserito":trim(r.pmc))+" • Prezzo "+trim(r.price)+(r.pmc==null?"":"\nP/L "+euro.format(r.pl)+" €")+" • Proventi "+euro.format(income)+" €";item.addView(positionFinanceText(body,r.pl,income,12));if(state.equals("Aperte")){Button open=ghostBtn("Apri titolo  ›");open.setOnClickListener(v->showPositionDetail(r.broker,r.isin));item.addView(open);}content.addView(item);}
    }

    void showPositionDetail(String broker,String isin){
        Cursor c=db.position(broker,isin);
        if(!c.moveToFirst()){c.close();toast("Posizione non trovata");return;}
        String name=c.getString(c.getColumnIndexOrThrow("instrument"));int ti=c.getColumnIndex("ticker");String ticker=ti>=0&&!c.isNull(ti)?c.getString(ti):"";if(ticker.isEmpty())ticker=knownTicker(name,isin);double qty=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));
        int pi=c.getColumnIndex("pmc");Double pmc=pi>=0&&!c.isNull(pi)?c.getDouble(pi):null;int bfi=c.getColumnIndex("buy_fee");double buyFee=bfi>=0&&!c.isNull(bfi)?c.getDouble(bfi):0;String srcDate=c.getString(c.getColumnIndexOrThrow("source_date"));c.close();
        heading(name,broker);setNavActive("PORTFOLIO");
        double detailIncome=db.sumIncomeForInstrument(broker,isin);Double detailPl=pmc==null?null:val-qty*pmc;
        String detailText="Categoria: "+positionCategory(broker,name,isin)+"\nISIN: "+isin+(ticker.isEmpty()?"":"\nTicker: "+ticker)+
                "\nQuantità: "+trim(qty)+"\nPMC: "+(pmc==null?"non inserito":trim(pmc))+"\nPrezzo attuale: "+euro.format(pr)+" €"+
                "\nValore attuale: "+euro.format(val)+" €"+(detailPl==null?"":"\nP/L non realizzato: "+euro.format(detailPl)+" €")+
                "\nProventi 2026 attribuiti: "+euro.format(detailIncome)+" €"+(srcDate==null||srcDate.isEmpty()?"":"\nPrezzo aggiornato al: "+srcDate);
        LinearLayout d=card();d.addView(positionDetailFinanceText(detailText,detailPl,detailIncome,14));content.addView(d);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        final Double fpmc=pmc;final double fq=qty,fpr=pr,fbf=buyFee;final String fn=name,fi=isin,fb=broker;
        Button edit=btn("Modifica");edit.setOnClickListener(v->positionEditDialog(fb,fi,fn,fq,fpmc,fpr,fi,fbf));
        Button sell=btn("Vendi");sell.setOnClickListener(v->positionSaleDialog(fb,fi,fn,fq,fpmc,fpr,fbf));
        actions.addView(edit,new LinearLayout.LayoutParams(0,dp(50),1));actions.addView(sell,new LinearLayout.LayoutParams(0,dp(50),1));content.addView(actions);
        LinearLayout hist=card();hist.addView(tv("Storico vendite",16,true));Cursor sales=db.salesForIsin(broker,isin);int n=0;while(sales.moveToNext()){n++;hist.addView(tv(sales.getString(sales.getColumnIndexOrThrow("date"))+" • "+trim(sales.getDouble(sales.getColumnIndexOrThrow("quantity")))+" × "+trim(sales.getDouble(sales.getColumnIndexOrThrow("price")))+" • P/L netto "+euro.format(sales.getDouble(sales.getColumnIndexOrThrow("realized_pl_net")))+" €",12,false));}sales.close();if(n==0)hist.addView(tv("Nessuna vendita registrata.",12,false));content.addView(hist);
        Button back=btn("Torna ai titoli");back.setOnClickListener(v->{current=broker;showPositionsList("Tutti");});content.addView(back);
    }

    static class QuoteResult { double price; String date,source; QuoteResult(double p,String d,String s){price=p;date=d;source=s;} }

    String normalizeMarketIsin(String raw){
        if(raw==null)return "";String x=raw.trim().toUpperCase(Locale.ROOT);int k=x.lastIndexOf('-');if(k>=0&&k<x.length()-1){String tail=x.substring(k+1);if(tail.matches("[A-Z]{2}[A-Z0-9]{10}"))x=tail;}return x;
    }
    String[] quoteUrls(String category,String isin){
        String q="?isin="+isin+"&lang=it";String c=category==null?"":category;
        if(c.equals("Azioni"))return new String[]{"https://www.borsaitaliana.it/borsa/azioni/dati-completi.html"+q,"https://www.borsaitaliana.it/borsa/azioni/scheda.html"+q};
        if(c.equals("ETF")||c.equals("ETP"))return new String[]{"https://www.borsaitaliana.it/borsa/etf/dettaglio.html"+q,"https://www.borsaitaliana.it/borsa/etf/scheda.html"+q};
        if(c.equals("Certificati"))return new String[]{"https://www.borsaitaliana.it/borsa/cw-e-certificates/dati-completi.html"+q,"https://www.borsaitaliana.it/borsa/cw-e-certificates/eurotlx/dati-completi.html"+q,"https://www.borsaitaliana.it/borsa/cw-e-certificates/sedex/dati-completi.html"+q};
        return new String[]{"https://www.borsaitaliana.it/borsa/azioni/dati-completi.html"+q,"https://www.borsaitaliana.it/borsa/etf/dettaglio.html"+q,"https://www.borsaitaliana.it/borsa/cw-e-certificates/dati-completi.html"+q};
    }
    String httpText(String urlString)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","Mozilla/5.0 (Android; Portafoglio2026/3.4.38)");c.setRequestProperty("Accept-Language","it-IT,it;q=0.9,en;q=0.6");c.setRequestProperty("Accept","text/html,application/xhtml+xml");
        int code=c.getResponseCode();if(code<200||code>=400){c.disconnect();throw new IOException("HTTP "+code);}InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0&&out.size()<1500000)out.write(buf,0,n);in.close();c.disconnect();return new String(out.toByteArray(),StandardCharsets.UTF_8);
    }
    String plainHtml(String html){return html.replace("&nbsp;"," ").replace("&#160;"," ").replace("&euro;","€").replaceAll("(?is)<script.*?</script>"," ").replaceAll("(?is)<style.*?</style>"," ").replaceAll("(?s)<[^>]+>"," ").replace("&amp;","&").replaceAll("\\s+"," ");}
    Double parseItalianPrice(String x){try{String s=x.trim().replace(".","").replace(',','.');return Double.parseDouble(s);}catch(Exception e){return null;}}
    Double parseLabeledPrice(String text,String... labels){
        for(String label:labels){Matcher m=Pattern.compile("(?i)"+Pattern.quote(label)+"\\s*:?\\s*([0-9]{1,6}(?:[.,][0-9]{1,6})?)").matcher(text);if(m.find()){Double p=parseItalianPrice(m.group(1));if(p!=null&&p>0)return p;}}
        return null;
    }
    String quoteDateNear(String text,int from){String d=currentDate();int a=Math.max(0,from-40),b=Math.min(text.length(),from+220);Matcher dm=Pattern.compile("([0-3]?[0-9]/[01]?[0-9]/(?:[0-9]{2}|[0-9]{4}))").matcher(text.substring(a,b));if(dm.find()){try{String[] x=dm.group(1).split("/");String yy=x[2].length()==2?"20"+x[2]:x[2];d=String.format(Locale.US,"%s-%02d-%02d",yy,Integer.parseInt(x[1]),Integer.parseInt(x[0]));}catch(Exception ignored){}}return d;}
    QuoteResult parseQuoteHtml(String html,String category){
        String t=plainHtml(html);
        if("Certificati".equals(category)){
            // Per i certificati il semplice ultimo contratto/prezzo di riferimento può essere vecchio e
            // molto diverso dalla valorizzazione del broker. Usiamo solo il lato BID/denaro del book.
            String[] bidLabels={"Prezzo Denaro","Prezzo denaro","Denaro","BID","Bid"};
            String[] askLabels={"Prezzo Lettera","Prezzo lettera","Lettera","ASK","Ask"};
            for(String label:bidLabels){Matcher m=Pattern.compile("(?i)"+Pattern.quote(label)+"\\s*:?\\s*([0-9]{1,6}(?:[.,][0-9]{1,6})?)").matcher(t);if(m.find()){Double bid=parseItalianPrice(m.group(1));Double ask=parseLabeledPrice(t,askLabels);if(bid!=null&&bid>0&&(ask==null||ask<=0||bid<=ask*1.001))return new QuoteResult(bid,quoteDateNear(t,m.start()),"Borsa Italiana / Euronext • BID");}}
            return null; // book assente: non sostituire il prezzo esistente con dati potenzialmente obsoleti
        }
        String[] labels={"Prezzo Ultimo Contratto","Ultimo Contratto","Prezzo di riferimento","Chiusura Precedente/Pre-Chiusura/Chiusura","Prezzo di Chiusura"};
        for(String label:labels){Matcher m=Pattern.compile("(?i)"+Pattern.quote(label)+"\\s*:?\\s*([0-9]{1,6}(?:[.,][0-9]{1,6})?)").matcher(t);if(m.find()){Double p=parseItalianPrice(m.group(1));if(p!=null&&p>0)return new QuoteResult(p,quoteDateNear(t,m.start()),"Borsa Italiana / Euronext");}}
        return null;
    }
    QuoteResult fetchFreeQuote(String category,String rawIsin){String isin=normalizeMarketIsin(rawIsin);if(!isin.matches("[A-Z]{2}[A-Z0-9]{10}"))return null;for(String u:quoteUrls(category,isin)){try{QuoteResult r=parseQuoteHtml(httpText(u),category);if(r!=null)return r;}catch(Exception ignored){}}return null;}
    void addQuoteUpdateCard(){
        LinearLayout q=card();LinearLayout h=hrow();LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);TextView tt=tv("Quotazioni automatiche",16,true);tt.setPadding(0,0,0,0);left.addView(tt);String last=db.getSetting("quotes_last_refresh","");TextView st=muted(last.isEmpty()?"Fonte gratuita • Borsa Italiana / Euronext":"Ultimo aggiornamento • "+last,11);st.setPadding(0,0,0,0);left.addView(st);h.addView(left,new LinearLayout.LayoutParams(0,-2,1));Button b=primaryBtn("↻ Aggiorna");b.setTextSize(13);b.setOnClickListener(v->refreshQuotes(true));h.addView(b,new LinearLayout.LayoutParams(dp(112),dp(48)));q.addView(h);TextView free=muted("Nessun abbonamento. Azioni/ETF/ETP: ultimo prezzo disponibile. Certificati: viene usato solo il BID/denaro del book; se il book non è disponibile il prezzo esistente non viene modificato.",10);q.addView(free);content.addView(q);
    }
    void maybeAutoRefreshQuotes(){String last=db.getSetting("quotes_last_refresh_date","");if(!currentDate().equals(last))refreshQuotes(false);}
    void refreshQuotes(boolean userRequested){
        if(userRequested)toast("Aggiornamento quotazioni avviato");
        new Thread(()->{int ok=0,fail=0,protectedCount=0;HashMap<String,QuoteResult> cache=new HashMap<>();HashSet<String> touched=new HashSet<>();Cursor c=db.allPositions();while(c.moveToNext()){String broker=c.getString(c.getColumnIndexOrThrow("broker")),isin=c.getString(c.getColumnIndexOrThrow("isin")),name=c.getString(c.getColumnIndexOrThrow("instrument"));double oldPrice=c.getDouble(c.getColumnIndexOrThrow("price"));String cat=positionCategory(broker,name,isin),key=normalizeMarketIsin(isin);QuoteResult r=cache.get(key);if(!cache.containsKey(key)){r=fetchFreeQuote(cat,isin);cache.put(key,r);}if(r!=null){boolean safe=true;if("Certificati".equals(cat)&&oldPrice>0){double delta=Math.abs(r.price-oldPrice)/oldPrice;if(delta>0.15)safe=false;}if(safe){db.updatePositionMarketPrice(broker,isin,r.price,r.date);touched.add(broker);ok++;}else protectedCount++;}else fail++;}c.close();for(String b:touched)db.syncInvestedFromPositions(b,currentDate(),"Quotazioni gratuite Borsa Italiana/Euronext");db.captureDailySnapshot(currentDate());String stamp=new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.ITALY).format(new java.util.Date());if(ok>0){db.setSetting("quotes_last_refresh",stamp);db.setSetting("quotes_last_refresh_date",currentDate());}final int fok=ok,ffail=fail,fprotected=protectedCount;runOnUiThread(()->{if(userRequested)toast("Quotazioni aggiornate: "+fok+" • non aggiornate: "+(ffail+fprotected)+(fprotected>0?" ("+fprotected+" protette)":""));if(current.equals("HOME"))showHome();});}).start();
    }

    Double unrealizedPl(String broker){
        if(broker!=null){if(db.positionCount(broker)==0)return 0.0;Double cost=db.sumPositionsCostBasis(broker);return cost==null?null:db.sumPositionsCurrentValue(broker)-cost;}
        double total=0;for(String b:db.portfolioNames(true)){if(db.positionCount(b)==0)continue;Double cost=db.sumPositionsCostBasis(b);if(cost==null)return null;total+=db.sumPositionsCurrentValue(b)-cost;}return total;
    }

    double[] monthlyIncome(String broker){double[] a=new double[12];for(int m=1;m<=12;m++)a[m-1]=broker==null?db.sumIncomeMonthActive(m,"gross"):db.sumIncomeMonth(broker,m,"gross");return a;}
    static class HistorySeries {
        ArrayList<String> dates=new ArrayList<>();
        ArrayList<Double> wealth=new ArrayList<>();
        ArrayList<Double> performance=new ArrayList<>();
        double undatedPerformance=0;
        int undatedYear=2026;
    }

    double currentPortfolioValue(String broker){return broker==null?db.latestPortfolioValueAllActive():db.latestPortfolioValue(broker);}
    double currentGrossPerformance(String broker){
        double inc=broker==null?db.sumIncomeActive("gross"):db.sumIncome(broker,"gross");
        double realized=db.sumRealized(broker,"realized_pl_gross");
        Double un=unrealizedPl(broker);
        return inc+realized+(un==null?0:un);
    }
    HistorySeries portfolioHistorySeries(String broker){
        db.captureDailySnapshot(currentDate());
        HistorySeries hs=new HistorySeries();
        String today=currentDate();
        int year=2026;try{year=Integer.parseInt(db.getSetting("year","2026"));}catch(Exception ignored){}
        hs.undatedYear=year;
        hs.undatedPerformance=year==2026?grossHistoricalAggregateIncome(broker):0;

        TreeMap<String,Double> wealthByDate=new TreeMap<>();
        TreeMap<String,Double> unrealByDate=new TreeMap<>();

        // Snapshot giornalieri: patrimonio reale e P/L non realizzato osservato in quella data.
        Cursor d=db.dailySnapshots(broker);
        while(d.moveToNext()){
            String date=d.getString(d.getColumnIndexOrThrow("date"));
            if(date==null||date.trim().isEmpty()||date.compareTo(today)>0)continue;
            Double w=getNullable(d,"total_value"),un=getNullable(d,"unrealized_pl");
            if(w!=null&&w>0)wealthByDate.put(date,w);
            if(un!=null)unrealByDate.put(date,un);
        }
        d.close();

        // Snapshot mensili realmente salvati prima di oggi: utili subito per la curva patrimonio.
        TreeMap<String,Double> monthlyWealth=new TreeMap<>();
        if(broker==null){
            for(String b:db.portfolioNames(true)){
                Cursor c=db.snapshots(b);
                while(c.moveToNext()){
                    int mth=c.getInt(c.getColumnIndexOrThrow("month"));Double f=getNullable(c,"final_value");
                    if(f==null||f<=0||mth<1||mth>12)continue;
                    String date=String.format(Locale.US,"%04d-%02d-28",year,mth);
                    if(date.compareTo(today)>0)continue;
                    monthlyWealth.put(date,(monthlyWealth.containsKey(date)?monthlyWealth.get(date):0)+f);
                }
                c.close();
            }
        }else{
            Cursor c=db.snapshots(broker);
            while(c.moveToNext()){
                int mth=c.getInt(c.getColumnIndexOrThrow("month"));Double f=getNullable(c,"final_value");
                if(f==null||f<=0||mth<1||mth>12)continue;
                String date=String.format(Locale.US,"%04d-%02d-28",year,mth);
                if(date.compareTo(today)<=0)monthlyWealth.put(date,f);
            }
            c.close();
        }
        wealthByDate.putAll(monthlyWealth);

        // L'ultimo punto patrimonio coincide sempre con la Home.
        double live=currentPortfolioValue(broker);
        if(live>0)wealthByDate.put(today,live);

        // Performance storica ricostruita dai movimenti REALMENTE datati:
        // proventi lordi + P/L realizzato lordo. Lo storico aggregato non datato
        // non viene inventato dentro mesi o giorni; resta nel totale annuo.
        TreeMap<String,Double> events=grossPerformanceByDate(broker);
        TreeMap<String,Double> perfByDate=new TreeMap<>();
        String yearStart=String.format(Locale.US,"%04d-01-01",year);
        if(yearStart.compareTo(today)<=0)perfByDate.put(yearStart,0.0);

        double cumulative=0;
        for(Map.Entry<String,Double> e:events.entrySet()){
            String date=e.getKey();
            if(date==null||date.compareTo(today)>0)continue;
            cumulative+=e.getValue();
            double un=unrealByDate.containsKey(date)?unrealByDate.get(date):0;
            perfByDate.put(date,cumulative+un);
        }

        // Gli snapshot giornalieri aggiungono il P/L non realizzato osservato,
        // mantenendo il cumulato dei soli movimenti datati fino a quel giorno.
        for(Map.Entry<String,Double> e:unrealByDate.entrySet()){
            String date=e.getKey();double dated=0;
            for(Map.Entry<String,Double> ev:events.entrySet()){
                if(ev.getKey().compareTo(date)>0)break;
                dated+=ev.getValue();
            }
            perfByDate.put(date,dated+e.getValue());
        }

        // Oggi: cumulato datato + P/L non realizzato corrente.
        double datedToday=0;for(Map.Entry<String,Double> e:events.entrySet())if(e.getKey().compareTo(today)<=0)datedToday+=e.getValue();
        Double unNow=unrealizedPl(broker);
        perfByDate.put(today,datedToday+(unNow==null?0:unNow));

        // Unione delle date. Nei punti solo-performance il patrimonio resta NaN:
        // la vista PATRIMONIO ignora quindi quei punti e non inventa valori.
        TreeSet<String> dates=new TreeSet<>();dates.addAll(wealthByDate.keySet());dates.addAll(perfByDate.keySet());
        double lastPerf=0;
        for(String date:dates){
            if(perfByDate.containsKey(date))lastPerf=perfByDate.get(date);
            hs.dates.add(date);
            hs.wealth.add(wealthByDate.containsKey(date)?wealthByDate.get(date):Double.NaN);
            hs.performance.add(lastPerf);
        }
        return hs;
    }

    void addPortfolioHistoryCard(String broker){
        LinearLayout box=card();LinearLayout head=hrow();head.addView(sectionTitle("Storico patrimonio"),new LinearLayout.LayoutParams(0,-2,1));box.addView(head);
        final PortfolioHistoryChartView chart=new PortfolioHistoryChartView(this,portfolioHistorySeries(broker));TextView summary=tv("",12,true);TextView breakdown=tv("",11,true);chart.setSummaryView(summary);chart.setBreakdownView(breakdown);

        LinearLayout modes=hrow();String[] modeLabels={"PATRIMONIO","PERFORMANCE €","PERFORMANCE %"};Button[] mbs=new Button[modeLabels.length];
        for(int i=0;i<modeLabels.length;i++){final int idx=i;mbs[i]=ghostBtn(modeLabels[i]);mbs[i].setTextSize(i==0?11:10);mbs[i].setSingleLine(true);mbs[i].setPadding(dp(3),0,dp(3),0);modes.addView(mbs[i],new LinearLayout.LayoutParams(0,dp(44),1));if(i<modeLabels.length-1)gap(modes,3);mbs[i].setOnClickListener(v->{chart.setMode(idx);for(int j=0;j<mbs.length;j++)setToggleStyle(mbs[j],j==idx);});}
        setToggleStyle(mbs[0],true);box.addView(modes);gap(box,6);
        box.addView(chart,new LinearLayout.LayoutParams(-1,dp(230)));

        LinearLayout periods=hrow();String[] labels={"YTD","1M","6M","1A","MAX"};Button[] pbs=new Button[labels.length];
        for(int i=0;i<labels.length;i++){final int idx=i;pbs[i]=ghostBtn(labels[i]);pbs[i].setTextSize(12);pbs[i].setSingleLine(true);pbs[i].setPadding(dp(2),0,dp(2),0);periods.addView(pbs[i],new LinearLayout.LayoutParams(0,dp(42),1));if(i<labels.length-1)gap(periods,3);pbs[i].setOnClickListener(v->{chart.setRange(labels[idx]);for(int j=0;j<pbs.length;j++)setToggleStyle(pbs[j],j==idx);});}
        setToggleStyle(pbs[0],true);box.addView(periods);gap(box,5);box.addView(summary);box.addView(breakdown);content.addView(box);
    }

    EditText field(String hint,Double val){
        EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setTextColor(C_TEXT);e.setHintTextColor(C_MUTED);e.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);e.setBackgroundResource(R.drawable.input_bg);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);if(val!=null)e.setText(trim(val));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;
    }
    EditText textField(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setTextColor(C_TEXT);e.setHintTextColor(C_MUTED);e.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);e.setBackgroundResource(R.drawable.input_bg);e.setText(val==null?"":val);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    void addLabeledField(LinearLayout box,String label,EditText field){
        TextView l=tv(label,11,true);l.setPadding(dp(4),dp(5),dp(4),0);box.addView(l);box.addView(field);
    }
    String trim(double d){if(Math.abs(d-Math.rint(d))<0.000001)return String.valueOf((long)Math.rint(d));return String.valueOf(d);}
    String currentDate(){Calendar c=Calendar.getInstance();return String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}
    Double num(EditText e){return parseUserNumber(e.getText().toString());}
    Double parseUserNumber(String raw){
        try{
            if(raw==null)return null;
            String s=raw.trim().replace("€","").replace("\u00A0","").replace(" ","");
            if(s.isEmpty())return null;
            int comma=s.lastIndexOf(','),dot=s.lastIndexOf('.');
            if(comma>=0&&dot>=0){
                if(comma>dot)s=s.replace(".","").replace(',', '.');
                else s=s.replace(",","");
            }else if(comma>=0){
                s=s.replace(',', '.');
            }
            return Double.parseDouble(s);
        }catch(Exception ex){return null;}
    }
    boolean invalidNumber(EditText e){String s=e.getText().toString().trim();return !s.isEmpty()&&parseUserNumber(s)==null;}
    double n(EditText e){Double x=num(e);return x==null?0:x;}
    Double getNullable(Cursor c,String col){int i=c.getColumnIndexOrThrow(col);return c.isNull(i)?null:c.getDouble(i);}

    Spinner spinner(String[] data,int selected){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,data){
        @Override public View getView(int position,View convertView,ViewGroup parent){TextView v=(TextView)super.getView(position,convertView,parent);v.setTextColor(C_TEXT);v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return v;}
        @Override public View getDropDownView(int position,View convertView,ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convertView,parent);v.setTextColor(C_TEXT);v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return v;}
    };s.setAdapter(a);if(selected>=0&&selected<data.length)s.setSelection(selected);return s;}

    int ytdMonthsElapsed(){
        Calendar now=Calendar.getInstance();int year=now.get(Calendar.YEAR);
        if(year<2026)return 0;if(year>2026)return 12;return now.get(Calendar.MONTH)+1;
    }

    double scopeIncomeMonth(int month,String field){return current.equals(TOTAL)?db.sumIncomeMonthActive(month,field):db.sumIncomeMonth(current,month,field);}
    double knownGrossCoverage(String broker){double total=0;java.util.List<String> brokers=broker==null?db.portfolioNames(true):java.util.Arrays.asList(broker);for(String b:brokers){Cursor c=db.incomes(b);while(c.moveToNext()){int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";if("NETTO".equalsIgnoreCase(mode))continue;int ni=c.getColumnIndex("notes");String notes=ni>=0&&!c.isNull(ni)?c.getString(ni):"";String low=notes.toLowerCase(Locale.ROOT);boolean incomplete=low.contains("da completare")&&(low.contains("netto")||low.contains("imposte"));if(!incomplete)total+=c.getDouble(c.getColumnIndexOrThrow("gross"));}c.close();}return total;}
    boolean scopeIncompleteNetMonth(int month){return current.equals(TOTAL)?db.hasIncompleteNetMonthActive(month):db.hasIncompleteNetMonth(current,month);}
    Cursor scopeIncomesForMonth(int month){return current.equals(TOTAL)?db.incomesForMonthActive(month):db.incomesForMonth(current,month);}
    boolean scopeHasCumulativeIncome(){if(current.equals(TOTAL)){for(String b:db.portfolioNames(true))if(db.hasAnyCumulativeIncome(b))return true;return false;}return db.hasAnyCumulativeIncome(current);}

    String incomeGroupLabel(String raw){
        String x=raw==null?"":raw.toLowerCase(Locale.ROOT);
        if(x.contains("cedol"))return "Cedole";
        if(x.contains("dividend"))return "Dividendi";
        if(x.contains("distrib"))return "Distribuzioni";
        if(x.contains("interess"))return "Interessi";
        return "Altri proventi";
    }

    boolean isHistoricalAggregateIncome(String broker,String instrument,String notes){
        String b=broker==null?"":broker.toLowerCase(Locale.ROOT);
        String i=instrument==null?"":instrument.toLowerCase(Locale.ROOT);
        String n=notes==null?"":notes.toLowerCase(Locale.ROOT);
        return b.contains("directa")&&(n.contains("storico aggregato directa")||n.contains("cumulat")||n.contains("aggregat")||i.matches("proventi .* 2026"));
    }

    String historicalIncomeTag(String broker,String instrument,String notes){
        return isHistoricalAggregateIncome(broker,instrument,notes)?" • Storico aggregato":"";
    }

    String incomeAmountLine(double gross,double net,String mode,String notes){
        String low=notes==null?"":notes.toLowerCase(Locale.ROOT);
        boolean incomplete=!"NETTO".equalsIgnoreCase(mode)&&low.contains("da completare")&&(low.contains("netto")||low.contains("imposte"));
        if("NETTO".equalsIgnoreCase(mode))return euro.format(net)+" € già netto";
        if(incomplete)return euro.format(gross)+" € lordo | netto da completare";
        return euro.format(gross)+" € lordo | "+euro.format(net)+" € netto";
    }

    void showIncome(){
        if(current.equals("HOME")){showHome();return;}heading("Proventi",current);int curMonth=Calendar.getInstance().get(Calendar.MONTH)+1;String broker=brokerFilter();double totalGross=broker==null?db.sumIncomeActive("gross"):db.sumIncome(broker,"gross"),totalNet=broker==null?db.sumIncomeActive("net"):db.sumIncome(broker,"net");boolean netIncomplete=broker==null?db.hasIncompleteNetActive():db.hasIncompleteNet(broker);double knownNet=broker==null?db.sumKnownNetActive():db.sumKnownNet(broker);double monthGross=scopeIncomeMonth(curMonth,"gross");
        double incomeTaxes=broker==null?db.sumIncomeTaxesActive():db.sumIncomeTaxes(broker);double monthTaxes=broker==null?db.sumIncomeTaxesMonthActive(curMonth):db.sumIncomeTaxesMonth(broker,curMonth);boolean monthIncomplete=scopeIncompleteNetMonth(curMonth);double monthKnownNet=current.equals(TOTAL)?db.sumKnownNetMonthActive(curMonth):db.sumKnownNetMonth(current,curMonth);double monthNet=scopeIncomeMonth(curMonth,"net");
        LinearLayout summary=card();summary.addView(sectionTitle("Proventi di "+months[curMonth-1]+" 2026"));
        LinearLayout sr=hrow();sr.addView(kpiValueColor("Lordo YTD",euro.format(totalGross)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));gap(sr,6);sr.addView(kpiValueColor(netIncomplete?"Netto noto YTD":"Netto YTD",euro.format(netIncomplete?knownNet:totalNet)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));summary.addView(sr);
        gap(summary,6);LinearLayout sr2=hrow();sr2.addView(kpiValueColor("Mese lordo",euro.format(monthGross)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));gap(sr2,6);sr2.addView(kpiValueColor(monthIncomplete?"Mese netto noto":"Mese netto",euro.format(monthIncomplete?monthKnownNet:monthNet)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));summary.addView(sr2);
        gap(summary,6);LinearLayout sr3=hrow();sr3.addView(kpiValueColor("Tasse YTD",euro.format(incomeTaxes)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));gap(sr3,6);sr3.addView(kpiValueColor("Tasse mese",euro.format(monthTaxes)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));summary.addView(sr3);
        if(netIncomplete){double coveredGross=knownGrossCoverage(broker);summary.addView(muted("Netto YTD parziale • dati completi su "+euro.format(coveredGross)+" € lordi.",12));}content.addView(summary);

        LinkedHashMap<String,Double> groups=new LinkedHashMap<>();groups.put("Cedole",0.0);groups.put("Dividendi",0.0);groups.put("Distribuzioni",0.0);groups.put("Interessi",0.0);groups.put("Altri proventi",0.0);Cursor ag=broker==null?db.incomesActive():db.incomes(broker);while(ag.moveToNext()){String g=incomeGroupLabel(ag.getString(ag.getColumnIndexOrThrow("income_type")));double x=ag.getDouble(ag.getColumnIndexOrThrow("gross"));groups.put(g,groups.containsKey(g)?groups.get(g)+x:x);}ag.close();LinearLayout comp=card();comp.addView(sectionTitle("Composizione proventi 2026"));for(Map.Entry<String,Double> e:groups.entrySet())if(e.getValue()!=0){double p=totalGross==0?0:e.getValue()/totalGross;TextView pv=financeText(e.getKey()+"   "+euro.format(e.getValue())+" €   "+pct.format(p),13,C_GREEN,true);comp.addView(pv);}content.addView(comp);

        LinearLayout monthsCard=card();monthsCard.addView(sectionTitle("Elenco proventi 2026 — mese per mese"));for(int m=1;m<=12;m++){final int month=m;double g=scopeIncomeMonth(m,"gross");Cursor cc=scopeIncomesForMonth(m);int cnt=cc.getCount();cc.close();if(g==0&&cnt==0&&m!=curMonth)continue;LinearLayout row=hrow();String movLabel=cnt==1?"1 movimento":cnt+" movimenti";TextView label=financeText(months[m-1]+"\n"+euro.format(g)+" € • "+movLabel,13,C_GREEN,false);row.addView(label,new LinearLayout.LayoutParams(0,-2,1));Button open=ghostBtn("Apri ›");open.setOnClickListener(v->showIncomeMonth(month));row.addView(open,new LinearLayout.LayoutParams(dp(84),dp(46)));monthsCard.addView(row);}content.addView(monthsCard);

        java.util.List<String> pnames=db.portfolioNames(true);String defaultBroker=current.equals(TOTAL)?(pnames.isEmpty()?DbHelper.DIRECTA:pnames.get(0)):current;
        LinearLayout form=card();form.addView(sectionTitle("＋ Nuovo provento"));
        String[] brokerNames=pnames.toArray(new String[0]);int defIdx=Math.max(0,pnames.indexOf(defaultBroker));Spinner brokerSp=spinner(brokerNames,defIdx);if(current.equals(TOTAL))form.addView(brokerSp);
        Spinner monthSp=spinner(months,curMonth-1);form.addView(monthSp);EditText date=textField("Data (YYYY-MM-DD)","2026-"+String.format(Locale.US,"%02d",monthSp.getSelectedItemPosition()+1)+"-01");form.addView(date);
        form.addView(tv("Categoria del provento",12,true));Spinner cat=spinner(incomeCategories,0);form.addView(cat);TextView autoType=badge("Tipo: "+incomeTypeForCategory(cat.getSelectedItem().toString()));form.addView(autoType);
        cat.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){autoType.setText("Tipo: "+incomeTypeForCategory(cat.getSelectedItem().toString()));}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        EditText instrument=textField("Strumento / nome","");form.addView(instrument);EditText isin=textField("ISIN (facoltativo)","");form.addView(isin);
        Spinner amountMode=spinner(new String[]{"Importo lordo","Importo già netto"},0);form.addView(tv("Importo",12,true));form.addView(amountMode);EditText gross=field("Importo €",null);form.addView(gross);EditText tax=field("Aliquota % (solo se lordo)",db.getTaxRate()*100);form.addView(tax);EditText notes=textField("Note","");form.addView(notes);
        TextView netPreview=tv("Netto calcolato: -",14,true);form.addView(netPreview);Runnable preview=()->{Double g=num(gross),t=num(tax);boolean alreadyNet=amountMode.getSelectedItemPosition()==1;if(g==null)netPreview.setText("Netto calcolato: -");else if(alreadyNet)netPreview.setText("Importo già netto: "+euro.format(g)+" €");else netPreview.setText("Netto calcolato: "+euro.format(g*(1-(t==null?db.getTaxRate()*100:t)/100.0))+" € • imposte "+euro.format(g-g*(1-(t==null?db.getTaxRate()*100:t)/100.0))+" €");};
        amountMode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){tax.setEnabled(pos==0);preview.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});Button calc=ghostBtn("Calcola netto");calc.setOnClickListener(v->preview.run());form.addView(calc);
        Button save=primaryBtn("Salva provento");save.setOnClickListener(v->{Double g=num(gross);if(g==null){toast("Inserisci l'importo");return;}String selectedCategory=cat.getSelectedItem().toString(),selectedType=incomeTypeForCategory(selectedCategory);int m=monthSp.getSelectedItemPosition()+1;boolean alreadyNet=amountMode.getSelectedItemPosition()==1;double tr=alreadyNet?0:(num(tax)==null?db.getTaxRate()*100:num(tax))/100.0;String b=current.equals(TOTAL)?brokerSp.getSelectedItem().toString():current;db.addIncome(date.getText().toString().trim(),m,b,selectedCategory,instrument.getText().toString(),isin.getText().toString(),selectedType,g,tr,notes.getText().toString(),alreadyNet?"NETTO":"LORDO");db.captureDailySnapshot(currentDate());toast(selectedType+" salvato");showIncomeMonth(m);});form.addView(save);content.addView(form);

        LinearLayout list=card();list.addView(sectionTitle("Ultimi proventi"));Cursor c=broker==null?db.incomesActive():db.incomes(broker);int count=0;while(c.moveToNext()&&count<8){long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),inst=c.getString(c.getColumnIndexOrThrow("instrument")),ca=c.getString(c.getColumnIndexOrThrow("category")),rawType=c.getString(c.getColumnIndexOrThrow("income_type")),isinVal=c.getString(c.getColumnIndexOrThrow("isin"));double g=c.getDouble(c.getColumnIndexOrThrow("gross")),ne=c.getDouble(c.getColumnIndexOrThrow("net")),tr=c.getDouble(c.getColumnIndexOrThrow("tax_rate"));int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";int noteIdx=c.getColumnIndex("notes");String incomeNotes=noteIdx>=0&&!c.isNull(noteIdx)?c.getString(noteIdx):"";LinearLayout rr=hrow();TextView tx=financeText(dt+" • "+b+historicalIncomeTag(b,inst,incomeNotes)+"\n"+incomeGroupLabel(rawType)+" • "+ca+" • "+inst+"\n"+incomeAmountLine(g,ne,mode,incomeNotes),13,C_GREEN,false);tx.setOnClickListener(v->showIncomeRecordDetail(dt,b,ca,rawType,inst,isinVal,g,ne,tr,mode,incomeNotes));rr.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=ghostBtn("×");del.setTextColor(C_RED);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo provento?").setPositiveButton("Elimina",(dd,w)->{db.deleteIncome(id);showIncome();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(40),dp(40)));list.addView(rr);count++;}c.close();if(count==0)list.addView(muted("Nessun provento inserito.",12));content.addView(list);

        LinearLayout chart=card();chart.addView(sectionTitle("Proventi mensili"));chart.addView(new ChartView(this,monthlyIncome(broker),false,"€",m->showIncomeMonth(m)),new LinearLayout.LayoutParams(-1,dp(112)));content.addView(chart);
    }

    void showIncomeMonth(int month){
        if(month<1||month>12){showIncome();return;}heading("Proventi • "+months[month-1],current);
        Button back=btn("← Tutti i mesi");back.setOnClickListener(v->showIncome());content.addView(back);
        double gross=scopeIncomeMonth(month,"gross"),net=scopeIncomeMonth(month,"net");boolean incomplete=scopeIncompleteNetMonth(month);double knownNet=current.equals(TOTAL)?db.sumKnownNetMonthActive(month):db.sumKnownNetMonth(current,month);double taxesMonth=current.equals(TOTAL)?db.sumIncomeTaxesMonthActive(month):db.sumIncomeTaxesMonth(current,month);Cursor countCursor=scopeIncomesForMonth(month);int count=countCursor.getCount();countCursor.close();
        LinearLayout summary=card();summary.addView(tv(months[month-1]+" 2026",19,true));LinearLayout mr1=hrow();mr1.addView(kpiValueColor("Lordo mese",euro.format(gross)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));gap(mr1,6);mr1.addView(kpiValueColor(incomplete?"Netto noto":"Netto mese",euro.format(incomplete?knownNet:net)+" €",C_GREEN),new LinearLayout.LayoutParams(0,-2,1));summary.addView(mr1);gap(summary,6);LinearLayout mr2=hrow();mr2.addView(kpiValueColor("Tasse mese",euro.format(taxesMonth)+" €",C_RED),new LinearLayout.LayoutParams(0,-2,1));gap(mr2,6);mr2.addView(kpi("Movimenti",String.valueOf(count)),new LinearLayout.LayoutParams(0,-2,1));summary.addView(mr2);if(incomplete)summary.addView(muted("Netto mese parziale.",12));content.addView(summary);

        LinkedHashMap<String,Double> groups=new LinkedHashMap<>();groups.put("Cedole",0.0);groups.put("Dividendi",0.0);groups.put("Distribuzioni",0.0);groups.put("Interessi",0.0);groups.put("Altri proventi",0.0);
        LinkedHashMap<String,Double> brokers=new LinkedHashMap<>();Cursor agg=scopeIncomesForMonth(month);while(agg.moveToNext()){String t=incomeGroupLabel(agg.getString(agg.getColumnIndexOrThrow("income_type"))),b=agg.getString(agg.getColumnIndexOrThrow("broker"));double g=agg.getDouble(agg.getColumnIndexOrThrow("gross"));groups.put(t,groups.get(t)+g);brokers.put(b,brokers.containsKey(b)?brokers.get(b)+g:g);}agg.close();
        LinearLayout breakdown=card();breakdown.addView(tv("Composizione del mese",17,true));for(Map.Entry<String,Double> e:groups.entrySet())if(e.getValue()!=0){TextView pv=financeText(e.getKey()+": "+euro.format(e.getValue())+" €",13,C_GREEN,false);breakdown.addView(pv);};if(count==0)breakdown.addView(tv("Nessun provento registrato in questo mese.",13,false));if(current.equals(TOTAL)&&!brokers.isEmpty()){breakdown.addView(tv("Per portafoglio",14,true));for(Map.Entry<String,Double> e:brokers.entrySet()){TextView pv=financeText(e.getKey()+": "+euro.format(e.getValue())+" €",13,C_GREEN,false);breakdown.addView(pv);};}content.addView(breakdown);

        LinearLayout list=card();list.addView(tv("Movimenti di "+months[month-1],17,true));Cursor c=scopeIncomesForMonth(month);int n=0;while(c.moveToNext()){
            long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),inst=c.getString(c.getColumnIndexOrThrow("instrument")),ca=c.getString(c.getColumnIndexOrThrow("category")),rawType=c.getString(c.getColumnIndexOrThrow("income_type")),isinVal=c.getString(c.getColumnIndexOrThrow("isin"));double g=c.getDouble(c.getColumnIndexOrThrow("gross")),ne=c.getDouble(c.getColumnIndexOrThrow("net")),tr=c.getDouble(c.getColumnIndexOrThrow("tax_rate"));int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";int noteIdx=c.getColumnIndex("notes");String notes=noteIdx>=0&&!c.isNull(noteIdx)?c.getString(noteIdx):"";
            LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);TextView tx=financeText(dt+" • "+b+historicalIncomeTag(b,inst,notes)+"\n"+incomeGroupLabel(rawType)+" • "+inst+"\n"+incomeAmountLine(g,ne,mode,notes),13,C_GREEN,false);tx.setOnClickListener(v->showIncomeRecordDetail(dt,b,ca,rawType,inst,isinVal,g,ne,tr,mode,notes));rr.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=ghostBtn("×");del.setTextColor(C_RED);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo provento?").setPositiveButton("Elimina",(dd,w)->{db.deleteIncome(id);showIncomeMonth(month);}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(40),dp(40)));list.addView(rr);n++;
        }c.close();if(n==0)list.addView(tv("Nessun movimento nel mese.",13,false));content.addView(list);
    }

    void showIncomeRecordDetail(String date,String broker,String category,String rawType,String instrument,String isin,double gross,double net,double taxRate,String mode,String notes){
        StringBuilder msg=new StringBuilder();boolean historical=isHistoricalAggregateIncome(broker,instrument,notes);msg.append(historical?"Data tecnica: ":"Data: ").append(date).append("\nPortafoglio: ").append(broker);if(historical)msg.append("\nOrigine: Storico aggregato Directa\nNota data: non necessariamente la data effettiva di accredito");msg.append("\nTipo: ").append(incomeGroupLabel(rawType));if(rawType!=null&&!rawType.isEmpty()&&!incomeGroupLabel(rawType).equals(rawType))msg.append(" (").append(rawType).append(")");msg.append("\nCategoria: ").append(category);if(instrument!=null&&!instrument.isEmpty())msg.append("\nStrumento: ").append(instrument);if(isin!=null&&!isin.isEmpty())msg.append("\nISIN: ").append(isin);msg.append("\n\n").append(incomeAmountLine(gross,net,mode,notes));if(!"NETTO".equalsIgnoreCase(mode))msg.append("\nAliquota registrata: ").append(String.format(Locale.ITALY,"%.2f%%",taxRate*100));if(notes!=null&&!notes.trim().isEmpty())msg.append("\n\nNote: ").append(notes);
        new AlertDialog.Builder(this).setTitle("Dettaglio provento").setMessage(msg.toString()).setPositiveButton("Chiudi",null).show();
    }

    void showReturns(){
        heading("Rendimento",current);
        if(current.equals(TOTAL)){showReturnSummary(null);return;}
        Spinner sp=spinner(months,Calendar.getInstance().get(Calendar.MONTH));content.addView(sp);LinearLayout form=card();content.addView(form);
        Runnable load=()->{
            form.removeAllViews();int m=sp.getSelectedItemPosition()+1;
            Double ini=null,fin=null,dep=null,wd=null,iniInv=null,iniCash=null,finInv=null,finCash=null;String notes="";
            Cursor c=db.snapshot(current,m);if(c.moveToFirst()){ini=getNullable(c,"initial_value");fin=getNullable(c,"final_value");dep=getNullable(c,"deposits");wd=getNullable(c,"withdrawals");iniInv=getNullable(c,"initial_invested");iniCash=getNullable(c,"initial_cash");finInv=getNullable(c,"final_invested");finCash=getNullable(c,"final_cash");int i=c.getColumnIndexOrThrow("notes");notes=c.isNull(i)?"":c.getString(i);}c.close();
            final Double oldIni=ini,oldFin=fin;
            double grossM=db.sumIncomeMonth(current,m,"gross"), netM=db.sumIncomeMonth(current,m,"net"), knownNetM=db.sumKnownNetMonth(current,m);boolean incompleteNetM=db.hasIncompleteNetMonth(current,m);
            form.addView(tv(months[m-1]+" – "+current,17,true));
            form.addView(tv("Proventi: "+euro.format(grossM)+" € lordi | "+(incompleteNetM?("netto noto "+euro.format(knownNetM)+" €"):(euro.format(netM)+" € netti")),14,true));
            if((oldIni!=null&&iniInv==null&&iniCash==null)||(oldFin!=null&&finInv==null&&finCash==null))
                form.addView(tv("Questo mese contiene un vecchio patrimonio totale. Se vuoi distinguere titoli e liquidità, completa i campi qui sotto; lo storico non viene cancellato.",12,false));
            EditText fIniInv=field("Valore titoli INIZIALE €",iniInv),fIniCash=field("Liquidità INIZIALE €",iniCash),fFinInv=field("Valore titoli FINALE €",finInv),fFinCash=field("Liquidità FINALE €",finCash),fDep=field("Versamenti ESTERNI €",dep),fWd=field("Prelievi ESTERNI €",wd),fNotes=textField("Note",notes);
            form.addView(fIniInv);form.addView(fIniCash);form.addView(fFinInv);form.addView(fFinCash);form.addView(fDep);form.addView(fWd);form.addView(fNotes);
            TextView out=tv("",15,true);Button save=btn("Calcola e salva");save.setOnClickListener(v->{
                Double iInv=num(fIniInv),iCash=num(fIniCash),fInv=num(fFinInv),fCash=num(fFinCash);
                Double iniTotal=sumParts(iInv,iCash),finTotal=sumParts(fInv,fCash);
                if(iniTotal==null||finTotal==null){toast("Inserisci Valore titoli e/o Liquidità sia iniziali sia finali");return;}
                db.saveSnapshotSplit(current,m,iInv,iCash,fInv,fCash,num(fDep),num(fWd),fNotes.getText().toString());
                Double rr=calcReturnValues(iniTotal,finTotal,num(fDep),num(fWd));
                out.setText("Patrimonio iniziale: "+euro.format(iniTotal)+" €\nPatrimonio finale: "+euro.format(finTotal)+" €\nRendimento del mese: "+(rr==null?"Non disponibile":pct.format(rr))+"\nProventi lordi mese: "+euro.format(grossM)+" €\n"+(incompleteNetM?("Netto noto mese: "+euro.format(knownNetM)+" € • da completare"):("Proventi netti mese: "+euro.format(netM)+" €")));toast("Patrimonio e rendimento salvati");
            });form.addView(save);form.addView(out);
            Button calcInfo=ghostBtn("ⓘ Calcolo rendimento");calcInfo.setOnClickListener(v->showReturnInfo());form.addView(calcInfo);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){load.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        showReturnSummary(current);
    }

    void showReturnInfo(){new AlertDialog.Builder(this).setTitle("Calcolo rendimento").setMessage("Patrimonio = Valore titoli + Liquidità. Versamenti e prelievi esterni indicano solo denaro che entra o esce dal broker. Dividendi, cedole e operazioni con liquidità già presente restano flussi interni.").setPositiveButton("Chiudi",null).show();}

    void showReturnSummary(String broker){
        LinearLayout x=card();x.addView(tv("Andamento rendimento mensile",17,true));
        x.addView(new ChartView(this,monthlyReturns(broker),false,"%"),new LinearLayout.LayoutParams(-1,dp(140)));
        Double ytd=calcYtdReturn(broker);
        x.addView(tv("Rendimento da inizio anno: "+(ytd==null?"Non disponibile":pct.format(ytd)),15,true));
        if(ytd==null){Button b=ghostBtn("ⓘ Dati richiesti");b.setOnClickListener(v->showReturnInfo());x.addView(b);}
        content.addView(x);
    }

    Double sumParts(Double invested,Double cash){if(invested==null&&cash==null)return null;return (invested==null?0:invested)+(cash==null?0:cash);}
    Double calcReturnValues(Double ini,Double fin,Double dep,Double wd){if(ini==null||fin==null)return null;double flow=(dep==null?0:dep)-(wd==null?0:wd);double denom=ini+0.5*flow;if(Math.abs(denom)<0.000001)return null;return (fin-ini-flow)/denom;}
    Double calcMonthlyReturn(String broker,int month){
        if(broker==null){double ini=0,fin=0,dep=0,wd=0;boolean any=false;for(String b:db.portfolioNames(true)){Double[] x=snapshotValues(b,month);boolean has=x[0]!=null&&x[1]!=null;if(has){any=true;ini+=x[0];fin+=x[1];dep+=x[2]==null?0:x[2];wd+=x[3]==null?0:x[3];}}return any?calcReturnValues(ini,fin,dep,wd):null;}
        Double[] x=snapshotValues(broker,month);return calcReturnValues(x[0],x[1],x[2],x[3]);
    }
    Double[] snapshotValues(String broker,int month){Double[] a={null,null,null,null};Cursor c=db.snapshot(broker,month);if(c.moveToFirst()){a[0]=getNullable(c,"initial_value");a[1]=getNullable(c,"final_value");a[2]=getNullable(c,"deposits");a[3]=getNullable(c,"withdrawals");}c.close();return a;}
    double[] monthlyReturns(String broker){double[] a=new double[12];for(int m=1;m<=12;m++){Double r=calcMonthlyReturn(broker,m);a[m-1]=r==null?Double.NaN:r*100;}return a;}
    Double calcYtdReturn(String broker){
        double currentValue=broker==null?db.latestPortfolioValueAllActive():db.latestPortfolioValue(broker);
        if(currentValue<=0)return null;
        double prod=1;boolean any=false;
        for(int m=1;m<=12;m++){Double r=calcMonthlyReturn(broker,m);if(r!=null){prod*=1+r;any=true;}}
        return any?prod-1:null;
    }

    TreeMap<String,Double> grossPerformanceByDate(String broker){
        TreeMap<String,Double> out=new TreeMap<>();java.util.List<String> brokers=broker==null?db.portfolioNames(true):java.util.Arrays.asList(broker);
        for(String b:brokers){
            Cursor ic=db.incomes(b);while(ic.moveToNext()){String date=ic.getString(ic.getColumnIndexOrThrow("date")),inst=ic.getString(ic.getColumnIndexOrThrow("instrument"));int ni=ic.getColumnIndex("notes");String notes=ni>=0&&!ic.isNull(ni)?ic.getString(ni):"";if(isHistoricalAggregateIncome(b,inst,notes))continue;int mi=ic.getColumnIndex("amount_mode");String mode=mi>=0&&!ic.isNull(mi)?ic.getString(mi):"LORDO";if("NETTO".equalsIgnoreCase(mode))continue;double x=ic.getDouble(ic.getColumnIndexOrThrow("gross"));if(date!=null&&!date.trim().isEmpty())out.put(date,out.containsKey(date)?out.get(date)+x:x);}ic.close();
            Cursor sc=db.sales(b);while(sc.moveToNext()){String date=sc.getString(sc.getColumnIndexOrThrow("date"));double x=sc.getDouble(sc.getColumnIndexOrThrow("realized_pl_gross"));if(date!=null&&!date.trim().isEmpty())out.put(date,out.containsKey(date)?out.get(date)+x:x);}sc.close();
        }
        return out;
    }
    String displayDate(String iso){try{if(iso!=null&&iso.matches("\\d{4}-\\d{2}-\\d{2}"))return iso.substring(8,10)+"/"+iso.substring(5,7)+"/"+iso.substring(0,4);}catch(Exception ignored){}return iso==null?"":iso;}
    int performanceMonth(String date){try{return Integer.parseInt(date.substring(5,7));}catch(Exception e){return 0;}}
    int performanceYear(String date){try{return Integer.parseInt(date.substring(0,4));}catch(Exception e){return 0;}}
    boolean hasPerformanceValue(double value){return Math.abs(value)>0.0001;}
    double grossHistoricalAggregateIncome(String broker){double x=0;java.util.List<String> brokers=broker==null?db.portfolioNames(true):java.util.Arrays.asList(broker);for(String b:brokers){Cursor c=db.incomes(b);while(c.moveToNext()){String inst=c.getString(c.getColumnIndexOrThrow("instrument"));int ni=c.getColumnIndex("notes");String notes=ni>=0&&!c.isNull(ni)?c.getString(ni):"";if(isHistoricalAggregateIncome(b,inst,notes))x+=c.getDouble(c.getColumnIndexOrThrow("gross"));}c.close();}return x;}
    double grossPerformanceForMonth(String broker,int year,int month){double x=0;for(Map.Entry<String,Double> e:grossPerformanceByDate(broker).entrySet())if(performanceYear(e.getKey())==year&&performanceMonth(e.getKey())==month)x+=e.getValue();return x;}
    double grossPerformanceForYear(String broker,int year){double x=year==2026?grossHistoricalAggregateIncome(broker):0;for(Map.Entry<String,Double> e:grossPerformanceByDate(broker).entrySet())if(performanceYear(e.getKey())==year)x+=e.getValue();return x;}
    boolean dateMatchesPerformancePeriod(String date,int year,int month,String exactDate){
        if(date==null||date.trim().isEmpty())return false;
        if(exactDate!=null)return exactDate.equals(date);
        if(performanceYear(date)!=year)return false;
        return month<=0||performanceMonth(date)==month;
    }
    double performanceCostsForPeriod(String broker,int year,int month,String exactDate){
        double total=0;java.util.List<String> brokers=broker==null?db.portfolioNames(true):java.util.Arrays.asList(broker);
        for(String b:brokers){
            Cursor ic=db.incomes(b);while(ic.moveToNext()){String d=ic.getString(ic.getColumnIndexOrThrow("date"));if(!dateMatchesPerformancePeriod(d,year,month,exactDate))continue;double gross=ic.getDouble(ic.getColumnIndexOrThrow("gross")),net=ic.getDouble(ic.getColumnIndexOrThrow("net"));total+=Math.max(0,gross-net);}ic.close();
            Cursor cc=db.costs(b);while(cc.moveToNext()){String d=cc.getString(cc.getColumnIndexOrThrow("date"));if(dateMatchesPerformancePeriod(d,year,month,exactDate))total+=Math.max(0,cc.getDouble(cc.getColumnIndexOrThrow("amount")));}cc.close();
            Cursor sc=db.sales(b);while(sc.moveToNext()){String d=sc.getString(sc.getColumnIndexOrThrow("date"));if(!dateMatchesPerformancePeriod(d,year,month,exactDate))continue;total+=Math.max(0,sc.getDouble(sc.getColumnIndexOrThrow("commission")))+Math.max(0,sc.getDouble(sc.getColumnIndexOrThrow("taxes")));}sc.close();
        }
        return total;
    }
    TextView performanceMetric(String label,double amount,int amountColor){
        String value=euro.format(amount)+" €",text=label+"  "+value;SpannableString sp=new SpannableString(text);sp.setSpan(new ForegroundColorSpan(C_TEXT),0,label.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new ForegroundColorSpan(amountColor),label.length()+2,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);TextView v=tv("",13,true);v.setText(sp);return v;
    }
    void addPerformanceCostsSummary(double gross,double costs){addPerformanceCostsSummary(gross,costs,false);}
    void addPerformanceCostsSummary(double gross,double costs,boolean incomplete){
        if(costs<=0.0001&&!incomplete)return;
        LinearLayout box=card();box.setPadding(dp(12),dp(10),dp(12),dp(10));double net=gross-costs;
        box.addView(performanceMetric("Lordo",gross,gross>0?C_GREEN:(gross<0?C_RED:C_TEXT)));
        box.addView(performanceMetric(incomplete?"Costi/tasse noti":"Costi/tasse",costs,C_RED));
        box.addView(performanceMetric(incomplete?"Netto noto":"Netto",net,net>0?C_GREEN:(net<0?C_RED:C_TEXT)));
        content.addView(box);
    }
    boolean hasPerformanceInMonth(TreeMap<String,Double> data,int year,int month){for(Map.Entry<String,Double> e:data.entrySet())if(performanceYear(e.getKey())==year&&performanceMonth(e.getKey())==month&&hasPerformanceValue(e.getValue()))return true;return false;}
    LinearLayout performanceValueRow(String label,double amount){LinearLayout row=hrow();row.setPadding(dp(10),dp(10),dp(10),dp(10));row.setBackgroundResource(R.drawable.list_row);TextView l=tv(label,16,false);row.addView(l,new LinearLayout.LayoutParams(0,-2,1));if(hasPerformanceValue(amount)){TextView v=signedText(euro.format(amount)+" €",amount,17,true);v.setGravity(Gravity.END);row.addView(v);}return row;}
    String shiftPerformanceDate(String iso,int days){try{Calendar c=Calendar.getInstance();c.set(Calendar.YEAR,Integer.parseInt(iso.substring(0,4)));c.set(Calendar.MONTH,Integer.parseInt(iso.substring(5,7))-1);c.set(Calendar.DAY_OF_MONTH,Integer.parseInt(iso.substring(8,10)));c.add(Calendar.DAY_OF_MONTH,days);return String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}catch(Exception e){return currentDate();}}
    void showPerformanceInfo(int year,String broker){
        double historical=year==2026?grossHistoricalAggregateIncome(broker):0;String msg="Performance = proventi lordi + P/L realizzato lordo. Il lordo non viene modificato; quando esistono costi o tasse viene mostrato anche il netto separatamente.";if(hasPerformanceValue(historical))msg+="\n\nIl totale "+year+" include "+euro.format(historical)+" € di storico aggregato senza attribuzione mensile.";new AlertDialog.Builder(this).setTitle("Performance").setMessage(msg).setPositiveButton("Chiudi",null).show();
    }
    void showPerformanceDatePicker(String selectedDay){String base=selectedDay==null?currentDate():selectedDay;int y=performanceYear(base),m=performanceMonth(base),d=1;try{d=Integer.parseInt(base.substring(8,10));}catch(Exception ignored){}Calendar now=Calendar.getInstance();if(y<1900)y=now.get(Calendar.YEAR);if(m<1||m>12)m=now.get(Calendar.MONTH)+1;final int yy=y,mm=m,dd=d;new DatePickerDialog(this,(view,year,month,day)->{String iso=String.format(Locale.US,"%04d-%02d-%02d",year,month+1,day);showPerformance(0,year,month+1,iso);},yy,mm-1,dd).show();}
    void showPerformanceMonthYearPicker(int year,int month){LinearLayout box=hrow();box.setPadding(dp(14),dp(4),dp(14),dp(4));NumberPicker mp=new NumberPicker(this);mp.setMinValue(1);mp.setMaxValue(12);mp.setDisplayedValues(months);mp.setValue(Math.max(1,Math.min(12,month)));NumberPicker yp=new NumberPicker(this);yp.setMinValue(2000);yp.setMaxValue(2100);yp.setValue(Math.max(2000,Math.min(2100,year)));box.addView(mp,new LinearLayout.LayoutParams(0,-2,1));gap(box,10);box.addView(yp,new LinearLayout.LayoutParams(0,-2,1));new AlertDialog.Builder(this).setTitle("Seleziona mese e anno").setView(box).setPositiveButton("Apri",(d,w)->showPerformance(1,yp.getValue(),mp.getValue(),null)).setNegativeButton("Annulla",null).show();}
    void showPerformanceYearPicker(int year){NumberPicker yp=new NumberPicker(this);yp.setMinValue(2000);yp.setMaxValue(2100);yp.setValue(Math.max(2000,Math.min(2100,year)));yp.setWrapSelectorWheel(false);new AlertDialog.Builder(this).setTitle("Seleziona anno").setView(yp).setPositiveButton("Apri",(d,w)->showPerformance(2,yp.getValue(),1,null)).setNegativeButton("Annulla",null).show();}
    void showPerformance(int mode,int month,String selectedDay){Calendar c=Calendar.getInstance();int year=c.get(Calendar.YEAR);if(selectedDay!=null&&performanceYear(selectedDay)>0)year=performanceYear(selectedDay);showPerformance(mode,year,month,selectedDay);}
    void showPerformance(int mode,int year,int month,String selectedDay){
        if(current.equals("HOME"))setPortfolio(TOTAL);String broker=brokerFilter();heading("Performance",current);setNavActive("PORTFOLIO");
        Calendar now=Calendar.getInstance();int selectedYear=year<1900?now.get(Calendar.YEAR):year;int selectedMonth=month<1||month>12?now.get(Calendar.MONTH)+1:month;if(mode==0&&selectedDay!=null&&performanceYear(selectedDay)>0){selectedYear=performanceYear(selectedDay);selectedMonth=performanceMonth(selectedDay);}final int viewYear=selectedYear,viewMonth=selectedMonth;
        LinearLayout tabsCard=card();tabsCard.setPadding(dp(8),dp(9),dp(8),dp(9));LinearLayout tabs=hrow();Button day=mode==0?primaryBtn("GIORNO"):ghostBtn("GIORNO");Button mon=mode==1?primaryBtn("MESE"):ghostBtn("MESE");Button yearBtn=mode==2?primaryBtn("ANNO"):ghostBtn("ANNO");Button info=infoBtn();for(Button b:new Button[]{day,mon,yearBtn}){b.setSingleLine(true);b.setTextSize(14);b.setPadding(dp(5),dp(4),dp(5),dp(4));}
        day.setOnClickListener(v->showPerformance(0,now.get(Calendar.YEAR),now.get(Calendar.MONTH)+1,currentDate()));mon.setOnClickListener(v->showPerformance(1,viewYear,viewMonth,null));yearBtn.setOnClickListener(v->showPerformance(2,viewYear,viewMonth,null));info.setOnClickListener(v->showPerformanceInfo(viewYear,broker));tabs.addView(day,new LinearLayout.LayoutParams(0,dp(52),1));gap(tabs,4);tabs.addView(mon,new LinearLayout.LayoutParams(0,dp(52),1));gap(tabs,4);tabs.addView(yearBtn,new LinearLayout.LayoutParams(0,dp(52),1));gap(tabs,4);tabs.addView(info,new LinearLayout.LayoutParams(dp(42),dp(52)));tabsCard.addView(tabs);content.addView(tabsCard);
        TreeMap<String,Double> data=grossPerformanceByDate(broker);
        if(mode==0){
            String dayKey=selectedDay==null?currentDate():selectedDay;if(performanceYear(dayKey)==0)dayKey=currentDate();final String selectedKey=dayKey;final String prevKey=shiftPerformanceDate(dayKey,-1),nextKey=shiftPerformanceDate(dayKey,1);Double total=data.get(dayKey);
            LinearLayout nav=card();LinearLayout row=hrow();Button prev=ghostBtn("‹");prev.setOnClickListener(v->showPerformance(0,performanceYear(prevKey),performanceMonth(prevKey),prevKey));Button next=ghostBtn("›");next.setOnClickListener(v->showPerformance(0,performanceYear(nextKey),performanceMonth(nextKey),nextKey));LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);TextView dateLabel=tv("📅  "+displayDate(dayKey),18,true);dateLabel.setTextColor(C_BLUE);dateLabel.setGravity(Gravity.CENTER);center.addView(dateLabel);if(total!=null&&hasPerformanceValue(total)){TextView amount=signedText(euro.format(total)+" €",total,18,true);amount.setGravity(Gravity.CENTER);center.addView(amount);}center.setPadding(dp(4),dp(2),dp(4),dp(2));center.setOnClickListener(v->showPerformanceDatePicker(selectedKey));row.addView(prev,new LinearLayout.LayoutParams(dp(54),dp(52)));row.addView(center,new LinearLayout.LayoutParams(0,-2,1));row.addView(next,new LinearLayout.LayoutParams(dp(54),dp(52)));nav.addView(row);content.addView(nav);double grossDay=total==null?0:total,costsDay=performanceCostsForPeriod(broker,performanceYear(dayKey),performanceMonth(dayKey),dayKey);addPerformanceCostsSummary(grossDay,costsDay);if((total!=null&&hasPerformanceValue(total))||costsDay>0.0001)addPerformanceDayDetails(broker,dayKey);return;
        }
        if(mode==1){
            int py=viewMonth==1?viewYear-1:viewYear,pm=viewMonth==1?12:viewMonth-1,ny=viewMonth==12?viewYear+1:viewYear,nm=viewMonth==12?1:viewMonth+1;double total=grossPerformanceForMonth(broker,viewYear,viewMonth);LinearLayout nav=card();LinearLayout row=hrow();Button prev=ghostBtn("‹");prev.setOnClickListener(v->showPerformance(1,py,pm,null));Button next=ghostBtn("›");next.setOnClickListener(v->showPerformance(1,ny,nm,null));LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);TextView lab=tv(months[viewMonth-1]+" "+viewYear,18,true);lab.setTextColor(C_BLUE);lab.setGravity(Gravity.CENTER);center.addView(lab);if(hasPerformanceValue(total)){TextView amount=signedText(euro.format(total)+" €",total,18,true);amount.setGravity(Gravity.CENTER);center.addView(amount);}center.setOnClickListener(v->showPerformanceMonthYearPicker(viewYear,viewMonth));row.addView(prev,new LinearLayout.LayoutParams(dp(54),dp(52)));row.addView(center,new LinearLayout.LayoutParams(0,-2,1));row.addView(next,new LinearLayout.LayoutParams(dp(54),dp(52)));nav.addView(row);content.addView(nav);double costsMonth=performanceCostsForPeriod(broker,viewYear,viewMonth,null);addPerformanceCostsSummary(total,costsMonth);
            for(Map.Entry<String,Double> e:data.entrySet())if(performanceYear(e.getKey())==viewYear&&performanceMonth(e.getKey())==viewMonth&&hasPerformanceValue(e.getValue())){LinearLayout pr=performanceValueRow(displayDate(e.getKey()),e.getValue());String d=e.getKey();pr.setOnClickListener(v->showPerformance(0,viewYear,viewMonth,d));content.addView(pr);gap(content,5);}return;
        }
        double yearTotal=grossPerformanceForYear(broker,viewYear);double historicalAggregate=viewYear==2026?grossHistoricalAggregateIncome(broker):0;LinearLayout yh=card();LinearLayout yr=hrow();Button prevYear=ghostBtn("‹");prevYear.setOnClickListener(v->showPerformance(2,viewYear-1,1,null));Button nextYear=ghostBtn("›");nextYear.setOnClickListener(v->showPerformance(2,viewYear+1,1,null));LinearLayout ycenter=new LinearLayout(this);ycenter.setOrientation(LinearLayout.VERTICAL);ycenter.setGravity(Gravity.CENTER);TextView yearLabel=tv(String.valueOf(viewYear),19,true);yearLabel.setTextColor(C_BLUE);yearLabel.setGravity(Gravity.CENTER);ycenter.addView(yearLabel);if(hasPerformanceValue(yearTotal)){TextView amount=signedText(euro.format(yearTotal)+" €",yearTotal,19,true);amount.setGravity(Gravity.CENTER);ycenter.addView(amount);}ycenter.setOnClickListener(v->showPerformanceYearPicker(viewYear));yr.addView(prevYear,new LinearLayout.LayoutParams(dp(54),dp(52)));yr.addView(ycenter,new LinearLayout.LayoutParams(0,-2,1));yr.addView(nextYear,new LinearLayout.LayoutParams(dp(54),dp(52)));yh.addView(yr);content.addView(yh);double costsYear=performanceCostsForPeriod(broker,viewYear,0,null);boolean incompleteYear=(broker==null?db.hasIncompleteNetActive():db.hasIncompleteNet(broker))||hasPerformanceValue(historicalAggregate);addPerformanceCostsSummary(yearTotal,costsYear,incompleteYear);
        for(int m=1;m<=12;m++){final int mm=m;if(!hasPerformanceInMonth(data,viewYear,mm))continue;double mt=grossPerformanceForMonth(broker,viewYear,mm);LinearLayout monthCard=card();LinearLayout mh=hrow();TextView ml=tv(months[mm-1]+" "+viewYear,17,true);mh.addView(ml,new LinearLayout.LayoutParams(0,-2,1));if(hasPerformanceValue(mt)){TextView mv=signedText(euro.format(mt)+" €",mt,17,true);mv.setGravity(Gravity.END);mh.addView(mv);}TextView arrow=tv("›",22,true);arrow.setTextColor(C_BLUE);arrow.setGravity(Gravity.END);mh.addView(arrow,new LinearLayout.LayoutParams(dp(34),-2));monthCard.addView(mh);monthCard.setOnClickListener(v->showPerformance(1,viewYear,mm,null));content.addView(monthCard);}
    }
    void addPerformanceDayDetails(String broker,String date){
        LinearLayout details=card();details.addView(sectionTitle("Dettaglio giornata"));java.util.List<String> brokers=broker==null?db.portfolioNames(true):java.util.Arrays.asList(broker);int count=0;double incomes=0,realized=0;
        for(String b:brokers){Cursor ic=db.incomes(b);while(ic.moveToNext()){String d=ic.getString(ic.getColumnIndexOrThrow("date"));if(!date.equals(d))continue;int mi=ic.getColumnIndex("amount_mode");String mode=mi>=0&&!ic.isNull(mi)?ic.getString(mi):"LORDO";double x=ic.getDouble(ic.getColumnIndexOrThrow("gross"));String inst=ic.getString(ic.getColumnIndexOrThrow("instrument"));if(!"NETTO".equalsIgnoreCase(mode)&&hasPerformanceValue(x)){details.addView(signedText("Provento • "+b+(inst==null||inst.isEmpty()?"":" • "+inst)+"   "+euro.format(x)+" €",x,14,false));incomes+=x;count++;}}ic.close();Cursor sc=db.sales(b);while(sc.moveToNext()){String d=sc.getString(sc.getColumnIndexOrThrow("date"));if(!date.equals(d))continue;double x=sc.getDouble(sc.getColumnIndexOrThrow("realized_pl_gross"));String inst=sc.getString(sc.getColumnIndexOrThrow("instrument"));if(hasPerformanceValue(x)){details.addView(signedText("P/L realizzato lordo • "+b+" • "+inst+"   "+euro.format(x)+" €",x,14,false));realized+=x;count++;}}sc.close();}
        double dayCosts=performanceCostsForPeriod(broker,performanceYear(date),performanceMonth(date),date);if(count==0&&dayCosts<=0.0001)return;if(hasPerformanceValue(incomes)){gap(details,6);details.addView(signedText("Proventi lordi: "+euro.format(incomes)+" €",incomes,14,true));}if(hasPerformanceValue(realized))details.addView(signedText("P/L realizzato lordo: "+euro.format(realized)+" €",realized,14,true));if(dayCosts>0.0001)details.addView(performanceMetric("Costi/tasse",dayCosts,C_RED));content.addView(details);
    }

    void showPac(){
        heading("PAC",current);
        if(current.equals(TOTAL)){showPacTotal();return;}
        Spinner sp=spinner(months,Calendar.getInstance().get(Calendar.MONTH));content.addView(sp);LinearLayout form=card();content.addView(form);
        Runnable load=()->{
            form.removeAllViews();int m=sp.getSelectedItemPosition()+1;Double planned=null,ext=null,in=null;String notes="";Cursor c=db.pac(current,m);if(c.moveToFirst()){planned=getNullable(c,"planned");ext=getNullable(c,"external_actual");in=getNullable(c,"internal_actual");int ni=c.getColumnIndexOrThrow("notes");notes=c.isNull(ni)?"":c.getString(ni);}c.close();if(planned==null)planned=db.getPacDefault(current);
            boolean netIncomplete=db.hasIncompleteNetMonth(current,m)||db.hasCumulativeIncomeCoveringMonth(current,m);
            double netIncome=db.sumIncomeMonth(current,m,"net");
            double grossIncome=db.sumIncomeMonth(current,m,"gross");
            double suggestedInternal=netIncomplete?0:Math.min(netIncome,planned),suggestedExternal=netIncomplete?planned:Math.max(planned-suggestedInternal,0);
            form.addView(tv(months[m-1]+" – "+current,17,true));
            form.addView(tv(netIncomplete
                    ?"Proventi netti del mese: da completare • Lordi registrati: "+euro.format(grossIncome)+" €"
                    :"Proventi netti del mese: "+euro.format(netIncome)+" €",14,true));
            if(db.hasCumulativeIncomeCoveringMonth(current,m))
                form.addView(tv("Questo mese è coperto da proventi cumulativi/aggregati: la copertura netta mensile non viene stimata finché manca il dettaglio mensile.",12,false));
            EditText fPlan=field("PAC programmato €",planned),fExt=field("Capitale esterno effettivo €",ext),fIn=field("Proventi/reinvestimento interno €",in),fNotes=textField("Note",notes);form.addView(fPlan);form.addView(fExt);form.addView(fIn);form.addView(fNotes);
            Button suggest=btn("Usa copertura suggerita");
            suggest.setEnabled(!netIncomplete);
            suggest.setOnClickListener(v->{fIn.setText(trim(suggestedInternal));fExt.setText(trim(suggestedExternal));});
            form.addView(suggest);

            Button allInternal=btn("PAC tutto da liquidità interna");
            allInternal.setOnClickListener(v->{double p=n(fPlan);fExt.setText("0");fIn.setText(trim(p));});
            form.addView(allInternal);

            form.addView(tv(netIncomplete
                    ?"Copertura suggerita disattivata: il netto mensile non è completo. Puoi comunque registrare manualmente capitale esterno e finanziamento interno se li conosci."
                    :"Copertura suggerita = usa prima i proventi netti del mese e considera esterno il resto.\nPAC tutto da liquidità interna = 0 € esterno e 100% finanziato con liquidità/proventi già presenti nel broker.",12,false));

            TextView out=tv("",15,true);
            Button save=btn("Salva PAC");
            save.setOnClickListener(v->{
                double p=n(fPlan),e=n(fExt),ii=n(fIn);
                Runnable doSave=()->{
                    db.savePac(current,m,num(fPlan),num(fExt),num(fIn),fNotes.getText().toString());
                    double covInternal=p==0?0:ii/p;
                    double covExternal=p==0?0:e/p;
                    String coverage=netIncomplete?"Copertura da proventi del mese: da completare":"Copertura da proventi del mese: "+pct.format(p==0?0:netIncome/p);
                    String surplus=netIncomplete?"Surplus proventi del mese dopo PAC: da completare":"Surplus proventi del mese dopo PAC: "+euro.format(Math.max(netIncome-p,0))+" €";
                    out.setText(coverage
                            +"\nFinanziamento interno registrato: "+pct.format(covInternal)
                            +"\nCapitale esterno registrato: "+pct.format(covExternal)
                            +"\n"+surplus);
                    toast("PAC salvato");
                };
                double diff=Math.abs((e+ii)-p);
                if(p>0 && diff>0.01){
                    new AlertDialog.Builder(this)
                            .setTitle("Controlla composizione PAC")
                            .setMessage("Capitale esterno + finanziamento interno = "+euro.format(e+ii)+" €, mentre il PAC programmato è "+euro.format(p)+" €.\n\nDifferenza: "+euro.format(diff)+" €. Vuoi salvare comunque?")
                            .setPositiveButton("Salva comunque",(d,w)->doSave.run())
                            .setNegativeButton("Correggi",null)
                            .show();
                }else doSave.run();
            });
            form.addView(save);form.addView(out);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){load.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        showPacYear(current);
    }

    void showPacYear(String broker){
        LinearLayout c=card();c.addView(tv("Copertura PAC anno",17,true));double planned=0,ext=0,in=0;Cursor p=db.pacs(broker);while(p.moveToNext()){Double x=getNullable(p,"planned"),e=getNullable(p,"external_actual"),ii=getNullable(p,"internal_actual");if(x!=null)planned+=x;if(e!=null)ext+=e;if(ii!=null)in+=ii;}p.close();double net=db.sumIncome(broker,"net");boolean incomplete=db.hasIncompleteNet(broker)||db.hasAnyCumulativeIncome(broker);
        String netLine=incomplete?"da completare":euro.format(net)+" €";
        String covLine=incomplete?"da completare":pct.format(planned==0?0:net/planned);
        c.addView(tv("PAC programmato nei mesi registrati: "+euro.format(planned)+" €\nProventi netti da inizio anno: "+netLine+"\nCapitale esterno registrato: "+euro.format(ext)+" €\nReinvestimento interno registrato: "+euro.format(in)+" €\nCopertura teorica: "+covLine,14,false));
        if(db.hasAnyCumulativeIncome(broker))c.addView(muted("Copertura da completare: proventi aggregati presenti.",12));
        content.addView(c);
    }

    void showPacTotal(){
        int currentMonth=Calendar.getInstance().get(Calendar.MONTH)+1;
        LinearLayout c=card();c.addView(tv("PAC mensile complessivo",17,true));double totalPlan=0,totalExt=0;StringBuilder lines=new StringBuilder();for(String b:db.portfolioNames(true)){double p=getPacMonth(b,currentMonth),e=sumPacField(b,"external_actual");totalPlan+=p;totalExt+=e;lines.append(b).append(" programmato ").append(months[currentMonth-1].toLowerCase(Locale.ITALY)).append(": ").append(euro.format(p)).append(" €\n");}
        lines.append("PAC mensile totale: ").append(euro.format(totalPlan)).append(" €\n");
        lines.append("Capitale esterno registrato da inizio anno: ").append(euro.format(totalExt)).append(" €");
        c.addView(tv(lines.toString(),14,false));
        content.addView(c);

        LinearLayout chart=card();chart.addView(tv("Copertura netta mensile del PAC",17,true));
        double[] v=new double[12];java.util.Arrays.fill(v,Double.NaN);
        for(int m=1;m<=currentMonth;m++){
            double plan=0;for(String b:db.portfolioNames(true))plan+=getPacMonth(b,m);
            boolean unavailable=db.hasIncompleteNetMonthActive(m)||db.hasCumulativeIncomeCoveringMonthActive(m);
            if(!unavailable && plan>0){double net=db.sumIncomeMonthActive(m,"net");v[m-1]=100*net/plan;}
        }
        chart.addView(new ChartView(this,v,false,"%"),new LinearLayout.LayoutParams(-1,dp(140)));content.addView(chart);
    }
    double sumPacField(String broker,String field){Cursor c=db.pacs(broker);double x=0;while(c.moveToNext()){Double v=getNullable(c,field);if(v!=null)x+=v;}c.close();return x;}
    double getPacMonth(String broker,int month){Cursor c=db.pac(broker,month);double x=db.getPacDefault(broker);if(c.moveToFirst()){Double v=getNullable(c,"planned");if(v!=null)x=v;}c.close();return x;}

    String[] movementTypesForBroker(String broker){return db.isTradeRepublicProfile(broker)?tradeRepublicMovementTypes:genericMovementTypes;}
    String flowClassForMovement(String type){
        if(type.equals("Versamento personale"))return "ESTERNO_ENTRATA";
        if(type.equals("Prelievo"))return "ESTERNO_USCITA";
        if(type.startsWith("Pagamento carta"))return "ESCLUSO";
        if(type.equals("Saveback"))return "PREMIO";
        if(type.equals("Commissione")||type.equals("Imposta"))return "COSTO";
        if(type.equals("Altro"))return "ALTRO";
        return "INTERNO";
    }
    void movementDialog(String broker){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        Spinner month=spinner(months,Calendar.getInstance().get(Calendar.MONTH));
        EditText date=textField("Data (YYYY-MM-DD)",currentDate());
        Spinner type=spinner(movementTypesForBroker(broker),0);
        EditText amount=field("Importo €",null);EditText notes=textField("Note","");
        box.addView(tv("Profilo broker: "+db.getBrokerProfile(broker),12,true));box.addView(month);box.addView(date);box.addView(type);box.addView(amount);box.addView(notes);
        new AlertDialog.Builder(this).setTitle("Nuovo movimento • "+broker).setView(box).setPositiveButton("Salva",(d,w)->{
            Double a=num(amount);if(a==null||a<0){toast("Importo non valido");return;}String t=type.getSelectedItem().toString();String fc=flowClassForMovement(t);db.addMovement(date.getText().toString().trim(),month.getSelectedItemPosition()+1,broker,t,fc,a,notes.getText().toString());db.captureDailySnapshot(currentDate());toast("Movimento salvato come "+fc);showHistory();
        }).setNegativeButton("Annulla",null).show();
    }
    void addMovementSection(){
        LinearLayout mv=card();mv.addView(tv("Movimenti classificati",17,true));String broker=brokerFilter();
        if(broker!=null){mv.addView(muted("Profilo: "+db.getBrokerProfile(broker),12));Button add=btn("＋ Nuovo movimento");add.setOnClickListener(v->movementDialog(broker));mv.addView(add);}
        double extIn=db.sumMovements(broker,"ESTERNO_ENTRATA"),extOut=db.sumMovements(broker,"ESTERNO_USCITA"),internal=db.sumMovements(broker,"INTERNO"),reward=db.sumMovements(broker,"PREMIO"),excluded=db.sumMovements(broker,"ESCLUSO");
        if(Math.abs(extIn)>0.0001)mv.addView(financeText("Versamenti esterni: "+euro.format(extIn)+" €",13,C_TEXT,false));
        if(Math.abs(extOut)>0.0001)mv.addView(financeText("Prelievi esterni: "+euro.format(extOut)+" €",13,C_TEXT,false));
        if(Math.abs(internal)>0.0001)mv.addView(financeText("Round up / capitale proprio: "+euro.format(internal)+" €",13,Color.rgb(116,190,255),false));
        if(Math.abs(reward)>0.0001)mv.addView(financeText("Premi/Saveback: +"+euro.format(reward)+" €",13,C_GREEN,false));
        if(Math.abs(excluded)>0.0001)mv.addView(financeText("Spese escluse dall’analisi: "+euro.format(excluded)+" €",13,C_RED,false));
        Cursor c=db.movements(broker);int count=0;while(c.moveToNext()&&count<12){long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),t=c.getString(c.getColumnIndexOrThrow("movement_type")),fc=c.getString(c.getColumnIndexOrThrow("flow_class"));double a=c.getDouble(c.getColumnIndexOrThrow("amount"));LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);rr.setGravity(Gravity.CENTER_VERTICAL);rr.addView(movementText(dt,b,t,fc,a),new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setTextSize(18);del.setMinHeight(dp(44));del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo movimento?").setPositiveButton("Elimina",(dd,w)->{db.deleteMovement(id);showHistory();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(46),dp(46)));mv.addView(rr);count++;}c.close();if(count==0)mv.addView(tv("Nessun movimento classificato.",12,true));content.addView(mv);
    }

    void costDialog(String broker){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        Spinner month=spinner(months,Calendar.getInstance().get(Calendar.MONTH));EditText date=textField("Data YYYY-MM-DD",currentDate());Spinner kind=spinner(new String[]{"Commissione","Imposta"},0);Spinner type=spinner(new String[]{"Acquisto","Vendita","Tobin Tax","Plusvalenza","Imposta di bollo","Ritenuta estera","Imposta su interessi","Altre imposte","Altro"},0);EditText amount=field("Importo pagato €",null),instrument=textField("Strumento / riferimento (facoltativo)",""),isin=textField("ISIN / ticker (facoltativo)",""),notes=textField("Note","");
        box.addView(month);box.addView(date);box.addView(kind);box.addView(type);box.addView(amount);box.addView(instrument);box.addView(isin);box.addView(notes);
        new AlertDialog.Builder(this).setTitle("Registra costo o imposta • "+broker).setView(box).setPositiveButton("Salva",(d,w)->{Double a=num(amount);if(a==null||a<0){toast("Importo non valido");return;}String k=kind.getSelectedItemPosition()==0?"COMMISSIONE":"IMPOSTA";db.addCost(date.getText().toString().trim(),month.getSelectedItemPosition()+1,broker,k,type.getSelectedItem().toString(),a,instrument.getText().toString(),isin.getText().toString(),notes.getText().toString());db.captureDailySnapshot(currentDate());toast("Costo registrato");showHistory();}).setNegativeButton("Annulla",null).show();
    }

    void addFinancialHistorySection(){
        String broker=brokerFilter();LinearLayout fin=card();fin.addView(tv("Contabilità: costi, tasse e risultati",17,true));
        double commissions=db.sumCosts(broker,"COMMISSIONE"),otherTaxes=db.sumCosts(broker,"IMPOSTA"),incomeTaxes=broker==null?db.sumIncomeTaxesActive():db.sumIncomeTaxes(broker),plGross=db.sumRealized(broker,"realized_pl_gross"),plNet=db.sumRealized(broker,"realized_pl_net");Double unreal=unrealizedPl(broker);
        fin.addView(financeText("Commissioni 2026: "+euro.format(commissions)+" €",14,commissions>0?C_RED:C_TEXT,false));
        fin.addView(financeText("Tasse trattenute sui proventi: "+euro.format(incomeTaxes)+" €",14,incomeTaxes>0?C_RED:C_TEXT,false));
        fin.addView(financeText("Altre imposte registrate: "+euro.format(otherTaxes)+" €",14,otherTaxes>0?C_RED:C_TEXT,false));
        fin.addView(financeTextSigned("P/L realizzato netto: ",plNet,14));
        if(unreal==null)fin.addView(tv("P/L non realizzato: PMC incompleto",14,true));else fin.addView(financeTextSigned("P/L non realizzato: ",unreal,14));
        fin.addView(financeTextSigned("P/L realizzato lordo: ",plGross,14));
        if(broker!=null){fin.addView(tv("Regime fiscale: "+db.fiscalRegime(broker),12,false));Button add=btn("＋ Registra commissione / imposta");add.setOnClickListener(v->costDialog(broker));fin.addView(add);}
        String[] taxTypes={"Tobin Tax","Plusvalenza","Imposta di bollo","Ritenuta estera","Imposta su interessi","Altre imposte"};StringBuilder tb=new StringBuilder();for(String t:taxTypes){double x=db.sumTaxType(broker,t);if(x!=0){if(tb.length()>0)tb.append(" • ");tb.append(t).append(": ").append(euro.format(x)).append(" €");}}if(tb.length()>0)fin.addView(tv(tb.toString(),12,false));
        Cursor cc=db.costs(broker);int count=0;while(cc.moveToNext()&&count<10){long id=cc.getLong(cc.getColumnIndexOrThrow("id"));String dt=cc.getString(cc.getColumnIndexOrThrow("date")),b=cc.getString(cc.getColumnIndexOrThrow("broker")),k=cc.getString(cc.getColumnIndexOrThrow("cost_kind")),t=cc.getString(cc.getColumnIndexOrThrow("cost_type")),inst=cc.getString(cc.getColumnIndexOrThrow("instrument"));double a=cc.getDouble(cc.getColumnIndexOrThrow("amount"));LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);TextView costLine=financeText(dt+" • "+b+"\n"+k+" • "+t+(inst==null||inst.isEmpty()?"":" • "+inst)+" • "+euro.format(a)+" €",13,C_RED,false);rr.addView(costLine,new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo costo/imposta? I dati di una vendita già registrata non verranno modificati.").setPositiveButton("Elimina",(dd,w)->{db.deleteCost(id);showHistory();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));fin.addView(rr);count++;}cc.close();
        content.addView(fin);

        LinearLayout closed=card();closed.addView(tv("Operazioni chiuse / vendite",17,true));Cursor sc=db.sales(broker);int sn=0;while(sc.moveToNext()&&sn<15){String dt=sc.getString(sc.getColumnIndexOrThrow("date")),b=sc.getString(sc.getColumnIndexOrThrow("broker")),inst=sc.getString(sc.getColumnIndexOrThrow("instrument"));double q=sc.getDouble(sc.getColumnIndexOrThrow("quantity")),price=sc.getDouble(sc.getColumnIndexOrThrow("price")),g=sc.getDouble(sc.getColumnIndexOrThrow("gross_amount")),pn=sc.getDouble(sc.getColumnIndexOrThrow("realized_pl_net")),co=sc.getDouble(sc.getColumnIndexOrThrow("commission")),ta=sc.getDouble(sc.getColumnIndexOrThrow("taxes"));closed.addView(signedText(dt+" • "+b+"\n"+inst+" • "+trim(q)+" × "+trim(price)+" = "+euro.format(g)+" €\nP/L netto "+euro.format(pn)+" € • commissioni "+euro.format(co)+" € • imposte "+euro.format(ta)+" €",pn,12,false));sn++;}sc.close();if(sn==0)closed.addView(tv("Nessuna vendita registrata.",12,false));content.addView(closed);
    }

    void showOperations(){
        if(current.equals("HOME"))setPortfolio(TOTAL);
        heading("Operazioni",current);
        LinearLayout intro=card();intro.addView(sectionTitle("Movimenti e risultati"));
        content.addView(intro);
        addMovementSection();
        addFinancialHistorySection();
        LinearLayout hist=card();hist.addView(sectionTitle("Storico completo"));Button open=ghostBtn("Apri storico annuale");open.setOnClickListener(v->showHistory());hist.addView(open);content.addView(hist);
    }

    void showHistory(){
        heading("Storico",current);
        addMovementSection();
        addFinancialHistorySection();

        LinearLayout annual=card(); annual.addView(tv("Storico risultati annuali",17,true));
        annual.addView(muted("Inserisci i dati di base: tasse, risultato complessivo e rendimento vengono calcolati automaticamente.",12));
        Button addYear=btn("＋ Aggiungi / modifica anno");
        addYear.setOnClickListener(v->annualHistoryDialog(null)); annual.addView(addYear);
        Cursor ah=db.annualHistory();
        while(ah.moveToNext()){
            int yr=ah.getInt(ah.getColumnIndexOrThrow("year"));
            Double gi=getNullable(ah,"gross_income"), ni=getNullable(ah,"net_income"), pp=getNullable(ah,"portfolio_profit"), rr=getNullable(ah,"return_rate");
            Double recovery=getNullable(ah,"fiscal_recovery"),taxes=getNullable(ah,"annual_taxes"),startCap=getNullable(ah,"starting_capital"),overall=getNullable(ah,"overall_result");
            if(recovery==null)recovery=0.0;if(taxes==null)taxes=annualAutoTaxes(pp,recovery);if(overall==null&&pp!=null)overall=pp-taxes+recovery;if(rr==null&&overall!=null&&startCap!=null&&startCap>0)rr=overall/startCap;
            String notes=ah.getString(ah.getColumnIndexOrThrow("notes"));
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(0,dp(7),0,dp(7));
            String text=yr+"";
            if(pp!=null) text+="\nRisultato lordo: "+euro.format(pp)+" €";
            if(recovery!=null&&Math.abs(recovery)>0.0001) text+="\nRecupero fiscale minus: "+euro.format(recovery)+" €";
            if(taxes!=null) text+="\nTasse stimate/residue: "+euro.format(taxes)+" €";
            if(overall!=null) text+="\nRisultato complessivo: "+euro.format(overall)+" €";
            if(pp!=null&&pp<0) text+="\nMinusvalenza generata: "+euro.format(Math.abs(pp))+" €";
            if(startCap!=null&&startCap>0) text+="\nCapitale iniziale: "+euro.format(startCap)+" €";
            if(rr!=null) text+="\nRendimento: "+pct.format(rr); else text+="\nRendimento: base capitale mancante";
            if(gi!=null&&Math.abs(gi)>0.0001) text+="\nProventi lordi: "+euro.format(gi)+" €";
            if(ni!=null&&Math.abs(ni)>0.0001) text+="\nProventi netti stimati: "+euro.format(ni)+" €";
            if(notes!=null&&!notes.trim().isEmpty()) text+="\n"+notes;
            row.addView(historyAnnualFinanceText(text,gi,ni,pp,rr,recovery,taxes,overall));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=btn("Modifica"); edit.setOnClickListener(v->annualHistoryDialog(yr));
            Button del=btn("Elimina"); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Elimina anno "+yr).setMessage("Eliminare definitivamente questo dato storico annuale? Il dato non verrà ricreato automaticamente.").setPositiveButton("Elimina",(d,w)->{db.deleteAnnualHistory(yr);showHistory();}).setNegativeButton("Annulla",null).show());
            actions.addView(edit,new LinearLayout.LayoutParams(0,dp(46),1)); actions.addView(del,new LinearLayout.LayoutParams(0,dp(46),1));
            row.addView(actions); annual.addView(row);
        }
        ah.close(); content.addView(annual);

        String broker=brokerFilter();LinearLayout chart=card();chart.addView(tv("Proventi mensili 2026",17,true));chart.addView(new ChartView(this,monthlyIncome(broker),false,"€",m->showIncomeMonth(m)),new LinearLayout.LayoutParams(-1,dp(180)));content.addView(chart);
        for(int m=1;m<=12;m++){
            double gross=broker==null?db.sumIncomeMonthActive(m,"gross"):db.sumIncomeMonth(broker,m,"gross"),net=broker==null?db.sumIncomeMonthActive(m,"net"):db.sumIncomeMonth(broker,m,"net"),value=portfolioMonth(broker,m),pac=0; if(current.equals(TOTAL)){for(String b:db.portfolioNames(true))pac+=getPacMonth(b,m);}else pac=getPacMonth(current,m);Double r=calcMonthlyReturn(broker,m);boolean incomplete=current.equals(TOTAL)?db.hasIncompleteNetMonthActive(m):db.hasIncompleteNetMonth(current,m);double knownNet=current.equals(TOTAL)?db.sumKnownNetMonthActive(m):db.sumKnownNetMonth(current,m);
            if(gross==0&&value==0&&r==null&&Math.abs(pac)<0.0001&&m>Calendar.getInstance().get(Calendar.MONTH)+1)continue;
            double taxesMonth=current.equals(TOTAL)?db.sumIncomeTaxesMonthActive(m):db.sumIncomeTaxesMonth(current,m);LinearLayout c=card();c.addView(tv(months[m-1],16,true));c.addView(historyMonthFinanceText(value,gross,net,incomplete,knownNet,taxesMonth,pac,r));content.addView(c);
        }
    }
    double portfolioMonth(String broker,int m){if(broker==null){double total=0;for(String b:db.portfolioNames(true))total+=portfolioMonth(b,m);return total;}Cursor c=db.snapshot(broker,m);double x=0;if(c.moveToFirst()){Double f=getNullable(c,"final_value");if(f!=null)x=f;}c.close();return x;}

    void annualHistoryDialog(Integer existingYear){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(8),dp(18),0);
        EditText year=field("Anno",existingYear==null?null:existingYear.doubleValue());
        EditText profit=field("Risultato lordo portafoglio €",null);
        EditText recovery=field("Recupero fiscale minusvalenze €",0.0);
        EditText startCap=field("Capitale iniziale anno € (se non rilevato)",null);
        EditText gross=field("Proventi lordi annuali € (opzionale)",null);
        EditText notes=textField("Note","");
        if(existingYear!=null){
            Cursor c=db.annualHistoryYear(existingYear);
            if(c.moveToFirst()){
                Double x=getNullable(c,"portfolio_profit"); if(x!=null)profit.setText(trim(x));
                x=getNullable(c,"fiscal_recovery"); if(x!=null)recovery.setText(trim(x));
                x=getNullable(c,"starting_capital"); if(x!=null)startCap.setText(trim(x));
                x=getNullable(c,"gross_income"); if(x!=null)gross.setText(trim(x));
                notes.setText(c.getString(c.getColumnIndexOrThrow("notes")));
            }
            c.close();
        }
        box.addView(year);box.addView(profit);box.addView(recovery);box.addView(startCap);box.addView(gross);box.addView(muted("Calcolo automatico: tasse stimate/residue, risultato complessivo e rendimento %. Se il capitale iniziale non è nello storico dell’app, basta inserirlo una sola volta.",11));box.addView(notes);
        new AlertDialog.Builder(this).setTitle(existingYear==null?"Aggiungi anno":"Modifica "+existingYear).setView(box)
                .setPositiveButton("Salva",(d,w)->{
                    Double y=num(year); if(y==null||y<1900||y>2100){toast("Anno non valido");return;}
                    int yy=(int)Math.round(y);Double p=num(profit),rec=num(recovery),cap=num(startCap),gi=num(gross);if(rec==null)rec=0.0;if(rec<0)rec=Math.abs(rec);
                    if(cap==null||cap<=0)cap=inferAnnualStartingCapital(yy);
                    double taxes=annualAutoTaxes(p,rec);Double overall=p==null?null:p-taxes+rec;Double rr=(overall!=null&&cap!=null&&cap>0)?overall/cap:null;
                    Double ni=gi==null?null:gi*(1.0-db.getTaxRate());
                    if(existingYear!=null && existingYear!=yy) db.deleteAnnualHistory(existingYear);
                    db.saveAnnualHistory(yy,gi,ni,p,rr,rec,taxes,cap,overall,notes.getText().toString());
                    String msg="Storico annuale salvato";if(overall!=null)msg+=" • risultato "+euro.format(overall)+" €";if(rr!=null)msg+=" • "+pct.format(rr);toast(msg);showHistory();
                }).setNegativeButton("Annulla",null).show();
    }

    void showGeneralSettings(){
        current="HOME";
        menuGrid.setVisibility(View.GONE);
        heading("Impostazioni generali","Tutti i portafogli");

        LinearLayout backup=card();
        backup.addView(tv("Backup e migrazione",17,true));
        Button exp=btn("Esporta backup completo – tutti i portafogli");
        exp.setOnClickListener(v->exportCsv());
        backup.addView(exp);
        Button imp=btn("Importa / ripristina backup completo");
        imp.setOnClickListener(v->importCsv());
        backup.addView(imp);
        if(hasEmergencyBackup()){
            Button emergency=btn("Ripristina ultimo backup di sicurezza");
            emergency.setOnClickListener(v->restoreEmergencyBackup());
            backup.addView(emergency);
        }
        
        content.addView(backup);

    }

    void showSettings(){
        heading("Impostazioni",current);
        LinearLayout s=card();s.addView(tv("Parametri generali",17,true));
        EditText tax=field("Aliquota fiscale %",db.getTaxRate()*100);s.addView(tax);
        
        Button save=btn("Salva impostazioni");save.setOnClickListener(v->{if(num(tax)!=null)db.setSettingDouble("tax_rate",n(tax)/100);toast("Impostazioni salvate");});s.addView(save);content.addView(s);

        if(!current.equals(TOTAL) && !current.equals("HOME") && db.portfolioExists(current)){
            LinearLayout fees=card();fees.addView(tv("Commissioni e fiscalità del portafoglio",17,true));
            
            String buyType=db.portfolioString(current,"buy_commission_type","FISSA"),sellType=db.portfolioString(current,"sell_commission_type","FISSA");
            Spinner buyTypeSp=spinner(new String[]{"Fissa (€)","Percentuale (%)"},"PERCENTUALE".equalsIgnoreCase(buyType)?1:0);
            Spinner sellTypeSp=spinner(new String[]{"Fissa (€)","Percentuale (%)"},"PERCENTUALE".equalsIgnoreCase(sellType)?1:0);
            EditText buyVal=field("Commissione acquisto predefinita",db.portfolioDouble(current,"buy_commission_value",0));
            EditText sellVal=field("Commissione vendita predefinita",db.portfolioDouble(current,"sell_commission_value",0));
            EditText minFee=field("Commissione minima € (0 = nessun minimo)",db.portfolioDouble(current,"commission_min",0));
            EditText maxFee=field("Commissione massima € (0 = nessun massimo)",db.portfolioDouble(current,"commission_max",0));
            String regime=db.fiscalRegime(current);String[] regimes={"Non specificato","Amministrato","Dichiarativo","Altro"};int regimeIdx=0;for(int i=0;i<regimes.length;i++)if(regimes[i].equalsIgnoreCase(regime))regimeIdx=i;Spinner fiscal=spinner(regimes,regimeIdx);
            fees.addView(tv("Commissione acquisto",12,true));fees.addView(buyTypeSp);fees.addView(buyVal);
            fees.addView(tv("Commissione vendita",12,true));fees.addView(sellTypeSp);fees.addView(sellVal);fees.addView(minFee);fees.addView(maxFee);
            fees.addView(tv("Regime fiscale",12,true));fees.addView(fiscal);
            Button saveFees=btn("Salva commissioni e fiscalità");saveFees.setOnClickListener(v->{
                double bv=num(buyVal)==null?0:n(buyVal),sv=num(sellVal)==null?0:n(sellVal),mn=num(minFee)==null?0:n(minFee),mx=num(maxFee)==null?0:n(maxFee);
                if(bv<0||sv<0||mn<0||mx<0){toast("Commissioni non valide");return;}
                db.saveBrokerFinancialSettings(current,buyTypeSp.getSelectedItemPosition()==1?"PERCENTUALE":"FISSA",bv,sellTypeSp.getSelectedItemPosition()==1?"PERCENTUALE":"FISSA",sv,mn,mx,fiscal.getSelectedItem().toString());toast("Commissioni e fiscalità salvate");showSettings();
            });fees.addView(saveFees);content.addView(fees);
        }

        LinearLayout pm=card();
        if(!current.equals(TOTAL) && !current.equals("HOME") && db.portfolioExists(current)){
            pm.addView(tv("Gestione portafoglio",17,true));
            Cursor one=db.portfolios(); boolean found=false;
            while(one.moveToNext()){
                String name=one.getString(one.getColumnIndexOrThrow("name"));
                if(!name.equals(current)) continue;
                found=true;
                boolean active=one.getInt(one.getColumnIndexOrThrow("active"))==1;
                double pac=one.getDouble(one.getColumnIndexOrThrow("pac_default"));
                String profile=db.getBrokerProfile(name);
                pm.addView(tv(name+(active?"":" (archiviato)")+" • "+profile+" • PAC predefinito "+euro.format(pac)+" €",14,true));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button ren=btn("Rinomina");ren.setOnClickListener(v->renamePortfolioDialog(name));
                Button prof=btn("Broker");prof.setOnClickListener(v->brokerProfileDialog(name));
                Button arc=btn(active?"Archivia":"Riattiva");arc.setOnClickListener(v->{db.setPortfolioActive(name,!active);showSettings();});
                Button del=btn("Elimina");del.setOnClickListener(v->deletePortfolioDialog(name));
                actions.addView(ren,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(prof,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(arc,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));
                pm.addView(actions);
                break;
            }
            one.close();
            if(!found) pm.addView(tv("Portafoglio non disponibile.",13,false));
        }else{
            pm.addView(tv("Gestione portafogli",17,true));
            
            Cursor pc=db.portfolios();
            while(pc.moveToNext()){
                String name=pc.getString(pc.getColumnIndexOrThrow("name"));
                boolean active=pc.getInt(pc.getColumnIndexOrThrow("active"))==1;
                double pac=pc.getDouble(pc.getColumnIndexOrThrow("pac_default"));
                LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(0,dp(8),0,dp(8));
                String profile=db.getBrokerProfile(name);
                row.addView(tv(name+(active?"":" (archiviato)")+" • "+profile+" • PAC predefinito "+euro.format(pac)+" €",14,true));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button ren=btn("Rinomina");ren.setOnClickListener(v->renamePortfolioDialog(name));
                Button prof=btn("Broker");prof.setOnClickListener(v->brokerProfileDialog(name));
                Button arc=btn(active?"Archivia":"Riattiva");arc.setOnClickListener(v->{db.setPortfolioActive(name,!active);showSettings();});
                Button del=btn("Elimina");del.setOnClickListener(v->deletePortfolioDialog(name));
                actions.addView(ren,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(prof,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(arc,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));
                row.addView(actions);pm.addView(row);
            }
            pc.close();
        }
        content.addView(pm);

        LinearLayout help=card();Button rules=ghostBtn("ⓘ Regole e definizioni");rules.setOnClickListener(v->showRulesInfo());help.addView(rules);Button appInfo=ghostBtn("Informazioni app");appInfo.setOnClickListener(v->showAppInfo());help.addView(appInfo);content.addView(help);
    }

    void showRulesInfo(){
        String msg="Valore titoli = valore attuale degli strumenti.\nLiquidità = denaro disponibile.\nPatrimonio = titoli + liquidità.\nQuantità × PMC = capitale di carico.\nVersamenti/prelievi esterni sono solo denaro che entra o esce dal broker.\nDividendi e cedole non sono versamenti esterni.\nArchivia conserva i dati; Elimina li cancella definitivamente.";new AlertDialog.Builder(this).setTitle("Regole e definizioni").setMessage(msg).setPositiveButton("Chiudi",null).show();
    }
    void addPortfolioDialog(){
        final boolean fromHome=current.equals("HOME");
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        EditText name=textField("Nome portafoglio","");
        Spinner profile=spinner(brokerProfiles,0);
        EditText pac=field("PAC mensile predefinito €",0.0);
        box.addView(name);box.addView(tv("Broker / profilo",12,true));box.addView(profile);box.addView(pac);
        new AlertDialog.Builder(this).setTitle("Aggiungi portafoglio").setView(box).setPositiveButton("Aggiungi",(d,w)->{
            String nme=name.getText().toString().trim();double p=num(pac)==null?0:n(pac);String selected=profile.getSelectedItem().toString();
            String prof=selected.equals("Riconoscimento automatico")?DbHelper.inferBrokerProfile(nme):(selected.equals("Altro / Generico")?"Generico":selected);
            if(db.addPortfolio(nme,p,prof)){toast("Portafoglio aggiunto • profilo "+prof);if(fromHome)showHome();else showSettings();}else toast("Nome non valido o già esistente");
        }).setNegativeButton("Annulla",null).show();
    }
    void brokerProfileDialog(String name){
        String currentProfile=db.getBrokerProfile(name);int selected=0;for(int i=1;i<brokerProfiles.length;i++){String p=brokerProfiles[i].equals("Altro / Generico")?"Generico":brokerProfiles[i];if(p.equalsIgnoreCase(currentProfile)){selected=i;break;}}
        final int initial=selected;
        new AlertDialog.Builder(this).setTitle("Profilo broker • "+name).setSingleChoiceItems(brokerProfiles,selected,null).setPositiveButton("Salva",(d,w)->{
            AlertDialog ad=(AlertDialog)d;int pos=ad.getListView().getCheckedItemPosition();if(pos<0)pos=initial;String sel=brokerProfiles[pos];String prof=sel.equals("Riconoscimento automatico")?DbHelper.inferBrokerProfile(name):(sel.equals("Altro / Generico")?"Generico":sel);db.setBrokerProfile(name,prof);toast("Profilo broker: "+prof);showSettings();
        }).setNegativeButton("Annulla",null).show();
    }
    void renamePortfolioDialog(String oldName){
        EditText name=textField("Nuovo nome",oldName);new AlertDialog.Builder(this).setTitle("Rinomina "+oldName).setView(name).setPositiveButton("Rinomina",(d,w)->{String nme=name.getText().toString().trim();if(db.renamePortfolio(oldName,nme)){if(current.equals(oldName))current=nme;toast("Portafoglio rinominato");showSettings();}else toast("Nome non valido o già esistente");}).setNegativeButton("Annulla",null).show();
    }
    void deletePortfolioDialog(String name){
        new AlertDialog.Builder(this).setTitle("Elimina portafoglio").setMessage("Eliminare definitivamente '"+name+"'? Saranno cancellati proventi, rendimenti, snapshot e PAC collegati. Per conservarli usa Archivia.").setPositiveButton("ELIMINA",(d,w)->{db.deletePortfolio(name);if(current.equals(name))current="HOME";toast("Portafoglio eliminato");showSettings();}).setNegativeButton("Annulla",null).show();
    }

    void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"Portafoglio_2026_V3431_DEV_backup.csv");startActivityForResult(i,41);}
    void importCsv(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,42);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        if(requestCode==41){try(OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write(buildCsv().getBytes(StandardCharsets.UTF_8));toast("Backup esportato");}catch(Exception e){toast("Errore export: "+e.getMessage());}}
        else if(requestCode==42){try(InputStream is=getContentResolver().openInputStream(data.getData())){ByteArrayOutputStream bo=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);pendingImport=bo.toString("UTF-8");confirmImport();}catch(Exception e){toast("Errore import: "+e.getMessage());}}
        else if(requestCode==43){readStatementFile(data.getData());}
    }

    void showStatementImportCenter(){
        current=TOTAL;menuGrid.setVisibility(View.VISIBLE);heading("Importazioni estratti conto","Tutti i portafogli");
        LinearLayout intro=card();intro.addView(tv("Aggiornamento mensile • PDF / CSV",17,true));content.addView(intro);
        for(String b:db.portfolioNames(true)){LinearLayout c=card();c.addView(tv(b+" • "+db.getBrokerProfile(b),16,true));Button x=btn("Importa estratto conto • "+b);x.setOnClickListener(v->startStatementImport(b));c.addView(x);content.addView(c);}
        LinearLayout hist=card();hist.addView(tv("Ultimi estratti importati",17,true));Cursor h=db.statementImports(null);int shown=0;while(h.moveToNext()&&shown<8){String b=h.getString(h.getColumnIndexOrThrow("broker")),d=h.getString(h.getColumnIndexOrThrow("statement_date")),n=h.getString(h.getColumnIndexOrThrow("source_name"));Double t=getNullable(h,"total_value");hist.addView(tv((d==null||d.isEmpty()?"Data non indicata":d)+" • "+b+"\n"+(n==null?"":n)+(t==null?"":" • "+euro.format(t)+" €"),13,false));shown++;}h.close();if(shown==0)hist.addView(tv("Nessun estratto importato con la nuova funzione.",13,false));content.addView(hist);
    }

    void startStatementImport(String broker){
        if(broker==null||!db.portfolioExists(broker)){toast("Portafoglio non valido");return;}
        pendingImportPortfolio=broker;pendingDirectaImport=null;pendingStatementHash="";pendingStatementName="";openPortfolioStatement();
    }

    void choosePortfolioForPdfImport(){
        java.util.List<String> ps=db.portfolioNames(true);if(ps.isEmpty()){toast("Crea prima almeno un portafoglio");return;}
        String[] names=ps.toArray(new String[0]);int checked=0;if(!current.equals(TOTAL)&&!current.equals("HOME")){int i=ps.indexOf(current);if(i>=0)checked=i;}final int initial=checked;
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio di destinazione").setSingleChoiceItems(names,checked,null).setPositiveButton("Continua",(d,w)->{AlertDialog ad=(AlertDialog)d;int pos=ad.getListView().getCheckedItemPosition();if(pos<0)pos=initial;startStatementImport(names[pos]);}).setNegativeButton("Annulla",null).show();
    }

    void openPortfolioStatement(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","text/csv","text/comma-separated-values","text/plain"});startActivityForResult(i,43);}
    void openPortfolioPdf(){openPortfolioStatement();}

    String displayName(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}String x=uri.getLastPathSegment();return x==null?"estratto":x;
    }
    String sha256(byte[] data)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] dig=md.digest(data);StringBuilder b=new StringBuilder();for(byte x:dig)b.append(String.format(Locale.US,"%02x",x));return b.toString();}
    byte[] readAll(Uri uri)throws Exception{try(InputStream is=getContentResolver().openInputStream(uri);ByteArrayOutputStream bo=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);return bo.toByteArray();}}

    void readStatementFile(Uri uri){
        final String target=pendingImportPortfolio;if(target==null||target.isEmpty()){toast("Scegli prima il portafoglio");return;}toast("Lettura estratto in corso…");
        new Thread(()->{try{byte[] bytes=readAll(uri);String hash=sha256(bytes),name=displayName(uri);if(db.isStatementImported(target,hash)){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Estratto già importato").setMessage("Questo stesso file è già stato importato in "+target+". Nessun dato è stato modificato.").setPositiveButton("OK",null).show());return;}String mime=getContentResolver().getType(uri);boolean pdf=(mime!=null&&mime.toLowerCase(Locale.US).contains("pdf"))||name.toLowerCase(Locale.US).endsWith(".pdf");DirectaImport out;if(pdf){try(InputStream is=new ByteArrayInputStream(bytes);PDDocument doc=PDDocument.load(is)){String raw=new PDFTextStripper().getText(doc);out=parseStatementPdf(raw,target);}}else out=parseStatementCsv(new String(bytes,StandardCharsets.UTF_8),target);pendingStatementHash=hash;pendingStatementName=name;runOnUiThread(()->previewDirectaImport(out));}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Estratto non importato").setMessage(e.getMessage()+"\n\nNessun dato del portafoglio è stato modificato.").setPositiveButton("OK",null).show());}}).start();
    }

    DirectaImport parseStatementPdf(String raw,String target)throws Exception{
        String up=raw==null?"":raw.toUpperCase(Locale.ITALY);String profile=db.getBrokerProfile(target);
        if(up.contains("SITUAZIONE PATRIMONIALE")){if("Trade Republic".equalsIgnoreCase(profile))throw new Exception("Il PDF sembra Directa ma il portafoglio selezionato è Trade Republic.");return parseDirectaSituation(raw);}
        if(up.contains("TRADE REPUBLIC")||"Trade Republic".equalsIgnoreCase(profile))return parseTradeRepublicStatement(raw);
        try{return parseDirectaSituation(raw);}catch(Exception ignored){}
        throw new Exception("Formato PDF non riconosciuto. Sono supportati la Situazione Patrimoniale Directa e, in modalità beta, gli estratti/portfolio statement Trade Republic con posizioni valorizzate.");
    }

    String normalizeDate(String d){if(d==null)return "";d=d.trim();Matcher y=Pattern.compile("(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2})").matcher(d);if(y.find())return String.format(Locale.US,"%s-%02d-%02d",y.group(1),Integer.parseInt(y.group(2)),Integer.parseInt(y.group(3)));Matcher i=Pattern.compile("(\\d{1,2})[-./](\\d{1,2})[-./](\\d{4})").matcher(d);if(i.find())return String.format(Locale.US,"%s-%02d-%02d",i.group(3),Integer.parseInt(i.group(2)),Integer.parseInt(i.group(1)));return d;}

    DirectaImport parseDirectaSituation(String raw) throws Exception{
        if(raw==null||!raw.toUpperCase(Locale.ITALY).contains("SITUAZIONE PATRIMONIALE"))throw new Exception("non sembra una Situazione Patrimoniale Directa");
        DirectaImport out=new DirectaImport();out.parser="Directa PDF";String t=raw.replace('\u00A0',' ');
        Matcher dm=Pattern.compile("(?i)data\\s*Operazione\\s*(\\d{1,2}/\\d{1,2}/\\d{4})").matcher(t);if(dm.find())out.date=normalizeDate(dm.group(1));
        Matcher cm=Pattern.compile("(?i)TOTALE\\s+LIQUIDITA'\\s*:\\s*([0-9.]+,[0-9]{2})").matcher(t);if(cm.find())out.cash=parseItalian(cm.group(1));
        Pattern row=Pattern.compile("(?m)^\\s*(.+?)\\s+\\(([A-Z]{2}[A-Z0-9]{10})\\)\\s+([0-9.,]+)\\s+([0-9.,]+)\\s+([0-9.]+,[0-9]{2})\\s*$");
        Matcher rm=row.matcher(t);double sum=0;while(rm.find()){String name=rm.group(1).trim(),isin=rm.group(2).trim();Double q=parseItalian(rm.group(3)),pr=parseItalian(rm.group(4)),v=parseItalian(rm.group(5));if(q!=null&&pr!=null&&v!=null){out.positions.add(new DbHelper.Position(isin,name,q,pr,v,out.date));sum+=v;}}
        Matcher tm=Pattern.compile("(?is)TOTALE\\s+TITOLI\\s+EURO.{0,120}?([0-9.]+,[0-9]{2})").matcher(t);if(tm.find())out.printedInvested=parseItalian(tm.group(1));out.invested=out.printedInvested!=null?out.printedInvested:sum;
        if(out.date.isEmpty())throw new Exception("data estratto Directa non trovata");if(out.positions.isEmpty())throw new Exception("nessuna posizione trovata");if(out.cash==null)throw new Exception("liquidità non trovata");if(out.printedInvested!=null&&Math.abs(sum-out.printedInvested)>0.10)throw new Exception("totale titoli non coerente con le posizioni");return out;
    }

    Double parseFlexible(String s){try{if(s==null)return null;String x=s.replace("€","").replace("EUR","").replace(" ","").trim();x=x.replaceAll("[^0-9,.-]","");if(x.isEmpty())return null;int lc=x.lastIndexOf(','),ld=x.lastIndexOf('.');if(lc>=0&&ld>=0){if(lc>ld)x=x.replace(".","").replace(',','.');else x=x.replace(",","");}else if(lc>=0)x=x.replace(',','.');return Double.parseDouble(x);}catch(Exception e){return null;}}

    DirectaImport parseTradeRepublicStatement(String raw)throws Exception{
        if(raw==null||!raw.toUpperCase(Locale.ITALY).contains("TRADE REPUBLIC"))throw new Exception("non sembra un estratto Trade Republic");DirectaImport out=new DirectaImport();out.parser="Trade Republic PDF beta";String t=raw.replace('\u00A0',' ');
        Matcher dates=Pattern.compile("(\\d{1,2}[./]\\d{1,2}[./]\\d{4}|\\d{4}-\\d{1,2}-\\d{1,2})").matcher(t);String last="";while(dates.find())last=dates.group(1);out.date=normalizeDate(last);if(out.date.isEmpty())out.date=currentDate();
        Matcher cash=Pattern.compile("(?i)(?:cash(?:\\s+balance)?|saldo(?:\\s+contante)?|liquidit[aà]|disponibilit[aà])[^0-9-]{0,50}([0-9][0-9.,]*[,.][0-9]{2})").matcher(t);if(cash.find())out.cash=parseFlexible(cash.group(1));
        String[] lines=t.split("\\r?\\n");Pattern ip=Pattern.compile("([A-Z]{2}[A-Z0-9]{10})");double sum=0;
        for(int i=0;i<lines.length;i++){Matcher im=ip.matcher(lines[i]);if(!im.find())continue;String isin=im.group(1),name=lines[i].substring(0,im.start()).trim();if(name.length()<3&&i>0)name=lines[i-1].trim();StringBuilder chunk=new StringBuilder(lines[i].substring(im.end()));for(int j=1;j<=2&&i+j<lines.length;j++)chunk.append(" ").append(lines[i+j]);Matcher nm=Pattern.compile("[-+]?[0-9]+(?:[.,][0-9]+)*(?:[.,][0-9]+)?").matcher(chunk.toString());ArrayList<Double> nums=new ArrayList<>();while(nm.find()){Double v=parseFlexible(nm.group());if(v!=null&&v>=0)nums.add(v);}Double q=null,pr=null,val=null;for(int a=0;a<nums.size()&&val==null;a++)for(int b=a+1;b<nums.size()&&val==null;b++)for(int c=b+1;c<nums.size();c++){double qq=nums.get(a),pp=nums.get(b),vv=nums.get(c);if(qq>0&&pp>0&&vv>0&&Math.abs(qq*pp-vv)/Math.max(1.0,vv)<0.08){q=qq;pr=pp;val=vv;break;}}if(val==null&&nums.size()>=2){double qq=nums.get(0),vv=nums.get(nums.size()-1);if(qq>0&&vv>0){q=qq;val=vv;pr=vv/qq;}}if(q!=null&&pr!=null&&val!=null){if(name.isEmpty())name=isin;out.positions.add(new DbHelper.Position(isin,name,q,pr,val,out.date));sum+=val;}}
        out.invested=sum;Matcher total=Pattern.compile("(?i)(?:portfolio(?:\\s+value)?|valore\\s+portafoglio|totale\\s+titoli|securities)[^0-9-]{0,60}([0-9][0-9.,]*[,.][0-9]{2})").matcher(t);Double grand=total.find()?parseFlexible(total.group(1)):null;if(out.positions.isEmpty())throw new Exception("Trade Republic riconosciuto, ma le posizioni non sono leggibili automaticamente da questo formato PDF. Serve un esempio di questo estratto per adattare il parser senza rischiare valori errati.");if(out.cash==null&&grand!=null&&grand>=sum)out.cash=grand-sum;return out;
    }

    String importedIncomeType(String desc){
        String u=desc==null?"":desc.toUpperCase(Locale.ITALY);
        if(u.contains("CEDOL")||u.contains("COUPON"))return "Cedola";
        if(u.contains("DIVID"))return "Dividendo";
        if(u.contains("DISTRIB"))return "Distribuzione";
        if(u.contains("INTERESS"))return "Interesse";
        return "Altro provento";
    }
    String importedIncomeCategory(String target,String isin,String desc){
        String cat=(isin==null||isin.trim().isEmpty())?"":db.positionCategory(target,isin);
        if(cat!=null&&!cat.trim().isEmpty())return cat;
        String t=importedIncomeType(desc);if("Cedola".equals(t))return "Certificati";if("Dividendo".equals(t))return "Azioni";if("Distribuzione".equals(t))return "ETF";if("Interesse".equals(t))return "Liquidità";return "Altro";
    }

    DirectaImport parseStatementCsv(String raw,String target)throws Exception{
        if(raw==null||raw.trim().isEmpty())throw new Exception("CSV vuoto");
        if(raw.startsWith("PORTAFOGLIO2026_"))throw new Exception("Hai selezionato un backup dell’app, non un estratto conto mensile.");
        String[] lines=raw.replace("\r","").split("\n");if(lines.length<2)throw new Exception("CSV senza righe dati");
        char sep=lines[0].chars().filter(ch->ch==';').count()>=lines[0].chars().filter(ch->ch==',').count()?';':',';
        String[] head=splitCsvSimple(lines[0],sep);Map<String,Integer> idx=new HashMap<>();for(int i=0;i<head.length;i++)idx.put(head[i].trim().toLowerCase(Locale.ITALY).replace("à","a"),i);
        int iIsin=findCol(idx,"isin"),iName=findCol(idx,"strumento","instrument","name","security","product","titolo"),iQty=findCol(idx,"quantita","quantity","shares","pezzi"),iPrice=findCol(idx,"prezzo","price","current price"),iValue=findCol(idx,"valore","value","market value","current value"),iDate=findCol(idx,"data","date");
        boolean positionsCsv=iIsin>=0&&iQty>=0&&(iPrice>=0||iValue>=0);
        if(positionsCsv){
            DirectaImport out=new DirectaImport();out.parser="CSV posizioni";out.positionsAuthoritative=true;double sum=0;
            for(int r=1;r<lines.length;r++){if(lines[r].trim().isEmpty())continue;String[] a=splitCsvSimple(lines[r],sep);String isin=cell(a,iIsin).trim();if(!isin.matches("[A-Z]{2}[A-Z0-9]{10}"))continue;Double q=parseFlexible(cell(a,iQty)),pr=iPrice>=0?parseFlexible(cell(a,iPrice)):null,val=iValue>=0?parseFlexible(cell(a,iValue)):null;if(q==null||q<=0)continue;if(val==null&&pr!=null)val=q*pr;if(pr==null&&val!=null)pr=val/q;if(pr==null||val==null)continue;String name=iName>=0?cell(a,iName):isin;if(iDate>=0&&!cell(a,iDate).trim().isEmpty())out.date=normalizeDate(cell(a,iDate));out.positions.add(new DbHelper.Position(isin,name,q,pr,val,out.date));sum+=val;}
            if(out.positions.isEmpty())throw new Exception("nessuna posizione valida trovata nel CSV");if(out.date.isEmpty())out.date=currentDate();out.invested=sum;return out;
        }
        int iDesc=findCol(idx,"descrizione","description","causale","tipo","type","operazione","movement"),iAmount=findCol(idx,"importo","amount","net amount","accredito","addebito");
        if(iDate<0||iDesc<0||iAmount<0)throw new Exception("CSV non riconosciuto: servono colonne posizioni oppure Data, Descrizione/Tipo e Importo.");
        DirectaImport out=new DirectaImport();out.parser="CSV movimenti";out.positionsAuthoritative=false;String latest="";
        for(int r=1;r<lines.length;r++){
            if(lines[r].trim().isEmpty())continue;String[] a=splitCsvSimple(lines[r],sep);String date=normalizeDate(cell(a,iDate)),desc=cell(a,iDesc);Double amount=parseFlexible(cell(a,iAmount));if(date.isEmpty()||amount==null||Math.abs(amount)<0.000001)continue;
            if(latest.isEmpty()||date.compareTo(latest)>0)latest=date;String isin=iIsin>=0?cell(a,iIsin).trim():"",instrument=iName>=0?cell(a,iName):"";String u=desc.toUpperCase(Locale.ITALY);double abs=Math.abs(amount);
            if(u.contains("DIVID")||u.contains("CEDOL")||u.contains("COUPON")||u.contains("DISTRIB")||u.contains("INTERESS")||u.contains("PROVENT")){
                ImportedIncome x=new ImportedIncome();x.date=date;x.isin=isin;x.instrument=instrument;x.type=importedIncomeType(desc);x.category=importedIncomeCategory(target,isin,desc);x.gross=abs;x.notes="Import estratto • "+desc;out.incomes.add(x);
            }else if(u.contains("COMMISSION")||u.contains("FEE")||u.contains("COSTO")||u.contains("IMPOST")||u.contains("TAX")||u.contains("BOLLO")||u.contains("RITENUT")){
                ImportedCost x=new ImportedCost();x.date=date;x.isin=isin;x.instrument=instrument;x.kind=(u.contains("COMMISSION")||u.contains("FEE")||u.contains("COSTO"))?"COMMISSIONE":"IMPOSTA";x.type=desc.trim().isEmpty()?("COMMISSIONE".equals(x.kind)?"Commissione":"Imposta"):desc.trim();x.amount=abs;x.notes="Import estratto";out.costs.add(x);
            }else if(u.contains("SAVEBACK")||u.contains("PREMIO")||u.contains("ROUND UP")||u.contains("VERSAMENTO")||u.contains("DEPOSITO")||u.contains("PRELIEVO")||u.contains("BONIFICO")){
                ImportedMovement x=new ImportedMovement();x.date=date;x.type=desc.trim().isEmpty()?"Movimento":desc.trim();x.amount=abs;x.flowClass=(u.contains("SAVEBACK")||u.contains("PREMIO"))?"PREMIO":((u.contains("VERSAMENTO")||u.contains("DEPOSITO")||u.contains("PRELIEVO")||u.contains("BONIFICO"))?"ESTERNO":"INTERNO");x.notes="Import estratto";out.movements.add(x);
            }
        }
        out.date=latest.isEmpty()?currentDate():latest;
        if(out.incomes.isEmpty()&&out.costs.isEmpty()&&out.movements.isEmpty())throw new Exception("Nessun movimento riconosciuto nel CSV.");
        return out;
    }

    int findCol(Map<String,Integer> idx,String... names){for(String n:names){for(Map.Entry<String,Integer> e:idx.entrySet())if(e.getKey().equals(n)||e.getKey().contains(n))return e.getValue();}return -1;}
    String[] splitCsvSimple(String line,char sep){return line.split(Pattern.quote(String.valueOf(sep)),-1);}
    String cell(String[] a,int i){return i>=0&&i<a.length?a[i].replace("\"","").trim():"";}
    Double parseItalian(String s){try{if(s==null)return null;String x=s.trim().replace(".","").replace(",",".");return Double.parseDouble(x);}catch(Exception e){return null;}}

    int statementDuplicateIncomeCount(String broker,DirectaImport out){int n=0;for(ImportedIncome x:out.incomes)if(db.hasMatchingIncome(broker,x.date,x.type,x.gross,x.isin,x.instrument))n++;return n;}
    int statementDuplicateCostCount(String broker,DirectaImport out){int n=0;for(ImportedCost x:out.costs)if(db.hasMatchingCost(broker,x.date,x.kind,x.type,x.amount,x.isin,x.instrument))n++;return n;}
    int statementDuplicateMovementCount(String broker,DirectaImport out){int n=0;for(ImportedMovement x:out.movements)if(db.hasMatchingMovement(broker,x.date,x.type,x.flowClass,x.amount))n++;return n;}

    void previewDirectaImport(DirectaImport out){
        if(pendingImportPortfolio==null||pendingImportPortfolio.isEmpty()||!db.portfolioExists(pendingImportPortfolio)){toast("Portafoglio di destinazione non valido");return;}
        pendingDirectaImport=out;StringBuilder msg=new StringBuilder();msg.append("Portafoglio: ").append(pendingImportPortfolio).append("\n");msg.append("Formato: ").append(out.parser).append("\n");msg.append("Data: ").append(out.date.isEmpty()?"non indicata":out.date).append("\n\n");
        if(out.positionsAuthoritative){
            Double oldCash=db.latestCashValue(pendingImportPortfolio);Double effectiveCash=out.cash!=null?out.cash:oldCash;double total=(out.invested==null?0:out.invested)+(effectiveCash==null?0:effectiveCash);
            msg.append("Posizioni: ").append(out.positions.size()).append("\n");msg.append("Valore titoli: ").append(euro.format(out.invested)).append(" €\n");if(out.cash!=null)msg.append("Liquidità: ").append(euro.format(out.cash)).append(" €\n");else msg.append("Liquidità: mantiene il valore registrato").append(oldCash==null?"":" ("+euro.format(oldCash)+" €)").append("\n");msg.append("Patrimonio risultante: ").append(euro.format(total)).append(" €");
        }else{
            int di=statementDuplicateIncomeCount(pendingImportPortfolio,out),dc=statementDuplicateCostCount(pendingImportPortfolio,out),dm=statementDuplicateMovementCount(pendingImportPortfolio,out);
            int totalRows=out.incomes.size()+out.costs.size()+out.movements.size(),duplicates=di+dc+dm;
            msg.append("Proventi trovati: ").append(out.incomes.size()).append("\nCosti/imposte: ").append(out.costs.size()).append("\nMovimenti: ").append(out.movements.size()).append("\n");
            if(duplicates>0)msg.append("\nGià presenti riconosciuti: ").append(duplicates).append("\nNuovi da aggiungere: ").append(totalRows-duplicates);
            else msg.append("\nNessun duplicato rilevato.");
        }
        new AlertDialog.Builder(this).setTitle("Anteprima estratto conto").setMessage(msg.toString()).setPositiveButton("IMPORTA",(d,w)->confirmPortfolioPdfImport()).setNegativeButton("Annulla",null).show();
    }

    void confirmPortfolioPdfImport(){
        if(pendingDirectaImport==null||pendingImportPortfolio==null||pendingImportPortfolio.isEmpty())return;
        String target=pendingImportPortfolio;DirectaImport out=pendingDirectaImport;
        if(db.isStatementImported(target,pendingStatementHash)){toast("Estratto già importato: nessun dato modificato");return;}
        int addedIncome=0,addedCosts=0,addedMov=0,skipped=0;
        if(out.positionsAuthoritative){
            boolean ok=db.applyStatementImport(target,out.positions,out.invested,out.cash,out.date,"Estratto conto • "+out.parser,pendingStatementHash,pendingStatementName);
            if(!ok){toast("Estratto già importato: nessun dato modificato");return;}
        }else{
            for(ImportedIncome x:out.incomes){int m=1;try{m=Integer.parseInt(x.date.substring(5,7));}catch(Exception ignored){}long id=db.addIncomeIfMissing(x.date,m,target,x.category,x.instrument,x.isin,x.type,x.gross,0,x.notes+" • importo da estratto","NETTO");if(id<0)skipped++;else addedIncome++;}
            for(ImportedCost x:out.costs){int m=1;try{m=Integer.parseInt(x.date.substring(5,7));}catch(Exception ignored){}long id=db.addCostIfMissing(x.date,m,target,x.kind,x.type,x.amount,x.instrument,x.isin,x.notes);if(id<0)skipped++;else addedCosts++;}
            for(ImportedMovement x:out.movements){int m=1;try{m=Integer.parseInt(x.date.substring(5,7));}catch(Exception ignored){}long id=db.addMovementIfMissing(x.date,m,target,x.type,x.flowClass,x.amount,x.notes);if(id<0)skipped++;else addedMov++;}
            double total=db.latestPortfolioValue(target);int statementMonth=Calendar.getInstance().get(Calendar.MONTH)+1;try{statementMonth=Integer.parseInt(out.date.substring(5,7));}catch(Exception ignored){}db.saveStatementImport(target,out.date,statementMonth,pendingStatementHash,pendingStatementName,db.latestInvestedValue(target),db.latestCashValue(target),total,0,new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new java.util.Date()));
        }
        db.captureDailySnapshot(currentDate());
        String result=out.positionsAuthoritative?(target+" aggiornato: "+out.positions.size()+" posizioni"):(target+" • nuovi: "+(addedIncome+addedCosts+addedMov)+" • già presenti: "+skipped);
        toast(result);current=target;pendingDirectaImport=null;pendingImportPortfolio="";pendingStatementHash="";pendingStatementName="";showDashboard();
    }

    void choosePortfolioForWealthUpdate(){
        java.util.List<String> ps=db.portfolioNames(true);
        if(ps.isEmpty()){toast("Crea prima almeno un portafoglio");return;}
        String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio").setItems(names,(d,which)->showWealthUpdateOptions(names[which])).show();
    }

    void showWealthUpdateOptions(String broker){
        final String[] opts={"INSERIMENTO MANUALE","IMPORTA DA FILE"};
        new AlertDialog.Builder(this).setTitle("Aggiorna "+broker).setItems(opts,(d,which)->{
            if(which==0)showManualPortfolioEditor(broker);
            else startStatementImport(broker);
        }).setNegativeButton("Annulla",null).show();
    }


    void showManualPortfolioEditor(String broker){
        current=broker;menuGrid.setVisibility(View.VISIBLE);heading("Aggiorna patrimonio",broker);

        LinearLayout summary=card();
        summary.addView(tv("Riepilogo patrimonio",17,true));
        summary.addView(tv("Inserisci Valore titoli e Liquidità. Il Patrimonio totale viene calcolato automaticamente e non può essere modificato manualmente.",13,false));
        Double titlesValue=db.latestInvestedValue(broker),cash=db.latestCashValue(broker);double previousTotal=db.latestPortfolioValue(broker);

        summary.addView(tv("Valore titoli",12,true));
        EditText fTitles=field("es. 103964,50",titlesValue);
        summary.addView(fTitles);

        summary.addView(tv("Liquidità",12,true));
        EditText fCash=field("es. 6040,22",cash);
        summary.addView(fCash);

        final TextView totalDisplay=tv("",16,true);
        totalDisplay.setPadding(dp(4),dp(10),dp(4),dp(10));
        summary.addView(totalDisplay);

        if(previousTotal>0 && (titlesValue==null || cash==null)){
            summary.addView(tv("Patrimonio totale precedente registrato: "+euro.format(previousTotal)+" €. Verrà sostituito dal nuovo totale automatico quando salvi Valore titoli e Liquidità.",12,false));
        }

        summary.addView(tv("Data",12,true));
        EditText fDate=textField("YYYY-MM-DD",currentDate());
        summary.addView(fDate);

        final Runnable refreshTotal=()->{
            Double tVal=num(fTitles),cVal=num(fCash);
            if(tVal!=null && cVal!=null && tVal>=0 && cVal>=0){
                totalDisplay.setText("Patrimonio totale calcolato: "+euro.format(tVal+cVal)+" €");
            }else{
                totalDisplay.setText("Patrimonio totale calcolato: inserisci Valore titoli e Liquidità");
            }
        };
        TextWatcher totalWatcher=new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){}
            @Override public void afterTextChanged(Editable e){refreshTotal.run();}
        };
        fTitles.addTextChangedListener(totalWatcher);
        fCash.addTextChangedListener(totalWatcher);
        refreshTotal.run();

        Button saveSummary=btn("SALVA RIEPILOGO");
        saveSummary.setOnClickListener(v->{
            if(invalidNumber(fTitles)||invalidNumber(fCash)){toast("Formato importo non valido. Esempi accettati: 6040,22 oppure 6.040,22");return;}
            Double tVal=num(fTitles),cVal=num(fCash);
            if(tVal==null||cVal==null){toast("Inserisci sia Valore titoli sia Liquidità. Il Patrimonio totale viene calcolato automaticamente.");return;}
            if(tVal<0||cVal<0){toast("Gli importi non possono essere negativi");return;}
            double tot=tVal+cVal;
            String date=fDate.getText().toString().trim();if(date.isEmpty())date=currentDate();
            db.savePortfolioStatus(broker,tVal,cVal,tot,date,"Inserimento manuale");db.captureDailySnapshot(currentDate());
            toast("Patrimonio aggiornato: "+euro.format(tot)+" €");showManualPortfolioEditor(broker);
        });
        summary.addView(saveSummary);content.addView(summary);

        int pcnt=db.positionCount(broker);double posValue=db.sumPositionsCurrentValue(broker);Double cost=db.sumPositionsCostBasis(broker);
        LinearLayout intro=card();intro.addView(tv("Posizioni dettagliate",17,true));
        String posInfo=pcnt+" strumenti";
        if(pcnt>0)posInfo+=" • Valore attuale "+euro.format(posValue)+" €";
        if(cost!=null){double pl=posValue-cost;double plPct=Math.abs(cost)<0.000001?0:pl/cost;posInfo+="\nCapitale di carico "+euro.format(cost)+" € • Guadagno/Perdita "+euro.format(pl)+" € ("+pct.format(plPct)+")";}
        else if(pcnt>0)posInfo+="\nCompleta il PMC delle posizioni per calcolare Guadagno/Perdita.";
        intro.addView(tv(posInfo,13,false));
        intro.addView(tv("Per ogni strumento inserisci Nome, ISIN, ticker facoltativo, categoria, Quantità, PMC (prezzo medio di carico) e Prezzo attuale.",12,false));
        Button add=btn("＋ INSERISCI TITOLO");add.setOnClickListener(v->positionEditDialog(broker,null,null,null,null,null,null,null));intro.addView(add);content.addView(intro);

        Cursor c=db.positions(broker);int n=0;
        while(c.moveToNext()){
            n++;String name=c.getString(c.getColumnIndexOrThrow("instrument"));String isin=c.getString(c.getColumnIndexOrThrow("isin"));int ti=c.getColumnIndex("ticker");String ticker=ti>=0&&!c.isNull(ti)?c.getString(ti):"";if(ticker.isEmpty())ticker=knownTicker(name,isin);double q=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),val=c.getDouble(c.getColumnIndexOrThrow("current_value"));int pi=c.getColumnIndex("pmc");Double pmc=pi>=0&&!c.isNull(pi)?c.getDouble(pi):null;int bfi=c.getColumnIndex("buy_fee");double buyFee=bfi>=0&&!c.isNull(bfi)?c.getDouble(bfi):0;
            double costRow=pmc==null?0:q*pmc,pl=pmc==null?0:val-costRow,plPct=pmc==null||Math.abs(costRow)<0.000001?0:pl/costRow;
            LinearLayout row=card();
            String line=name+"\n"+isin+(ticker.isEmpty()?"":" • Ticker "+ticker)+" • "+positionCategory(broker,name,isin)+"\nQuantità: "+trim(q)+" • PMC: "+(pmc==null?"non inserito":trim(pmc))+" • Prezzo attuale: "+trim(pr)+"\nValore attuale: "+euro.format(val)+" € • Commissione acquisto residua: "+euro.format(buyFee)+" €";
            if(pmc!=null)line+=" • Guadagno/Perdita: "+euro.format(pl)+" € ("+pct.format(plPct)+")";
            row.addView(tv(line,13,true));
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
            final Double fPmc=pmc;final double fQ=q,fPr=pr,fBuyFee=buyFee;final String fName=name,fIsin=isin;
            Button edit=btn("Modifica");edit.setOnClickListener(v->positionEditDialog(broker,fIsin,fName,fQ,fPmc,fPr,fIsin,fBuyFee));
            Button sell=btn("Vendi");sell.setOnClickListener(v->positionSaleDialog(broker,fIsin,fName,fQ,fPmc,fPr,fBuyFee));
            Button del=btn("Elimina");del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Elimina posizione").setMessage("Eliminare "+fName+" senza registrare una vendita? Usa Vendi se vuoi contabilizzare guadagno/perdita.").setPositiveButton("Elimina",(d,w)->{db.deletePosition(broker,fIsin);db.syncInvestedFromPositions(broker,currentDate());toast("Posizione eliminata");showManualPortfolioEditor(broker);}).setNegativeButton("Annulla",null).show());
            actions.addView(edit,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(sell,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));row.addView(actions);content.addView(row);
        }
        c.close();
        if(n==0){LinearLayout empty=card();empty.addView(tv("Nessuna posizione inserita. Puoi comunque usare il riepilogo patrimoniale sopra.",13,false));content.addView(empty);}
        Button back=btn("Torna alla Dashboard");back.setOnClickListener(v->showDashboard());content.addView(back);
    }

    void manualWealthDialog(String broker){
        showManualPortfolioEditor(broker);
    }

    void showPositionsDialog(String broker){
        showManualPortfolioEditor(broker);
    }

    void positionEditDialog(String broker,String isin,String instrument,Double quantity,Double pmc,Double price,String originalIsin,Double existingBuyFee){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        box.addView(tv("Il PMC è il prezzo medio di carico. La commissione di acquisto viene conservata separatamente e sarà attribuita proporzionalmente in caso di vendita parziale.",12,false));
        String existingTicker=originalIsin==null?"":db.positionTicker(broker,originalIsin);if(existingTicker.isEmpty()&&originalIsin!=null)existingTicker=knownTicker(instrument,isin);
        String existingCategory=originalIsin==null?"":db.positionCategory(broker,originalIsin);
        if(existingCategory.isEmpty()&&originalIsin!=null)existingCategory=inferPositionCategory(instrument,isin);
        EditText fName=textField("Nome strumento",instrument==null?"":instrument),fIsin=textField("ISIN / codice principale",isin==null?"":isin),fTicker=textField("Ticker (facoltativo)",existingTicker),fQ=field("Quantità",quantity),fPmc=field("PMC - prezzo medio di carico",pmc),fPrice=field("Prezzo attuale",price),fBuyFee=field("Commissione acquisto € (vuoto = predefinita)",existingBuyFee);
        String[] catChoices={"Riconoscimento automatico","Azioni","ETF","ETP","Certificati","Altro"};int catIdx=0;for(int i=1;i<catChoices.length;i++)if(catChoices[i].equalsIgnoreCase(existingCategory)){catIdx=i;break;}Spinner fCategory=spinner(catChoices,catIdx);
        addLabeledField(box,"Nome strumento",fName);
        addLabeledField(box,"ISIN / codice principale",fIsin);
        addLabeledField(box,"Ticker (facoltativo, es. PST)",fTicker);
        box.addView(tv("Categoria",11,true));box.addView(fCategory);
        box.addView(tv("Altro è riservato agli strumenti non contemplati nelle categorie principali, ad esempio BTP, BOT e obbligazioni.",11,false));
        addLabeledField(box,"Quantità",fQ);
        addLabeledField(box,"PMC - prezzo medio di carico",fPmc);
        addLabeledField(box,"Prezzo attuale (€ per quota)",fPrice);
        addLabeledField(box,"Commissione acquisto (€)",fBuyFee);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog ad=new AlertDialog.Builder(this).setTitle(originalIsin==null?"Inserisci titolo":"Modifica titolo").setView(scroll).setPositiveButton("Salva",null).setNegativeButton("Annulla",null).create();
        ad.setOnShowListener(dd->{
            ad.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                if(invalidNumber(fQ)||invalidNumber(fPrice)||invalidNumber(fPmc)||invalidNumber(fBuyFee)){toast("Formato numerico non valido. Usa ad esempio 10,5 oppure 10.5");return;}
                String code=fIsin.getText().toString().trim().toUpperCase(Locale.ITALY),ticker=fTicker.getText().toString().trim().toUpperCase(Locale.ITALY),name=fName.getText().toString().trim();Double q=num(fQ),p=num(fPrice),m=num(fPmc),fee=num(fBuyFee);
                if(code.isEmpty()||name.isEmpty()){toast("Inserisci almeno nome e ISIN/codice principale");return;}
                if(q==null||q<=0||p==null||p<0){toast("Quantità e Prezzo attuale non validi");return;}
                if(m!=null&&m<0){toast("PMC non valido");return;}
                String selectedCategory=catChoices[fCategory.getSelectedItemPosition()];String finalCategory=selectedCategory.equals("Riconoscimento automatico")?inferPositionCategory(name,code):selectedCategory;
                if(selectedCategory.equals("Riconoscimento automatico")&&finalCategory.equals("Altro")&&!looksLikeOtherInstrument(name)){toast("Categoria non riconosciuta automaticamente: scegli Azioni, ETF, ETP, Certificati oppure Altro.");return;}
                double gross=q*(m!=null?m:p);double buyFee=fee==null?db.defaultCommission(broker,false,gross):fee;if(buyFee<0){toast("Commissione non valida");return;}
                if(originalIsin!=null&&!originalIsin.equals(code))db.deletePosition(broker,originalIsin);
                db.savePosition(broker,new DbHelper.Position(code,name,q,m,p,q*p,currentDate(),buyFee,ticker,finalCategory));
                if(originalIsin==null && buyFee>0){int month=Calendar.getInstance().get(Calendar.MONTH)+1;db.addCost(currentDate(),month,broker,"COMMISSIONE","Acquisto",buyFee,name,code,"Commissione registrata all'aggiunta titolo");}
                db.syncInvestedFromPositions(broker,currentDate());toast("Titolo salvato in "+finalCategory);ad.dismiss();showManualPortfolioEditor(broker);
            });
        });
        ad.show();
    }

    void choosePortfolioForPositionEntry(){
        java.util.List<String> ps=db.portfolioNames(true);if(ps.isEmpty()){toast("Aggiungi prima un portafoglio");return;}String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Inserisci titolo • scegli portafoglio").setItems(names,(d,which)->{String b=names[which];current=b;positionEditDialog(b,null,null,null,null,null,null,null);}).setNegativeButton("Annulla",null).show();
    }

    void positionSaleDialog(String broker,String isin,String instrument,double quantity,Double pmc,double currentPrice,double buyFee){
        if(pmc==null){toast("Inserisci prima il PMC della posizione");return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);
        box.addView(tv(instrument+"\nDisponibili: "+trim(quantity)+" • PMC "+trim(pmc)+" • Commissione acquisto residua "+euro.format(buyFee)+" €",12,true));
        box.addView(tv("Compila solo commissioni e imposte effettivamente applicate. Lascia 0 se non presenti.",11,false));
        EditText fDate=textField("Data vendita YYYY-MM-DD",currentDate()),fQty=field("Quantità venduta",quantity),fPrice=field("Prezzo di vendita",currentPrice),fComm=field("Commissione vendita €",db.defaultCommission(broker,true,quantity*currentPrice)),fTax=field("Imposta plusvalenza €",0.0),fTobin=field("Tobin Tax €",0.0),fOther=field("Altre imposte €",0.0);EditText fNotes=textField("Note","");
        addLabeledField(box,"Data vendita (AAAA-MM-GG)",fDate);
        addLabeledField(box,"Quantità venduta",fQty);
        addLabeledField(box,"Prezzo di vendita (€ per quota)",fPrice);
        addLabeledField(box,"Commissione di vendita (€)",fComm);
        addLabeledField(box,"Imposta su plusvalenza (€)",fTax);
        addLabeledField(box,"Tobin Tax (€)",fTobin);
        addLabeledField(box,"Altre imposte / costi fiscali (€)",fOther);
        addLabeledField(box,"Note",fNotes);
        TextView preview=tv("",13,true);box.addView(preview);
        Button calc=btn("Calcola risultato");calc.setOnClickListener(v->{Double q=num(fQty),p=num(fPrice),co=num(fComm),ta=num(fTax),to=num(fTobin),ot=num(fOther);if(q==null||p==null){preview.setText("Inserisci quantità e prezzo");return;}double gross=q*p,cost=q*pmc,ratio=Math.min(1,q/quantity),buyAlloc=buyFee*ratio,taxes=(ta==null?0:ta)+(to==null?0:to)+(ot==null?0:ot),netPl=gross-cost-buyAlloc-(co==null?0:co)-taxes;preview.setText("Controvalore: "+euro.format(gross)+" €\nP/L lordo: "+euro.format(gross-cost)+" €\nP/L netto: "+euro.format(netPl)+" €");});box.addView(calc);
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog ad=new AlertDialog.Builder(this).setTitle("Vendi posizione").setView(scroll).setPositiveButton("REGISTRA VENDITA",null).setNegativeButton("Annulla",null).create();
        ad.setOnShowListener(dd->ad.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            Double q=num(fQty),p=num(fPrice),co=num(fComm),ta=num(fTax),to=num(fTobin),ot=num(fOther);if(q==null||q<=0||q-quantity>0.0000001||p==null||p<0){toast("Quantità o prezzo non validi");return;}
            try{DbHelper.SaleResult r=db.sellPosition(broker,isin,q,p,co==null?0:co,ta==null?0:ta,to==null?0:to,ot==null?0:ot,fDate.getText().toString().trim(),fNotes.getText().toString());toast("Vendita registrata • P/L netto "+euro.format(r.plNet)+" €");ad.dismiss();showManualPortfolioEditor(broker);}catch(Exception ex){toast(ex.getMessage());}
        }));
        ad.show();
    }

    boolean backupLooksValid(String text){
        if(text==null||text.trim().length()<12)return false;
        String clean=text.replace("\r","").trim();
        if(clean.startsWith("SEZIONE;"))return clean.contains("MESE;");
        if(!clean.startsWith("PORTAFOGLIO2026_"))return false;
        return clean.contains("\nPORTFOLIO;")||clean.contains("\nINCOME;")||clean.contains("\nSNAPSHOT;")||clean.contains("\nPAC;")||clean.contains("\nPOSITION;")||clean.contains("\nSTATUS;")||clean.contains("\nMOVEMENT;")||clean.contains("\nCOST;")||clean.contains("\nTRADE;")||clean.contains("\nSTATEMENT;")||clean.contains("\nANNUAL;");
    }

    String backupSummary(String text){
        String[] lines=text==null?new String[0]:text.replace("\r","").split("\n");
        LinkedHashSet<String> portfolios=new LinkedHashSet<>();
        int incomes=0,positions=0,pacs=0,snapshots=0,dailySnapshots=0,movements=0,costs=0,trades=0,statements=0;
        for(String line:lines){
            if(line==null||line.trim().isEmpty())continue;
            String[] a=line.split(";",-1);
            if(a.length==0)continue;
            if(a[0].equals("PORTFOLIO")&&a.length>=2)portfolios.add(a[1]);
            else if(a[0].equals("INCOME")){incomes++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("POSITION")){positions++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("PAC")){pacs++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("SNAPSHOT")){snapshots++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("DAILY_SNAPSHOT")){dailySnapshots++;if(a.length>=2)portfolios.add(a[1]);}
            else if(a[0].equals("MOVEMENT")){movements++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("COST")){costs++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("TRADE")){trades++;if(a.length>=4)portfolios.add(a[3]);}
            else if(a[0].equals("STATEMENT")){statements++;if(a.length>=2)portfolios.add(a[1]);}
        }
        String names=portfolios.isEmpty()?"non rilevati":android.text.TextUtils.join(", ",portfolios);
        return "Portafogli: "+names+"\nPosizioni: "+positions+" • Proventi: "+incomes+" • PAC: "+pacs+" • Snapshot mensili: "+snapshots+" • Giornalieri: "+dailySnapshots+"\nMovimenti: "+movements+" • Costi/imposte: "+costs+" • Operazioni chiuse: "+trades+" • Estratti registrati: "+statements;
    }

    void confirmImport(){
        if(!backupLooksValid(pendingImport)){
            new AlertDialog.Builder(this).setTitle("Backup non valido").setMessage("Il file selezionato è vuoto o non contiene una struttura di backup riconoscibile. Nessun dato è stato modificato.").setPositiveButton("OK",null).show();
            return;
        }
        String summary=backupSummary(pendingImport);
        new AlertDialog.Builder(this).setTitle("Verifica backup").setMessage(summary+"\n\nSostituisci ripristina l'intera app. Prima della sostituzione verrà creato automaticamente un backup di sicurezza interno. Se l'importazione fallisce, tutte le modifiche vengono annullate e i dati attuali restano invariati.").setPositiveButton("Sostituisci",(d,w)->importBackupSafely(true)).setNeutralButton("Aggiungi",(d,w)->importBackupSafely(false)).setNegativeButton("Annulla",null).show();
    }

    boolean hasEmergencyBackup(){return new File(getFilesDir(),"backup_pre_import.csv").exists();}

    void saveEmergencyBackup(){
        try(FileOutputStream fos=openFileOutput("backup_pre_import.csv",MODE_PRIVATE)){
            fos.write(buildCsv().getBytes(StandardCharsets.UTF_8));
        }catch(Exception ignored){}
    }

    void restoreEmergencyBackup(){
        File f=new File(getFilesDir(),"backup_pre_import.csv");
        if(!f.exists()){toast("Nessun backup di sicurezza disponibile");return;}
        try(FileInputStream is=new FileInputStream(f)){
            ByteArrayOutputStream bo=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);
            pendingImport=bo.toString("UTF-8");
            if(!backupLooksValid(pendingImport)){toast("Backup di sicurezza non valido");return;}
            new AlertDialog.Builder(this).setTitle("Backup di sicurezza").setMessage(backupSummary(pendingImport)+"\n\nVuoi ripristinare questo backup interno?").setPositiveButton("Ripristina",(d,w)->importBackupSafely(false,true)).setNegativeButton("Annulla",null).show();
        }catch(Exception e){toast("Errore lettura backup di sicurezza: "+e.getMessage());}
    }

    void importBackupSafely(boolean replace){importBackupSafely(replace,false);}

    void importBackupSafely(boolean replace,boolean emergencySource){
        if(!backupLooksValid(pendingImport)){toast("Backup non valido: nessun dato modificato");return;}
        if(replace&&!emergencySource)saveEmergencyBackup();
        android.database.sqlite.SQLiteDatabase sql=db.getWritableDatabase();
        String error=null;
        sql.beginTransaction();
        try{
            if(replace||emergencySource)db.clearTablesOnly();
            parseImportOrThrow(pendingImport);
            sql.setTransactionSuccessful();
        }catch(Exception e){error=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
        finally{sql.endTransaction();}
        if(error!=null){
            new AlertDialog.Builder(this).setTitle("Ripristino annullato").setMessage("Il backup contiene un errore e non è stato applicato. I dati presenti prima dell'operazione sono rimasti invariati.\n\nDettaglio: "+error).setPositiveButton("OK",null).show();
        }else{
            db.normalizeKnownNetIncomeModes();
            db.normalizeKnownHistoricalIncomeTypes();
            toast((replace||emergencySource)?"Backup ripristinato correttamente":"Backup aggiunto correttamente");
            showHome();
        }
    }

    String esc(String s){return s==null?"":s.replace(";",",").replace("\n"," ");}
    String val(Double d){return d==null?"":String.valueOf(d);}
    String buildCsv(){
        StringBuilder s=new StringBuilder();s.append("PORTAFOGLIO2026_V3438;12\n");s.append("SETTING;tax_rate;").append(db.getTaxRate()).append("\n");
        Cursor ports=db.portfolios();while(ports.moveToNext()){
            s.append("PORTFOLIO;").append(esc(ports.getString(ports.getColumnIndexOrThrow("name")))).append(";").append(ports.getInt(ports.getColumnIndexOrThrow("active"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("pac_default"))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("broker_profile")))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("buy_commission_type")))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("buy_commission_value"))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("sell_commission_type")))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("sell_commission_value"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("commission_min"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("commission_max"))).append(";").append(esc(ports.getString(ports.getColumnIndexOrThrow("fiscal_regime")))).append("\n");
        }ports.close();
        Cursor c=db.incomes(null);while(c.moveToNext()){int mi=c.getColumnIndex("amount_mode");String mode=mi>=0&&!c.isNull(mi)?c.getString(mi):"LORDO";s.append("INCOME;").append(esc(c.getString(c.getColumnIndexOrThrow("date")))).append(";").append(c.getInt(c.getColumnIndexOrThrow("month"))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("broker")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("category")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("instrument")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("isin")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("income_type")))).append(";").append(c.getDouble(c.getColumnIndexOrThrow("gross"))).append(";").append(c.getDouble(c.getColumnIndexOrThrow("tax_rate"))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("notes")))).append(";").append(esc(mode)).append("\n");}c.close();
        for(String b:db.portfolioNames(false)){Cursor r=db.snapshots(b);while(r.moveToNext())s.append("SNAPSHOT;").append(esc(b)).append(";").append(r.getInt(r.getColumnIndexOrThrow("month"))).append(";").append(val(getNullable(r,"initial_value"))).append(";").append(val(getNullable(r,"final_value"))).append(";").append(val(getNullable(r,"deposits"))).append(";").append(val(getNullable(r,"withdrawals"))).append(";").append(esc(r.getString(r.getColumnIndexOrThrow("notes")))).append(";").append(val(getNullable(r,"initial_invested"))).append(";").append(val(getNullable(r,"initial_cash"))).append(";").append(val(getNullable(r,"final_invested"))).append(";").append(val(getNullable(r,"final_cash"))).append("\n");r.close();Cursor pr=db.pacs(b);while(pr.moveToNext())s.append("PAC;").append(esc(b)).append(";").append(pr.getInt(pr.getColumnIndexOrThrow("month"))).append(";").append(val(getNullable(pr,"planned"))).append(";").append(val(getNullable(pr,"external_actual"))).append(";").append(val(getNullable(pr,"internal_actual"))).append(";").append(esc(pr.getString(pr.getColumnIndexOrThrow("notes")))).append("\n");pr.close();}
        Cursor pos=db.allPositions();while(pos.moveToNext()){int bi=pos.getColumnIndex("buy_fee"),ti=pos.getColumnIndex("ticker"),ci=pos.getColumnIndex("category");double buyFee=bi>=0&&!pos.isNull(bi)?pos.getDouble(bi):0;String ticker=ti>=0&&!pos.isNull(ti)?pos.getString(ti):"",cat=ci>=0&&!pos.isNull(ci)?pos.getString(ci):"";s.append("POSITION;").append(esc(pos.getString(pos.getColumnIndexOrThrow("broker")))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("isin")))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("instrument")))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("quantity"))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("price"))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("current_value"))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("source_date")))).append(";").append(val(getNullable(pos,"pmc"))).append(";").append(buyFee).append(";").append(esc(ticker)).append(";").append(esc(cat)).append("\n");}pos.close();
        Cursor st=db.portfolioStatuses();while(st.moveToNext())s.append("STATUS;").append(esc(st.getString(st.getColumnIndexOrThrow("broker")))).append(";").append(val(getNullable(st,"invested"))).append(";").append(val(getNullable(st,"cash"))).append(";").append(esc(st.getString(st.getColumnIndexOrThrow("source_date")))).append(";").append(esc(st.getString(st.getColumnIndexOrThrow("source")))).append(";").append(val(getNullable(st,"total_value"))).append("\n");st.close();
        Cursor mv=db.allMovements();while(mv.moveToNext())s.append("MOVEMENT;").append(esc(mv.getString(mv.getColumnIndexOrThrow("date")))).append(";").append(mv.getInt(mv.getColumnIndexOrThrow("month"))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("broker")))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("movement_type")))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("flow_class")))).append(";").append(mv.getDouble(mv.getColumnIndexOrThrow("amount"))).append(";").append(esc(mv.getString(mv.getColumnIndexOrThrow("notes")))).append("\n");mv.close();
        Cursor costs=db.allCosts();while(costs.moveToNext())s.append("COST;").append(esc(costs.getString(costs.getColumnIndexOrThrow("date")))).append(";").append(costs.getInt(costs.getColumnIndexOrThrow("month"))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("broker")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("cost_kind")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("cost_type")))).append(";").append(costs.getDouble(costs.getColumnIndexOrThrow("amount"))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("instrument")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("isin")))).append(";").append(esc(costs.getString(costs.getColumnIndexOrThrow("notes")))).append("\n");costs.close();
        Cursor tr=db.allTrades();while(tr.moveToNext())s.append("TRADE;").append(esc(tr.getString(tr.getColumnIndexOrThrow("date")))).append(";").append(tr.getInt(tr.getColumnIndexOrThrow("month"))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("broker")))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("trade_type")))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("isin")))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("instrument")))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("quantity"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("price"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("gross_amount"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("cost_basis"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("buy_fee_allocated"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("commission"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("taxes"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("net_amount"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("realized_pl_gross"))).append(";").append(tr.getDouble(tr.getColumnIndexOrThrow("realized_pl_net"))).append(";").append(esc(tr.getString(tr.getColumnIndexOrThrow("notes")))).append("\n");tr.close();
        Cursor si=db.allStatementImports();while(si.moveToNext())s.append("STATEMENT;").append(esc(si.getString(si.getColumnIndexOrThrow("broker")))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("statement_date")))).append(";").append(si.getInt(si.getColumnIndexOrThrow("month"))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("file_hash")))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("source_name")))).append(";").append(val(getNullable(si,"invested"))).append(";").append(val(getNullable(si,"cash"))).append(";").append(val(getNullable(si,"total_value"))).append(";").append(si.getInt(si.getColumnIndexOrThrow("positions_count"))).append(";").append(esc(si.getString(si.getColumnIndexOrThrow("imported_at")))).append("\n");si.close();
        Cursor ds=db.allDailySnapshots();while(ds.moveToNext())s.append("DAILY_SNAPSHOT;").append(esc(ds.getString(ds.getColumnIndexOrThrow("broker")))).append(";").append(esc(ds.getString(ds.getColumnIndexOrThrow("date")))).append(";").append(val(getNullable(ds,"total_value"))).append(";").append(val(getNullable(ds,"invested"))).append(";").append(val(getNullable(ds,"cash"))).append(";").append(val(getNullable(ds,"gross_income"))).append(";").append(val(getNullable(ds,"realized_pl_gross"))).append(";").append(val(getNullable(ds,"unrealized_pl"))).append("\n");ds.close();
        Cursor ah=db.annualHistory();while(ah.moveToNext())s.append("ANNUAL;").append(ah.getInt(ah.getColumnIndexOrThrow("year"))).append(";").append(val(getNullable(ah,"gross_income"))).append(";").append(val(getNullable(ah,"net_income"))).append(";").append(val(getNullable(ah,"portfolio_profit"))).append(";").append(val(getNullable(ah,"return_rate"))).append(";").append(val(getNullable(ah,"fiscal_recovery"))).append(";").append(val(getNullable(ah,"annual_taxes"))).append(";").append(val(getNullable(ah,"starting_capital"))).append(";").append(val(getNullable(ah,"overall_result"))).append(";").append(esc(ah.getString(ah.getColumnIndexOrThrow("notes")))).append("\n");ah.close();
        return s.toString();
    }

    Double parseD(String s){try{return s==null||s.trim().isEmpty()?null:Double.parseDouble(s.replace(",","."));}catch(Exception e){return null;}}
    void parseImportOrThrow(String text) throws Exception{
        String[] lines=text.replace("\r","").split("\n");
        if(lines.length==0||!backupLooksValid(text))throw new Exception("file vuoto o formato non riconosciuto");
        boolean v2=lines[0].startsWith("SEZIONE;");
        if(v2){importV2(lines);return;}
        int imported=0;
        for(int lineNo=0;lineNo<lines.length;lineNo++){
            String line=lines[lineNo];if(line.trim().isEmpty())continue;
            String[] a=line.split(";",-1);
            try{
                if(a[0].startsWith("PORTAFOGLIO2026_")){continue;}
                if(a[0].equals("SETTING")&&a.length>=3){if(a[1].equals("tax_rate")){Double x=parseD(a[2]);if(x!=null)db.setSettingDouble(a[1],x);}else if(a[1].equals("creator_name")){/* firma incorporata */}imported++;}
                else if(a[0].equals("ANNUAL")&&a.length>=7){Double yr=parseD(a[1]);if(yr!=null){if(a.length>=11)db.saveAnnualHistory((int)Math.round(yr),parseD(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),parseD(a[6]),parseD(a[7]),parseD(a[8]),parseD(a[9]),a[10]);else db.saveAnnualHistory((int)Math.round(yr),parseD(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),a[6]);imported++;}}
                else if(a[0].equals("PORTFOLIO")&&a.length>=4){Double pac=parseD(a[3]);String prof=a.length>=5&&!a[4].trim().isEmpty()?a[4]:DbHelper.inferBrokerProfile(a[1]);if(!db.portfolioExists(a[1]))db.addPortfolio(a[1],pac==null?0:pac,prof);else{db.setPortfolioPacDefault(a[1],pac==null?0:pac);db.setBrokerProfile(a[1],prof);}db.setPortfolioActive(a[1],!a[2].equals("0"));if(a.length>=12){String bt=a[5].isEmpty()?"FISSA":a[5],st=a[7].isEmpty()?"FISSA":a[7],fr=a[11].isEmpty()?"Non specificato":a[11];db.saveBrokerFinancialSettings(a[1],bt,parseD(a[6])==null?0:parseD(a[6]),st,parseD(a[8])==null?0:parseD(a[8]),parseD(a[9])==null?0:parseD(a[9]),parseD(a[10])==null?0:parseD(a[10]),fr);}imported++;}
                else if(a[0].equals("MOVEMENT")&&a.length>=8){Double amt=parseD(a[6]);if(amt==null)throw new Exception("importo movimento non valido");db.ensurePortfolio(a[3]);db.addMovement(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],amt,a[7]);imported++;}
                else if(a[0].equals("COST")&&a.length>=10){Double amt=parseD(a[6]);if(amt==null)throw new Exception("importo costo non valido");db.ensurePortfolio(a[3]);db.addCost(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],amt,a[7],a[8],a[9]);imported++;}
                else if(a[0].equals("TRADE")&&a.length>=18){Double q=parseD(a[7]),pr=parseD(a[8]),gross=parseD(a[9]),basis=parseD(a[10]),bfa=parseD(a[11]),co=parseD(a[12]),tax=parseD(a[13]),net=parseD(a[14]),plg=parseD(a[15]),pln=parseD(a[16]);if(q==null||pr==null||gross==null||basis==null||bfa==null||co==null||tax==null||net==null||plg==null||pln==null)throw new Exception("dati operazione non validi");db.ensurePortfolio(a[3]);db.addTradeRecord(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],a[6],q,pr,gross,basis,bfa,co,tax,net,plg,pln,a[17]);imported++;}
                else if(a[0].equals("INCOME")&&a.length>=11){Double g=parseD(a[8]),tr=parseD(a[9]);if(g==null)throw new Exception("importo provento non valido");db.ensurePortfolio(a[3]);String mode=a.length>=12&&!a[11].trim().isEmpty()?a[11]:"LORDO";db.addIncome(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],a[6],a[7],g,tr==null?db.getTaxRate():tr,a[10],mode);imported++;}
                else if(a[0].equals("SNAPSHOT")&&a.length>=8){db.ensurePortfolio(a[1]);if(a.length>=12&&(parseD(a[8])!=null||parseD(a[9])!=null||parseD(a[10])!=null||parseD(a[11])!=null))db.saveSnapshotSplit(a[1],Integer.parseInt(a[2]),parseD(a[8]),parseD(a[9]),parseD(a[10]),parseD(a[11]),parseD(a[5]),parseD(a[6]),a[7]);else db.saveSnapshot(a[1],Integer.parseInt(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),parseD(a[6]),a[7]);imported++;}
                else if(a[0].equals("POSITION")&&a.length>=8){Double q=parseD(a[4]),pr=parseD(a[5]),v=parseD(a[6]),pmc=a.length>=9?parseD(a[8]):null,bf=a.length>=10?parseD(a[9]):0;String ticker=a.length>=11?a[10]:"",cat=a.length>=12?a[11]:"";if(q==null||pr==null||v==null)throw new Exception("dati posizione non validi");db.ensurePortfolio(a[1]);db.savePosition(a[1],new DbHelper.Position(a[2],a[3],q,pmc,pr,v,a[7],bf==null?0:bf,ticker,cat));imported++;}
                else if(a[0].equals("STATUS")&&a.length>=6){db.ensurePortfolio(a[1]);Double total=a.length>=7?parseD(a[6]):null;if(total!=null)db.savePortfolioStatus(a[1],parseD(a[2]),parseD(a[3]),total,a[4],a[5]);else db.savePortfolioStatus(a[1],parseD(a[2]),parseD(a[3]),a[4],a[5]);imported++;}
                else if(a[0].equals("STATEMENT")&&a.length>=11){db.ensurePortfolio(a[1]);Double inv=parseD(a[6]),cash=parseD(a[7]),tot=parseD(a[8]),cnt=parseD(a[9]);db.saveStatementImport(a[1],a[2],Integer.parseInt(a[3]),a[4],a[5],inv,cash,tot,cnt==null?0:(int)Math.round(cnt),a[10]);imported++;}
                else if(a[0].equals("DAILY_SNAPSHOT")&&a.length>=9){db.saveDailySnapshot(a[1],a[2],parseD(a[3]),parseD(a[4]),parseD(a[5]),parseD(a[6]),parseD(a[7]),parseD(a[8]));imported++;}
                else if(a[0].equals("PAC")&&a.length>=7){db.ensurePortfolio(a[1]);db.savePac(a[1],Integer.parseInt(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),a[6]);imported++;}
                else if(a[0].startsWith("PORTAFOGLIO2026_")){/* intestazione */}
                else if(!a[0].trim().isEmpty())throw new Exception("tipo record non riconosciuto: "+a[0]);
            }catch(Exception row){throw new Exception("riga "+(lineNo+1)+": "+row.getMessage());}
        }
        if(imported==0)throw new Exception("nessun dato importabile trovato");
    }

    int monthIndex(String name){for(int i=0;i<months.length;i++)if(months[i].equalsIgnoreCase(name))return i+1;return 0;}
    void importV2(String[] lines){
        for(int i=1;i<lines.length;i++){String[] a=lines[i].split(";",-1);if(a.length<13||!a[0].equals("MESE"))continue;int m=monthIndex(a[1]);if(m==0)continue;String date="2026-"+String.format(Locale.US,"%02d",m)+"-28";String[] cats={"Azioni","ETF","ETP","Certificati"};for(int j=0;j<4;j++){Double g=parseD(a[2+j]);if(g!=null&&g!=0){String type=(j==0||j==1)?"Dividendo":(j==2?"Distribuzione":"Cedola");db.addIncome(date,m,DbHelper.DIRECTA,cats[j],"Import V2","",type,g,db.getTaxRate(),"STORICO AGGREGATO DIRECTA - Importato da V2; data tecnica, non data effettiva di accredito");}}db.saveSnapshot(DbHelper.DIRECTA,m,parseD(a[7]),parseD(a[8]),parseD(a[9]),parseD(a[10]),a[12]);}
        for(int m=1;m<=12;m++)db.savePac(DbHelper.DIRECTA,m,db.getPacDefault(DbHelper.DIRECTA),null,null,"Import V2");
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    interface MonthClickListener { void onMonthClick(int month); }

    public class DonutChartView extends View {
        LinkedHashMap<String,Double> parts; double total; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); RectF oval=new RectF();
        DonutPartClickListener partClick; Runnable centerClick; float cx,cy,radius,stroke;
        public DonutChartView(Context c,LinkedHashMap<String,Double> data,double totalValue,DonutPartClickListener listener,Runnable center){
            super(c);parts=data;total=Math.max(0,totalValue);partClick=listener;centerClick=center;setClickable(true);setPadding(dp(6),dp(6),dp(6),dp(6));
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);int w=getWidth(),h=getHeight();cx=w/2f;cy=h-dp(18);radius=Math.min(w*0.37f,h*0.68f);stroke=Math.max(dp(26),radius*0.24f);oval.set(cx-radius,cy-radius,cx+radius,cy+radius);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(stroke);p.setStrokeCap(Paint.Cap.BUTT);float start=180f;
            for(Map.Entry<String,Double> e:parts.entrySet()){double value=Math.max(0,e.getValue());if(total<=0||value<=0)continue;float sweep=(float)(value/total*180f);p.setColor(colorForPart(e.getKey()));c.drawArc(oval,start,sweep,false,p);start+=sweep;}
            if(total<=0){p.setColor(Color.rgb(81,105,119));c.drawArc(oval,180,180,false,p);}p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(18));c.drawText(total<=0?"0 €":euro.format(total)+" €",cx,cy-radius*0.18f,p);p.setTextSize(dp(14));p.setColor(C_DARK_MUTED);c.drawText("Patrimonio totale",cx,cy+dp(8),p);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float dx=e.getX()-cx,dy=e.getY()-cy,dist=(float)Math.sqrt(dx*dx+dy*dy);
            float inner=radius-stroke/2f,outer=radius+stroke/2f;
            if(dist<inner){performClick();if(centerClick!=null)centerClick.run();return true;}
            if(dist>outer || total<=0 || dy>0)return true;
            double deg=Math.toDegrees(Math.atan2(dy,dx));if(deg<0)deg+=360;if(deg<180)deg+=360;double pos=deg-180;if(pos>180)return true;double acc=0;
            for(Map.Entry<String,Double> en:parts.entrySet()){
                double value=Math.max(0,en.getValue());if(value<=0)continue;double sweep=value/total*180.0;
                if(pos>=acc && pos<acc+sweep){performClick();if(partClick!=null)partClick.onPartClick(en.getKey());return true;}acc+=sweep;
            }
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}
    }

    public class PortfolioHistoryChartView extends View {
        final String[] dates;final double[] wealth,perf;final double undatedPerformance;final int undatedYear;Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);String range="YTD";int mode=0,start=0,end=0,selected=-1;TextView summaryView,breakdownView;
        final int GOLD=Color.rgb(216,155,43),BLUE=Color.rgb(47,128,237),PURPLE=Color.rgb(142,91,217),CYAN=Color.rgb(0,166,214);
        public PortfolioHistoryChartView(Context c,HistorySeries hs){
            super(c);int n=hs.dates.size();dates=new String[n];wealth=new double[n];perf=new double[n];
            for(int i=0;i<n;i++){dates[i]=hs.dates.get(i);wealth[i]=hs.wealth.get(i);perf[i]=hs.performance.get(i);}
            undatedPerformance=hs.undatedPerformance;undatedYear=hs.undatedYear;
            setPadding(dp(8),dp(8),dp(8),dp(8));setClickable(true);recalcRange();
        }
        void setSummaryView(TextView v){summaryView=v;updateSummary();}
        void setBreakdownView(TextView v){breakdownView=v;updateBreakdown();}
        void setMode(int m){mode=Math.max(0,Math.min(2,m));selected=-1;updateSummary();updateBreakdown();invalidate();}
        void setRange(String r){range=r;selected=-1;recalcRange();updateSummary();updateBreakdown();invalidate();}
        long dateMs(String d){try{return new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d).getTime();}catch(Exception e){return 0;}}
        void recalcRange(){
            end=Math.max(0,dates.length-1);start=0;if(dates.length==0)return;
            long last=dateMs(dates[end]),days=0;if("1M".equals(range))days=31;else if("6M".equals(range))days=183;else if("1A".equals(range))days=366;
            if(days>0&&last>0){long min=last-days*86400000L;for(int i=0;i<dates.length;i++)if(dateMs(dates[i])>=min){start=i;break;}}
            else if("YTD".equals(range)){String y=dates[end].length()>=4?dates[end].substring(0,4):String.valueOf(Calendar.getInstance().get(Calendar.YEAR));for(int i=0;i<dates.length;i++)if(dates[i].startsWith(y)){start=i;break;}}
        }
        double basePerformance(){return start>0?perf[start-1]:0;}
        double performanceDelta(int i){if(dates.length==0)return 0;return perf[i]-basePerformance();}
        int firstWealthIndex(){for(int i=start;i<=end;i++)if(!Double.isNaN(wealth[i])&&wealth[i]>0)return i;return -1;}
        int lastWealthIndex(){for(int i=end;i>=start;i--)if(!Double.isNaN(wealth[i])&&wealth[i]>0)return i;return -1;}
        double performanceBaseWealth(){
            for(int i=start;i>=0;i--)if(!Double.isNaN(wealth[i])&&wealth[i]>0)return wealth[i];
            for(int i=start;i<=end;i++)if(!Double.isNaN(wealth[i])&&wealth[i]>0)return wealth[i];
            for(int i=end;i<wealth.length;i++)if(!Double.isNaN(wealth[i])&&wealth[i]>0)return wealth[i];
            return 0;
        }
        double valueAt(int i){
            if(mode==0)return wealth[i];
            double d=performanceDelta(i);if(mode==1)return d;
            double base=performanceBaseWealth();return Math.abs(base)<0.000001?0:d/base*100.0;
        }
        void updateSummary(){
            if(summaryView==null)return;if(dates.length==0||start>end){summaryView.setText("Storico non disponibile");return;}
            String text;double semantic=0;
            if(mode==0){
                int fi=firstWealthIndex(),li=lastWealthIndex();if(fi<0||li<0){summaryView.setText("Patrimonio storico non disponibile");return;}
                double first=wealth[fi],last=wealth[li],chg=Math.abs(first)<0.000001?0:last/first-1.0;semantic=chg;text="Inizio "+euro.format(first)+" €   •   Attuale "+euro.format(last)+" €   •   "+(chg>=0?"+":"")+pct.format(chg);
            }
            else if(mode==1){double d=performanceDelta(end);semantic=d;text="Risultato periodo  "+(d>=0?"+":"")+euro.format(d)+" €";}
            else{double d=valueAt(end);semantic=d;text="Risultato periodo  "+String.format(Locale.ITALY,"%+.2f%%",d);}
            SpannableString sp=new SpannableString(text);String tail=mode==0?text.substring(text.lastIndexOf("•")+1).trim():text.substring(text.indexOf("periodo")+8).trim();int pos=text.lastIndexOf(tail);if(pos>=0)sp.setSpan(new ForegroundColorSpan(semantic>0?C_GREEN:(semantic<0?C_RED:C_TEXT)),pos,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);summaryView.setText(sp);summaryView.setTextColor(C_TEXT);summaryView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        }
        void updateBreakdown(){
            if(breakdownView==null)return;if(mode==0||Math.abs(undatedPerformance)<0.0001){breakdownView.setVisibility(View.GONE);return;}breakdownView.setVisibility(View.VISIBLE);double dated=performanceDelta(end),overall=dated;boolean includeUndated=("YTD".equals(range)||"MAX".equals(range))&&dates.length>0&&dates[end].startsWith(String.valueOf(undatedYear));if(includeUndated)overall+=undatedPerformance;String text="Curva datata  "+(dated>=0?"+":"")+euro.format(dated)+" €\nStorico aggregato non datato  "+euro.format(undatedPerformance)+" €\nPerformance YTD complessiva  "+(overall>=0?"+":"")+euro.format(overall)+" €";SpannableString sp=new SpannableString(text);int p=text.lastIndexOf((overall>=0?"+":"")+euro.format(overall)+" €");if(p>=0)sp.setSpan(new ForegroundColorSpan(overall>=0?C_GREEN:C_RED),p,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);breakdownView.setText(sp);
        }
        String shortDate(String d){try{java.util.Date x=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d);return new java.text.SimpleDateFormat("dd MMM",Locale.ITALY).format(x);}catch(Exception e){return d;}}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);int w=getWidth(),h=getHeight();float left=dp(18),right=w-dp(50),top=dp(20),bottom=h-dp(38);
            if(dates.length==0||start>end){p.setColor(C_TEXT);p.setTextSize(dp(12));p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Nessun dato storico",left,top+dp(30),p);return;}
            ArrayList<Integer> ids=new ArrayList<>();for(int i=start;i<=end;i++)if(mode!=0||wealth[i]>0)ids.add(i);if(ids.isEmpty())return;
            double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;for(int i:ids){double v=valueAt(i);if(Double.isNaN(v)||Double.isInfinite(v))continue;min=Math.min(min,v);max=Math.max(max,v);}
            if(mode==0){double pad=(max-min)*0.16;if(pad<1)pad=Math.max(1,max*0.025);min=Math.max(0,min-pad);max+=pad;}else{min=Math.min(min,0);max=Math.max(max,0);double pad=Math.max(mode==2?0.5:1,(max-min)*0.14);min-=pad;max+=pad;}if(max-min<0.0001)max=min+1;
            p.setStrokeWidth(dp(1));p.setColor(Color.rgb(40,86,128));for(int g=0;g<4;g++){float y=top+(bottom-top)*g/3f;c.drawLine(left,y,right,y,p);}
            if(mode!=0&&min<0&&max>0){float zy=(float)(bottom-(0-min)/(max-min)*(bottom-top));p.setColor(Color.rgb(89,126,162));p.setStrokeWidth(dp(1.2f));c.drawLine(left,zy,right,zy,p);}
            int count=Math.max(1,ids.size()-1);float[] xs=new float[ids.size()],ys=new float[ids.size()];long t0=dateMs(dates[ids.get(0)]),t1=dateMs(dates[ids.get(ids.size()-1)]);boolean timed=t0>0&&t1>t0;
            for(int k=0;k<ids.size();k++){int i=ids.get(k);double v=valueAt(i);long tx=dateMs(dates[i]);xs[k]=timed?left+(right-left)*(tx-t0)/(float)(t1-t0):left+(right-left)*k/(float)count;ys[k]=(float)(bottom-(v-min)/(max-min)*(bottom-top));}
            Path linePath=new Path(),fillPath=new Path();linePath.moveTo(xs[0],ys[0]);fillPath.moveTo(xs[0],bottom);fillPath.lineTo(xs[0],ys[0]);
            for(int k=1;k<xs.length;k++){float mx=(xs[k-1]+xs[k])/2f;linePath.cubicTo(mx,ys[k-1],mx,ys[k],xs[k],ys[k]);fillPath.cubicTo(mx,ys[k-1],mx,ys[k],xs[k],ys[k]);}
            fillPath.lineTo(xs[xs.length-1],bottom);fillPath.close();
            int[] areaColors={Color.argb(46,216,155,43),Color.argb(52,47,128,237),Color.argb(46,142,91,217),Color.argb(42,0,166,214)};p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(left,0,right,0,areaColors,null,Shader.TileMode.CLAMP));c.drawPath(fillPath,p);p.setShader(null);
            int[] lineColors={GOLD,BLUE,PURPLE,CYAN};p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setShader(new LinearGradient(left,0,right,0,lineColors,null,Shader.TileMode.CLAMP));c.drawPath(linePath,p);p.setShader(null);p.setStyle(Paint.Style.FILL);
            if(selected>=start&&selected<=end){int k=ids.indexOf(selected);if(k>=0){p.setColor(Color.WHITE);c.drawCircle(xs[k],ys[k],dp(5),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(C_NAVY);c.drawCircle(xs[k],ys[k],dp(5),p);p.setStyle(Paint.Style.FILL);}}
            p.setColor(C_TEXT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(9));int ticks=Math.min(4,Math.max(1,ids.size()-1));for(int t=0;t<=ticks;t++){int k=Math.min(ids.size()-1,Math.round((ids.size()-1)*t/(float)ticks));float x=xs[k];String lab=shortDate(dates[ids.get(k)]);c.drawText(lab,Math.max(left,Math.min(x-dp(12),right-dp(35))),bottom+dp(20),p);}
            p.setTextAlign(Paint.Align.RIGHT);String unit=mode==2?"%":"€";for(int g=0;g<4;g++){double vv=max-(max-min)*g/3.0;float y=top+(bottom-top)*g/3f;p.setColor(C_TEXT);c.drawText(formatAxis(vv,mode==2)+unit,right+dp(44),y+dp(4),p);}p.setTextAlign(Paint.Align.LEFT);
            if(selected>=start&&selected<=end){int k=ids.indexOf(selected);if(k>=0){double vv=valueAt(selected);String val=mode==2?String.format(Locale.ITALY,"%+.2f%%",vv):(mode==1?(vv>=0?"+":"")+euro.format(vv)+" €":euro.format(vv)+" €");String label=shortDate(dates[selected])+"  "+val;p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(11));float tw=p.measureText(label),bx=Math.max(left,Math.min(xs[k]-tw/2,right-tw-dp(14))),by=top+dp(4);p.setColor(Color.argb(238,15,47,85));RectF rr=new RectF(bx-dp(8),by-dp(4),bx+tw+dp(8),by+dp(20));c.drawRoundRect(rr,dp(8),dp(8),p);p.setColor(Color.WHITE);c.drawText(label,bx,by+dp(12),p);}}
        }
        String formatAxis(double v,boolean pctMode){if(pctMode)return String.format(Locale.ITALY,"%.1f",v);if(Math.abs(v)>=1000)return String.format(Locale.ITALY,"%.1fk",v/1000.0);return String.format(Locale.ITALY,"%.0f",v);}
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_UP&&dates.length>0){float left=dp(18),right=getWidth()-dp(50);if(e.getX()>=left&&e.getX()<=right){int idx=start;float best=Float.MAX_VALUE;long t0=dateMs(dates[start]),t1=dateMs(dates[end]);for(int i=start;i<=end;i++){float x;if(t0>0&&t1>t0){long ti=dateMs(dates[i]);x=left+(right-left)*(ti-t0)/(float)(t1-t0);}else{x=left+(right-left)*(i-start)/(float)Math.max(1,end-start);}float d=Math.abs(e.getX()-x);if(d<best){best=d;idx=i;}}selected=idx;performClick();invalidate();return true;}}return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}
    }

    public class ChartView extends View {
        double[] data; boolean line; boolean incomeBars; String unit; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); MonthClickListener monthClick;
        public ChartView(Context c,double[] d,boolean l,String u){this(c,d,l,u,null);}
        public ChartView(Context c,double[] d,boolean l,String u,MonthClickListener listener){super(c);data=d;line=l;unit=u;monthClick=listener;incomeBars=listener!=null&&!l&&"€".equals(u);p.setTypeface(android.graphics.Typeface.DEFAULT);setPadding(dp(8),dp(10),dp(8),dp(8));setClickable(listener!=null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();double max=0,min=0;for(double v:data)if(!Double.isNaN(v)){max=Math.max(max,v);min=Math.min(min,v);}double range=max-min;if(range<0.0001)range=1;float left=dp(34),right=w-dp(10),top=dp(18),bottom=h-dp(34),step=(right-left)/12f;
            p.setStrokeWidth(dp(1));p.setColor(Color.rgb(35,78,119));for(int g=0;g<4;g++){float yy=top+(bottom-top)*g/3f;c.drawLine(left,yy,right,yy,p);}p.setColor(Color.rgb(62,103,143));c.drawLine(left,bottom,right,bottom,p);
            if(line){p.setColor(C_BLUE);p.setStrokeWidth(dp(2.5f));Path path=new Path();boolean started=false;for(int i=0;i<12;i++){double v=data[i];if(Double.isNaN(v)||v==0&&max>0&&i>0)continue;float x=left+step*(i+0.5f),y=(float)(bottom-(v-min)/range*(bottom-top));if(!started){path.moveTo(x,y);started=true;}else path.lineTo(x,y);c.drawCircle(x,y,dp(2.5f),p);}c.drawPath(path,p);}else{for(int i=0;i<12;i++){double v=data[i];if(Double.isNaN(v))continue;float x=left+step*i+dp(3),bw=step-dp(6);double zeroPos=(0-min)/range;float y0=(float)(bottom-zeroPos*(bottom-top));float y=(float)(bottom-(v-min)/range*(bottom-top));p.setColor(v>=0?(incomeBars?C_GREEN:C_BLUE):C_RED);c.drawRoundRect(x,Math.min(y,y0),x+bw,Math.max(y,y0),dp(4),dp(4),p);}}
            p.setColor(C_MUTED);p.setTextSize(dp(9));for(int i=0;i<12;i+=2)c.drawText(months[i].substring(0,3),left+step*i,bottom+dp(19),p);p.setTextSize(dp(9));c.drawText(unit+" max "+shortNum(max),dp(4),dp(11),p);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(monthClick==null)return super.onTouchEvent(e);
            if(e.getAction()==android.view.MotionEvent.ACTION_UP){float left=dp(32),right=getWidth()-dp(10),step=(right-left)/12f;int idx=(int)((e.getX()-left)/step);if(e.getX()>=left&&e.getX()<=right&&idx>=0&&idx<12){performClick();monthClick.onMonthClick(idx+1);return true;}}
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}

        String shortNum(double x){if(Double.isNaN(x))return "-";if(Math.abs(x)>=1000)return String.format(Locale.ITALY,"%.1fk",x/1000.0);return String.format(Locale.ITALY,"%.1f",x);}
    }
}
