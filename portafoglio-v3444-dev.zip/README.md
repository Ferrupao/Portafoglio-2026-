# Portafoglio 2026 — V3.4.44 DEV

## Storico annuale — correzioni V3.4.44
- Ripristinata la riga **Capitale iniziale**.
- `Titoli a fine anno` rinominato **Capitale investito a fine anno** per distinguerlo dal patrimonio complessivo.
- **Patrimonio finale** = capitale investito + liquidità quando il dettaglio è disponibile.
- Per gli anni storici senza separazione attendibile investito/liquidità, le due righe vengono omesse invece di mostrare trattini fuorvianti.
- Restano visibili gli importi di dividendi/cedole, perdita-minus, risultato dopo minus e recupero fiscale.
- Nessuna percentuale sulle singole componenti economiche; rimangono solo le percentuali utili di composizione e rendimento annuale.
- I flussi esterni restano nascosti nello Storico e sono usati solo internamente per neutralizzare versamenti/prelievi nel calcolo del rendimento.

Versione: `3.4.44-dev`  
versionCode: `86`  
DB_VERSION: `16`  
Package: `it.portafoglio2026.v32`
