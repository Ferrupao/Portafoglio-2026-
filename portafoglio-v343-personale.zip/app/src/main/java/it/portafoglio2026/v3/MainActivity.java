package it.portafoglio2026.v3;

import android.app.*;
import android.os.Bundle;
import android.os.Build;
import android.graphics.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.InputType;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    DbHelper db;
    LinearLayout content, menuGrid;
    TextView title, subtitle;
    String current = "HOME";
    final String TOTAL = "Totale";
    final String[] months={"Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"};
    final String[] categories={"Azioni","ETF","ETP","Certificati","Altro"};
    final String[] incomeTypes={"Dividendo","Cedola","Premio","Distribuzione ETF","Distribuzione ETP","Altro"};
    final DecimalFormat euro = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.ITALY));
    final DecimalFormat pct = new DecimalFormat("0.00%", DecimalFormatSymbols.getInstance(Locale.ITALY));
    String pendingImport="";
    DirectaImport pendingDirectaImport;
    String pendingImportPortfolio="";

    static class DirectaImport {
        String date=""; Double cash=null, invested=null, printedInvested=null;
        List<DbHelper.Position> positions=new ArrayList<>();
    }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        PDFBoxResourceLoader.init(getApplicationContext());
        db=new DbHelper(this);
        buildShell();
        showHome();
    }

    TextView tv(String text,int size,boolean bold){
        TextView v=new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(Color.rgb(31,41,55));
        if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        v.setPadding(dp(4),dp(6),dp(4),dp(6)); return v;
    }

    Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); b.setGravity(Gravity.CENTER); b.setMinHeight(dp(52)); return b;
    }

    void buildShell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        getWindow().setStatusBarColor(Color.rgb(16,42,67)); getWindow().setNavigationBarColor(Color.rgb(245,247,250));
        if(Build.VERSION.SDK_INT>=30){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets s=insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0,s.top,0,s.bottom); return insets;
            });
        }else root.setFitsSystemWindows(true);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(8),0,dp(8),0); top.setBackgroundColor(Color.rgb(16,42,67));
        Button home=btn("⌂"); home.setTextSize(22); home.setOnClickListener(v->showHome());
        top.addView(home,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setPadding(dp(8),0,0,0);
        title=tv("Portafoglio 2026 V3.4.3",20,true); title.setTextColor(Color.WHITE); title.setPadding(0,0,0,0);
        subtitle=tv("",12,false); subtitle.setTextColor(Color.rgb(215,230,244)); subtitle.setPadding(0,0,0,0);
        titles.addView(title); titles.addView(subtitle); top.addView(titles,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(58)));

        menuGrid=new LinearLayout(this); menuGrid.setOrientation(LinearLayout.VERTICAL); menuGrid.setPadding(dp(8),dp(7),dp(8),dp(7)); menuGrid.setBackgroundColor(Color.WHITE); menuGrid.setVisibility(View.GONE);
        String[][] rows={{"Dashboard","Cedole","Rendimento"},{"PAC","Storico","Impostazioni"}};
        for(String[] rowNames:rows){
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for(String name:rowNames){
                Button b=btn(name); b.setTextSize(13); b.setSingleLine(true);
                b.setOnClickListener(v->navigate(name));
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),1); p.setMargins(dp(3),dp(2),dp(3),dp(2)); row.addView(b,p);
            }
            menuGrid.addView(row,new LinearLayout.LayoutParams(-1,dp(54)));
        }
        root.addView(menuGrid,new LinearLayout.LayoutParams(-1,dp(122)));

        ScrollView sc=new ScrollView(this); sc.setFillViewport(true);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(12),dp(12),dp(26)); sc.addView(content);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); root.requestApplyInsets();
    }

    void navigate(String name){
        if(name.equals("Dashboard")) showDashboard(); else if(name.equals("Cedole")) showIncome(); else if(name.equals("Rendimento")) showReturns();
        else if(name.equals("PAC")) showPac(); else if(name.equals("Storico")) showHistory(); else showSettings();
    }

    void heading(String main,String sub){ title.setText(main); subtitle.setText(sub); content.removeAllViews(); }
    void setPortfolio(String p){current=p; menuGrid.setVisibility(View.VISIBLE); subtitle.setText(p);}
    String brokerFilter(){return current.equals(TOTAL)?null:current;}

    LinearLayout card(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(12),dp(14),dp(12)); l.setBackgroundResource(R.drawable.card);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); l.setLayoutParams(p); return l;
    }
    TextView kpi(String label,String value){TextView v=tv(label+"\n"+value,18,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(12),dp(8),dp(12));v.setBackgroundResource(R.drawable.card);return v;}

    void showHome(){
        current="HOME"; menuGrid.setVisibility(View.GONE); java.util.List<String> ps=db.portfolioNames(true);
        heading("Portafoglio 2026 V3.4.3",ps.size()+" portafogli attivi • Totale");
        double gross=db.sumIncomeActive("gross"), totalValue=db.latestPortfolioValueAllActive();
        int separatedCount=db.separatedPortfolioCountActive(), unseparatedCount=db.unseparatedPortfolioCountActive();
        Double invested=db.knownInvestedValueAllActive(), cash=db.knownCashValueAllActive();
        String invLabel=unseparatedCount>0?"Capitale investito noto":"Capitale investito";
        String cashLabel=unseparatedCount>0?"Liquidità nota":"Liquidità";
        String invValue=totalValue==0?"da inserire":(separatedCount==0?"da separare":euro.format(invested==null?0:invested)+" €");
        String cashValue=totalValue==0?"da inserire":(separatedCount==0?"da separare":euro.format(cash==null?0:cash)+" €");
        LinearLayout row1=new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(kpi(invLabel,invValue),new LinearLayout.LayoutParams(0,-2,1));
        row1.addView(kpi(cashLabel,cashValue),new LinearLayout.LayoutParams(0,-2,1)); content.addView(row1);
        LinearLayout row2=new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(kpi("Patrimonio totale",totalValue==0?"da inserire":euro.format(totalValue)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        row2.addView(kpi("Proventi YTD",euro.format(gross)+" €"),new LinearLayout.LayoutParams(0,-2,1)); content.addView(row2);
        if(unseparatedCount>0){
            java.util.List<String> pending=new ArrayList<>(); for(String b:ps)if(!db.isPortfolioFullySeparated(b))pending.add(b);
            LinearLayout pendingCard=card(); pendingCard.addView(tv("Patrimonio da separare",16,true));
            pendingCard.addView(tv(euro.format(db.unseparatedPortfolioValueAllActive())+" € • "+unseparatedCount+" portafogli da completare: "+android.text.TextUtils.join(", ",pending),13,false)); content.addView(pendingCard);
        }
        Double ytd=calcYtdReturn(null); content.addView(kpi("Rendimento YTD",ytd==null?"da compilare":pct.format(ytd)));


        LinearLayout annualHome=card(); annualHome.addView(tv("Storico risultati anni precedenti",17,true));
        Cursor ah=db.annualHistory(); int shown=0;
        while(ah.moveToNext() && shown<3){
            int yr=ah.getInt(ah.getColumnIndexOrThrow("year"));
            Double gi=getNullable(ah,"gross_income"), pp=getNullable(ah,"portfolio_profit"), rr=getNullable(ah,"return_rate");
            String line=String.valueOf(yr);
            if(gi!=null) line+=" • proventi "+euro.format(gi)+" €";
            if(pp!=null) line+=" • guadagno/perdita "+euro.format(pp)+" €";
            if(rr!=null) line+=" • "+pct.format(rr);
            annualHome.addView(tv(line,13,false)); shown++;
        }
        ah.close();
        if(shown==0) annualHome.addView(tv("Nessun anno precedente inserito.",13,false));
        content.addView(annualHome);

        LinearLayout choose=card(); choose.addView(tv("Scegli portafoglio",18,true));
        for(String name:ps){ Button b=btn(name.toUpperCase(Locale.ITALY)); b.setOnClickListener(v->{setPortfolio(name);showDashboard();}); choose.addView(b); }
        Button total=btn("TOTALE"); total.setOnClickListener(v->{setPortfolio(TOTAL);showDashboard();}); choose.addView(total);
        Button addPortfolio=btn("＋ AGGIUNGI PORTAFOGLIO"); addPortfolio.setOnClickListener(v->addPortfolioDialog()); choose.addView(addPortfolio);
        content.addView(choose);

        Button quick=btn("＋ Inserimento rapido"); quick.setOnClickListener(v->quickEntry()); content.addView(quick);
        LinearLayout disclaimerCard=card();
        disclaimerCard.addView(tv("Avvertenza",16,true));
        disclaimerCard.addView(tv("Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.",12,false));
        content.addView(disclaimerCard);

        LinearLayout info=card(); info.addView(tv("V3.4.3 – gestione portafogli più coerente",17,true));
        info.addView(tv("• aggiungi un portafoglio solo dalla Home\n• nelle Impostazioni del singolo portafoglio gestisci solo quel portafoglio\n• da TOTALE puoi gestire anche i portafogli archiviati\n• nessun limite applicativo fisso al numero di portafogli\n• totale aggregato automatico dei portafogli attivi\n• capitale investito e liquidità mostrati separatamente\n• proventi del mese visibili nel rendimento\n• PAC interno separato dal capitale esterno\n• PAC tutto da liquidità interna con un tocco\n• controllo automatico della composizione PAC\n• storico guadagni degli anni precedenti\n• firma ideatore incorporata nel codice: by Paolo Ferrucci\n• backup CSV V3.4 con posizioni e gestione portafogli",14,false)); content.addView(info);
    }

    void quickEntry(){
        final java.util.List<String> ps=db.portfolioNames(true); if(ps.isEmpty()){toast("Aggiungi prima un portafoglio");return;}
        final String[] names=ps.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio").setItems(names,(d,which)->{
            String broker=names[which]; setPortfolio(broker);
            final String[] opts={"Provento","Patrimonio / rendimento","PAC"};
            new AlertDialog.Builder(this).setTitle(broker+" – Inserimento rapido").setItems(opts,(d2,x)->{if(x==0)showIncome();else if(x==1)showReturns();else showPac();}).show();
        }).show();
    }

    void showDashboard(){
        if(current.equals("HOME")){showHome();return;} heading("Dashboard",current);
        String broker=brokerFilter(); double gross=broker==null?db.sumIncomeActive("gross"):db.sumIncome(broker,"gross"), net=broker==null?db.sumIncomeActive("net"):db.sumIncome(broker,"net"); int nmonths=broker==null?db.monthsWithIncomeActive():db.monthsWithIncome(broker);
        double value=current.equals(TOTAL)?db.latestPortfolioValueAllActive():db.latestPortfolioValue(current);
        boolean totalView=current.equals(TOTAL);
        int separatedCount=totalView?db.separatedPortfolioCountActive():0, unseparatedCount=totalView?db.unseparatedPortfolioCountActive():0;
        Double invested=totalView?db.knownInvestedValueAllActive():db.latestInvestedValue(current);
        Double cash=totalView?db.knownCashValueAllActive():db.latestCashValue(current);
        String splitStatus=value==0?"da inserire":"da separare";
        String invLabel=totalView&&unseparatedCount>0?"Capitale investito noto":"Capitale investito";
        String cashLabel=totalView&&unseparatedCount>0?"Liquidità nota":"Liquidità";
        String invValue=totalView?(value==0?"da inserire":(separatedCount==0?"da separare":euro.format(invested==null?0:invested)+" €")):(invested==null?splitStatus:euro.format(invested)+" €");
        String cashValue=totalView?(value==0?"da inserire":(separatedCount==0?"da separare":euro.format(cash==null?0:cash)+" €")):(cash==null?splitStatus:euro.format(cash)+" €");
        LinearLayout r1=new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(kpi(invLabel,invValue),new LinearLayout.LayoutParams(0,-2,1));
        r1.addView(kpi(cashLabel,cashValue),new LinearLayout.LayoutParams(0,-2,1)); content.addView(r1);
        LinearLayout r2=new LinearLayout(this); r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(kpi("Patrimonio totale",value==0?"da inserire":euro.format(value)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        r2.addView(kpi("Proventi lordi",euro.format(gross)+" €"),new LinearLayout.LayoutParams(0,-2,1)); content.addView(r2);
        if(totalView&&unseparatedCount>0){
            java.util.List<String> pending=new ArrayList<>(); for(String b:db.portfolioNames(true))if(!db.isPortfolioFullySeparated(b))pending.add(b);
            LinearLayout pendingCard=card(); pendingCard.addView(tv("Patrimonio da separare",16,true));
            pendingCard.addView(tv(euro.format(db.unseparatedPortfolioValueAllActive())+" € • "+unseparatedCount+" portafogli da completare: "+android.text.TextUtils.join(", ",pending),13,false)); content.addView(pendingCard);
        }
        LinearLayout r3=new LinearLayout(this); r3.setOrientation(LinearLayout.HORIZONTAL);
        r3.addView(kpi("Netto",euro.format(net)+" €"),new LinearLayout.LayoutParams(0,-2,1));
        r3.addView(kpi("Media mensile",nmonths==0?"-":euro.format(gross/nmonths)+" €"),new LinearLayout.LayoutParams(0,-2,1)); content.addView(r3);
        Double ytd=calcYtdReturn(broker); content.addView(kpi("Rendimento YTD",ytd==null?"da compilare":pct.format(ytd)));

        LinearLayout breakdown=card(); breakdown.addView(tv("Ripartizione proventi",17,true));
        for(String cat:categories)addBar(breakdown,cat,broker==null?db.sumCategoryActive(cat):db.sumCategory(broker,cat),gross); content.addView(breakdown);

        LinearLayout chart=card(); chart.addView(tv("Proventi mensili lordi",17,true)); chart.addView(new ChartView(this,monthlyIncome(broker),false,"€"),new LinearLayout.LayoutParams(-1,dp(190))); content.addView(chart);
        LinearLayout pchart=card(); pchart.addView(tv("Patrimonio nel tempo",17,true)); pchart.addView(new ChartView(this,monthlyPortfolio(broker),true,"€"),new LinearLayout.LayoutParams(-1,dp(190))); content.addView(pchart);

        if(current.equals(TOTAL)){
            LinearLayout split=card(); split.addView(tv("Confronto portafogli",17,true));
            for(String b:db.portfolioNames(true)) split.addView(tv(b+": "+euro.format(db.latestPortfolioValue(b))+" € | proventi "+euro.format(db.sumIncome(b,"gross"))+" €",14,false));
            content.addView(split);
        } else {
            int pcnt=db.positionCount(current);
            if(pcnt>0){
                LinearLayout pos=card();pos.addView(tv("Posizioni importate",17,true));String sd=db.statusDate(current);
                pos.addView(tv(pcnt+" strumenti"+(sd.isEmpty()?"":" • situazione al "+sd),13,false));
                Button view=btn("Mostra posizioni");view.setOnClickListener(v->showPositionsDialog(current));pos.addView(view);content.addView(pos);
            }
        }
    }

    void addBar(LinearLayout parent,String label,double v,double total){
        double p=total==0?0:v/total; parent.addView(tv(label+": "+euro.format(v)+" €  ("+pct.format(p)+")",14,false));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(1000); bar.setProgress((int)Math.round(p*1000)); parent.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));
    }

    double[] monthlyIncome(String broker){double[] a=new double[12];for(int m=1;m<=12;m++)a[m-1]=broker==null?db.sumIncomeMonthActive(m,"gross"):db.sumIncomeMonth(broker,m,"gross");return a;}
    double[] monthlyPortfolio(String broker){
        double[] a=new double[12];
        if(broker==null){for(String b:db.portfolioNames(true)){double[] x=monthlyPortfolio(b);for(int i=0;i<12;i++)a[i]+=x[i];}return a;}
        Cursor c=db.snapshots(broker);while(c.moveToNext()){int m=c.getInt(c.getColumnIndexOrThrow("month"));Double f=getNullable(c,"final_value");if(f!=null)a[m-1]=f;}c.close();return carryForward(a);
    }
    double[] carryForward(double[] a){double last=0;for(int i=0;i<a.length;i++){if(a[i]>0)last=a[i];else if(last>0)a[i]=last;}return a;}

    EditText field(String hint,Double val){
        EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setBackgroundResource(R.drawable.input_bg);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);if(val!=null)e.setText(trim(val));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;
    }
    EditText textField(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setBackgroundResource(R.drawable.input_bg);e.setText(val==null?"":val);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    String trim(double d){if(Math.abs(d-Math.rint(d))<0.000001)return String.valueOf((long)Math.rint(d));return String.valueOf(d);}
    Double num(EditText e){String s=e.getText().toString().trim().replace(",",".");if(s.isEmpty())return null;try{return Double.parseDouble(s);}catch(Exception ex){return null;}}
    double n(EditText e){Double x=num(e);return x==null?0:x;}
    Double getNullable(Cursor c,String col){int i=c.getColumnIndexOrThrow(col);return c.isNull(i)?null:c.getDouble(i);}

    Spinner spinner(String[] data,int selected){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,data);s.setAdapter(a);if(selected>=0&&selected<data.length)s.setSelection(selected);return s;}

    void showIncome(){
        heading("Cedole e dividendi",current); java.util.List<String> pnames=db.portfolioNames(true); String defaultBroker=current.equals(TOTAL)?(pnames.isEmpty()?DbHelper.DIRECTA:pnames.get(0)):current;
        LinearLayout form=card(); form.addView(tv("＋ Nuovo provento",17,true));
        String[] brokerNames=pnames.toArray(new String[0]); int defIdx=Math.max(0,pnames.indexOf(defaultBroker)); Spinner brokerSp=spinner(brokerNames,defIdx); if(current.equals(TOTAL))form.addView(brokerSp);
        Spinner monthSp=spinner(months,Calendar.getInstance().get(Calendar.MONTH)); form.addView(monthSp);
        EditText date=textField("Data (YYYY-MM-DD)","2026-"+String.format(Locale.US,"%02d",monthSp.getSelectedItemPosition()+1)+"-01"); form.addView(date);
        Spinner cat=spinner(categories,0); form.addView(cat); Spinner typ=spinner(incomeTypes,0); form.addView(typ);
        EditText instrument=textField("Strumento / nome",""); form.addView(instrument); EditText isin=textField("ISIN (facoltativo)",""); form.addView(isin);
        EditText gross=field("Importo lordo €",null); form.addView(gross); EditText tax=field("Aliquota %",db.getTaxRate()*100); form.addView(tax); EditText notes=textField("Note",""); form.addView(notes);
        TextView netPreview=tv("Netto calcolato: -",15,true); form.addView(netPreview);
        Button calc=btn("Calcola netto"); calc.setOnClickListener(v->{Double g=num(gross),t=num(tax);netPreview.setText(g==null?"Netto calcolato: -":"Netto calcolato: "+euro.format(g*(1-(t==null?26:t)/100.0))+" €");}); form.addView(calc);
        Button save=btn("Salva provento"); save.setOnClickListener(v->{
            Double g=num(gross);if(g==null){toast("Inserisci l'importo lordo");return;} int m=monthSp.getSelectedItemPosition()+1; double tr=(num(tax)==null?26:num(tax))/100.0;String b=current.equals(TOTAL)?brokerSp.getSelectedItem().toString():current;
            db.addIncome(date.getText().toString().trim(),m,b,cat.getSelectedItem().toString(),instrument.getText().toString(),isin.getText().toString(),typ.getSelectedItem().toString(),g,tr,notes.getText().toString());toast("Provento salvato");showIncome();
        }); form.addView(save); content.addView(form);

        LinearLayout list=card(); list.addView(tv("Ultimi movimenti",17,true)); Cursor c=brokerFilter()==null?db.incomesActive():db.incomes(brokerFilter());int count=0;
        while(c.moveToNext()&&count<20){long id=c.getLong(c.getColumnIndexOrThrow("id"));String b=c.getString(c.getColumnIndexOrThrow("broker")),dt=c.getString(c.getColumnIndexOrThrow("date")),inst=c.getString(c.getColumnIndexOrThrow("instrument")),ca=c.getString(c.getColumnIndexOrThrow("category"));double g=c.getDouble(c.getColumnIndexOrThrow("gross")),ne=c.getDouble(c.getColumnIndexOrThrow("net"));
            LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.HORIZONTAL);TextView tx=tv(dt+" • "+b+"\n"+ca+" • "+inst+"\n"+euro.format(g)+" € lordo | "+euro.format(ne)+" € netto",13,false);rr.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=btn("×");del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Eliminare questo movimento?").setPositiveButton("Elimina",(dd,w)->{db.deleteIncome(id);showIncome();}).setNegativeButton("Annulla",null).show());rr.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));list.addView(rr);count++;
        }c.close(); if(count==0)list.addView(tv("Nessun provento inserito.",14,false));content.addView(list);
    }

    void showReturns(){
        heading("Rendimento",current);
        if(current.equals(TOTAL)){
            LinearLayout info=card();info.addView(tv("Totale aggregato",17,true));info.addView(tv("Il rendimento totale viene calcolato sommando valori e flussi esterni di tutti i portafogli attivi. Per modificare i dati scegli il singolo portafoglio.",14,false));content.addView(info);
            showReturnSummary(null);return;
        }
        Spinner sp=spinner(months,Calendar.getInstance().get(Calendar.MONTH));content.addView(sp);LinearLayout form=card();content.addView(form);
        Runnable load=()->{
            form.removeAllViews();int m=sp.getSelectedItemPosition()+1;
            Double ini=null,fin=null,dep=null,wd=null,iniInv=null,iniCash=null,finInv=null,finCash=null;String notes="";
            Cursor c=db.snapshot(current,m);if(c.moveToFirst()){ini=getNullable(c,"initial_value");fin=getNullable(c,"final_value");dep=getNullable(c,"deposits");wd=getNullable(c,"withdrawals");iniInv=getNullable(c,"initial_invested");iniCash=getNullable(c,"initial_cash");finInv=getNullable(c,"final_invested");finCash=getNullable(c,"final_cash");int i=c.getColumnIndexOrThrow("notes");notes=c.isNull(i)?"":c.getString(i);}c.close();
            final Double oldIni=ini,oldFin=fin;
            double grossM=db.sumIncomeMonth(current,m,"gross"), netM=db.sumIncomeMonth(current,m,"net");
            form.addView(tv(months[m-1]+" – "+current,17,true));
            form.addView(tv("Proventi del mese (automatici): "+euro.format(grossM)+" € lordi | "+euro.format(netM)+" € netti\nCapitale investito = soli titoli. Liquidità = denaro non investito. Il rendimento usa il patrimonio totale (investito + liquidità).",14,true));
            if((oldIni!=null&&iniInv==null&&iniCash==null)||(oldFin!=null&&finInv==null&&finCash==null))
                form.addView(tv("Questo mese contiene un vecchio valore totale non ancora separato. Compila investito e liquidità per convertirlo senza perdere lo storico.",12,false));
            EditText fIniInv=field("Capitale investito INIZIALE €",iniInv),fIniCash=field("Liquidità INIZIALE €",iniCash),fFinInv=field("Capitale investito FINALE €",finInv),fFinCash=field("Liquidità FINALE €",finCash),fDep=field("Versamenti ESTERNI €",dep),fWd=field("Prelievi ESTERNI €",wd),fNotes=textField("Note",notes);
            form.addView(fIniInv);form.addView(fIniCash);form.addView(fFinInv);form.addView(fFinCash);form.addView(fDep);form.addView(fWd);form.addView(fNotes);
            TextView out=tv("",15,true);Button save=btn("Calcola e salva");save.setOnClickListener(v->{
                Double iInv=num(fIniInv),iCash=num(fIniCash),fInv=num(fFinInv),fCash=num(fFinCash);
                Double iniTotal=sumParts(iInv,iCash),finTotal=sumParts(fInv,fCash);
                if(iniTotal==null||finTotal==null){toast("Inserisci capitale investito e/o liquidità sia iniziali sia finali");return;}
                db.saveSnapshotSplit(current,m,iInv,iCash,fInv,fCash,num(fDep),num(fWd),fNotes.getText().toString());
                Double rr=calcReturnValues(iniTotal,finTotal,num(fDep),num(fWd));
                out.setText("Patrimonio iniziale: "+euro.format(iniTotal)+" €\nPatrimonio finale: "+euro.format(finTotal)+" €\nRendimento mese: "+(rr==null?"-":pct.format(rr))+"\nProventi lordi mese: "+euro.format(grossM)+" €\nProventi netti mese: "+euro.format(netM)+" €");toast("Patrimonio e rendimento salvati");
            });form.addView(save);form.addView(out);
            LinearLayout explain=card();explain.addView(tv("Formula",16,true));explain.addView(tv("Patrimonio totale = capitale investito + liquidità. Spostare denaro dalla liquidità ai titoli è un movimento interno e non crea rendimento. Modified Dietz semplificato: (Patrimonio finale − Patrimonio iniziale − flusso esterno netto) / (Patrimonio iniziale + 0,5 × flusso esterno netto).",13,false));form.addView(explain);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){load.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        showReturnSummary(current);
    }

    void showReturnSummary(String broker){
        LinearLayout x=card();x.addView(tv("Andamento rendimento mensile",17,true));x.addView(new ChartView(this,monthlyReturns(broker),false,"%"),new LinearLayout.LayoutParams(-1,dp(190)));Double ytd=calcYtdReturn(broker);x.addView(tv("YTD: "+(ytd==null?"da compilare":pct.format(ytd)),15,true));content.addView(x);
    }

    Double sumParts(Double invested,Double cash){if(invested==null&&cash==null)return null;return (invested==null?0:invested)+(cash==null?0:cash);}
    Double calcReturnValues(Double ini,Double fin,Double dep,Double wd){if(ini==null||fin==null)return null;double flow=(dep==null?0:dep)-(wd==null?0:wd);double denom=ini+0.5*flow;if(Math.abs(denom)<0.000001)return null;return (fin-ini-flow)/denom;}
    Double calcMonthlyReturn(String broker,int month){
        if(broker==null){double ini=0,fin=0,dep=0,wd=0;boolean any=false;for(String b:db.portfolioNames(true)){Double[] x=snapshotValues(b,month);boolean has=x[0]!=null&&x[1]!=null;if(has){any=true;ini+=x[0];fin+=x[1];dep+=x[2]==null?0:x[2];wd+=x[3]==null?0:x[3];}}return any?calcReturnValues(ini,fin,dep,wd):null;}
        Double[] x=snapshotValues(broker,month);return calcReturnValues(x[0],x[1],x[2],x[3]);
    }
    Double[] snapshotValues(String broker,int month){Double[] a={null,null,null,null};Cursor c=db.snapshot(broker,month);if(c.moveToFirst()){a[0]=getNullable(c,"initial_value");a[1]=getNullable(c,"final_value");a[2]=getNullable(c,"deposits");a[3]=getNullable(c,"withdrawals");}c.close();return a;}
    double[] monthlyReturns(String broker){double[] a=new double[12];for(int m=1;m<=12;m++){Double r=calcMonthlyReturn(broker,m);a[m-1]=r==null?Double.NaN:r*100;}return a;}
    Double calcYtdReturn(String broker){double prod=1;boolean any=false;for(int m=1;m<=12;m++){Double r=calcMonthlyReturn(broker,m);if(r!=null){prod*=1+r;any=true;}}return any?prod-1:null;}

    void showPac(){
        heading("PAC",current);
        if(current.equals(TOTAL)){showPacTotal();return;}
        Spinner sp=spinner(months,Calendar.getInstance().get(Calendar.MONTH));content.addView(sp);LinearLayout form=card();content.addView(form);
        Runnable load=()->{
            form.removeAllViews();int m=sp.getSelectedItemPosition()+1;Double planned=null,ext=null,in=null;String notes="";Cursor c=db.pac(current,m);if(c.moveToFirst()){planned=getNullable(c,"planned");ext=getNullable(c,"external_actual");in=getNullable(c,"internal_actual");int ni=c.getColumnIndexOrThrow("notes");notes=c.isNull(ni)?"":c.getString(ni);}c.close();if(planned==null)planned=db.getPacDefault(current);
            double netIncome=db.sumIncomeMonth(current,m,"net");double suggestedInternal=Math.min(netIncome,planned),suggestedExternal=Math.max(planned-suggestedInternal,0);form.addView(tv(months[m-1]+" – "+current,17,true));form.addView(tv("Proventi netti del mese: "+euro.format(netIncome)+" €",14,true));
            EditText fPlan=field("PAC programmato €",planned),fExt=field("Capitale esterno effettivo €",ext),fIn=field("Proventi/reinvestimento interno €",in),fNotes=textField("Note",notes);form.addView(fPlan);form.addView(fExt);form.addView(fIn);form.addView(fNotes);
            Button suggest=btn("Usa copertura suggerita");
            suggest.setOnClickListener(v->{fIn.setText(trim(suggestedInternal));fExt.setText(trim(suggestedExternal));});
            form.addView(suggest);

            Button allInternal=btn("PAC tutto da liquidità interna");
            allInternal.setOnClickListener(v->{double p=n(fPlan);fExt.setText("0");fIn.setText(trim(p));});
            form.addView(allInternal);

            form.addView(tv("Copertura suggerita = usa prima i proventi netti del mese e considera esterno il resto.\nPAC tutto da liquidità interna = 0 € esterno e 100% finanziato con liquidità/proventi già presenti nel broker.",12,false));

            TextView out=tv("",15,true);
            Button save=btn("Salva PAC");
            save.setOnClickListener(v->{
                double p=n(fPlan),e=n(fExt),ii=n(fIn);
                Runnable doSave=()->{
                    db.savePac(current,m,num(fPlan),num(fExt),num(fIn),fNotes.getText().toString());
                    double covMonth=p==0?0:netIncome/p;
                    double covInternal=p==0?0:ii/p;
                    double covExternal=p==0?0:e/p;
                    out.setText("Copertura da proventi del mese: "+pct.format(covMonth)
                            +"\nFinanziamento interno registrato: "+pct.format(covInternal)
                            +"\nCapitale esterno registrato: "+pct.format(covExternal)
                            +"\nSurplus proventi del mese dopo PAC: "+euro.format(Math.max(netIncome-p,0))+" €");
                    toast("PAC salvato");
                };
                double diff=Math.abs((e+ii)-p);
                if(p>0 && diff>0.01){
                    new AlertDialog.Builder(this)
                            .setTitle("Controlla composizione PAC")
                            .setMessage("Capitale esterno + finanziamento interno = "+euro.format(e+ii)+" €, mentre il PAC programmato è "+euro.format(p)+" €.\n\nDifferenza: "+euro.format(diff)+" €. Vuoi salvare comunque?")
                            .setPositiveButton("Salva comunque",(d,w)->doSave.run())
                            .setNegativeButton("Correggi",null)
                            .show();
                }else doSave.run();
            });
            form.addView(save);form.addView(out);
        };
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){load.run();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        showPacYear(current);
    }

    void showPacYear(String broker){
        LinearLayout c=card();c.addView(tv("Copertura PAC anno",17,true));double planned=0,ext=0,in=0;Cursor p=db.pacs(broker);while(p.moveToNext()){Double x=getNullable(p,"planned"),e=getNullable(p,"external_actual"),ii=getNullable(p,"internal_actual");if(x!=null)planned+=x;if(e!=null)ext+=e;if(ii!=null)in+=ii;}p.close();double net=db.sumIncome(broker,"net");c.addView(tv("PAC programmato: "+euro.format(planned)+" €\nProventi netti YTD: "+euro.format(net)+" €\nCapitale esterno registrato: "+euro.format(ext)+" €\nReinvestimento interno registrato: "+euro.format(in)+" €\nCopertura teorica: "+pct.format(planned==0?0:net/planned),14,false));content.addView(c);
    }

    void showPacTotal(){
        LinearLayout c=card();c.addView(tv("PAC complessivo",17,true));double totalPlan=0,totalExt=0;StringBuilder lines=new StringBuilder();for(String b:db.portfolioNames(true)){double p=sumPacField(b,"planned"),e=sumPacField(b,"external_actual");totalPlan+=p;totalExt+=e;lines.append(b).append(" programmato: ").append(euro.format(p)).append(" €\n");}lines.append("Capitale esterno registrato totale: ").append(euro.format(totalExt)).append(" €");c.addView(tv(lines.toString(),14,false));c.addView(tv("Nota: reinvestimenti e PAC finanziati da cedole/dividendi restano flussi interni e non sono nuovo capitale esterno.",13,true));content.addView(c);
        LinearLayout chart=card();chart.addView(tv("Copertura netta mensile del PAC",17,true));double[] v=new double[12];for(int m=1;m<=12;m++){double plan=0;for(String b:db.portfolioNames(true))plan+=getPacMonth(b,m);double net=db.sumIncomeMonthActive(m,"net");v[m-1]=plan==0?0:100*net/plan;}chart.addView(new ChartView(this,v,false,"%"),new LinearLayout.LayoutParams(-1,dp(190)));content.addView(chart);
    }
    double sumPacField(String broker,String field){Cursor c=db.pacs(broker);double x=0;while(c.moveToNext()){Double v=getNullable(c,field);if(v!=null)x+=v;}c.close();return x;}
    double getPacMonth(String broker,int month){Cursor c=db.pac(broker,month);double x=db.getPacDefault(broker);if(c.moveToFirst()){Double v=getNullable(c,"planned");if(v!=null)x=v;}c.close();return x;}

    void showHistory(){
        heading("Storico",current);

        LinearLayout annual=card(); annual.addView(tv("Storico risultati annuali",17,true));
        annual.addView(tv("Qui puoi conservare i risultati degli anni precedenti separando proventi e performance del portafoglio.",12,false));
        Button addYear=btn("＋ Aggiungi / modifica anno");
        addYear.setOnClickListener(v->annualHistoryDialog(null)); annual.addView(addYear);
        Cursor ah=db.annualHistory();
        while(ah.moveToNext()){
            int yr=ah.getInt(ah.getColumnIndexOrThrow("year"));
            Double gi=getNullable(ah,"gross_income"), ni=getNullable(ah,"net_income"), pp=getNullable(ah,"portfolio_profit"), rr=getNullable(ah,"return_rate");
            String notes=ah.getString(ah.getColumnIndexOrThrow("notes"));
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(0,dp(7),0,dp(7));
            String text=yr+"";
            if(gi!=null) text+="\nProventi lordi: "+euro.format(gi)+" €";
            if(ni!=null) text+="\nProventi netti: "+euro.format(ni)+" €";
            if(pp!=null) text+="\nGuadagno/perdita portafoglio: "+euro.format(pp)+" €";
            if(rr!=null) text+="\nRendimento: "+pct.format(rr);
            if(notes!=null&&!notes.trim().isEmpty()) text+="\n"+notes;
            row.addView(tv(text,13,true));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=btn("Modifica"); edit.setOnClickListener(v->annualHistoryDialog(yr));
            Button del=btn("Elimina"); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Elimina anno "+yr).setMessage("Eliminare definitivamente questo dato storico annuale? Il dato non verrà ricreato automaticamente.").setPositiveButton("Elimina",(d,w)->{db.deleteAnnualHistory(yr);showHistory();}).setNegativeButton("Annulla",null).show());
            actions.addView(edit,new LinearLayout.LayoutParams(0,dp(46),1)); actions.addView(del,new LinearLayout.LayoutParams(0,dp(46),1));
            row.addView(actions); annual.addView(row);
        }
        ah.close(); content.addView(annual);

        String broker=brokerFilter();LinearLayout chart=card();chart.addView(tv("Proventi mensili 2026",17,true));chart.addView(new ChartView(this,monthlyIncome(broker),false,"€"),new LinearLayout.LayoutParams(-1,dp(180)));content.addView(chart);
        for(int m=1;m<=12;m++){
            double gross=broker==null?db.sumIncomeMonthActive(m,"gross"):db.sumIncomeMonth(broker,m,"gross"),net=broker==null?db.sumIncomeMonthActive(m,"net"):db.sumIncomeMonth(broker,m,"net"),value=portfolioMonth(broker,m),pac=0; if(current.equals(TOTAL)){for(String b:db.portfolioNames(true))pac+=getPacMonth(b,m);}else pac=getPacMonth(current,m);Double r=calcMonthlyReturn(broker,m);
            if(gross==0&&value==0&&r==null&&m>Calendar.getInstance().get(Calendar.MONTH)+1)continue;
            LinearLayout c=card();c.addView(tv(months[m-1],16,true));c.addView(tv("Patrimonio: "+(value==0?"-":euro.format(value)+" €")+"\nLordo: "+euro.format(gross)+" € | Netto: "+euro.format(net)+" €\nPAC programmato: "+euro.format(pac)+" €\nRendimento: "+(r==null?"-":pct.format(r)),14,false));content.addView(c);
        }
    }
    double portfolioMonth(String broker,int m){if(broker==null){double total=0;for(String b:db.portfolioNames(true))total+=portfolioMonth(b,m);return total;}Cursor c=db.snapshot(broker,m);double x=0;if(c.moveToFirst()){Double f=getNullable(c,"final_value");if(f!=null)x=f;}c.close();return x;}

    void annualHistoryDialog(Integer existingYear){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(8),dp(18),0);
        EditText year=field("Anno",existingYear==null?null:existingYear.doubleValue());
        EditText gross=field("Proventi lordi annuali €",null);
        EditText net=field("Proventi netti annuali € (opzionale)",null);
        EditText profit=field("Guadagno/perdita portafoglio €",null);
        EditText ret=field("Rendimento annuo %",null);
        EditText notes=textField("Note","");
        if(existingYear!=null){
            Cursor c=db.annualHistoryYear(existingYear);
            if(c.moveToFirst()){
                Double x=getNullable(c,"gross_income"); if(x!=null)gross.setText(trim(x));
                x=getNullable(c,"net_income"); if(x!=null)net.setText(trim(x));
                x=getNullable(c,"portfolio_profit"); if(x!=null)profit.setText(trim(x));
                x=getNullable(c,"return_rate"); if(x!=null)ret.setText(trim(x*100.0));
                notes.setText(c.getString(c.getColumnIndexOrThrow("notes")));
            }
            c.close();
        }
        box.addView(year);box.addView(gross);box.addView(net);box.addView(profit);box.addView(ret);box.addView(notes);
        new AlertDialog.Builder(this).setTitle(existingYear==null?"Aggiungi anno":"Modifica "+existingYear).setView(box)
                .setPositiveButton("Salva",(d,w)->{
                    Double y=num(year); if(y==null||y<1900||y>2100){toast("Anno non valido");return;}
                    int yy=(int)Math.round(y);
                    Double rr=num(ret); if(rr!=null)rr=rr/100.0;
                    if(existingYear!=null && existingYear!=yy) db.deleteAnnualHistory(existingYear);
                    db.saveAnnualHistory(yy,num(gross),num(net),num(profit),rr,notes.getText().toString());
                    toast("Storico annuale salvato");showHistory();
                }).setNegativeButton("Annulla",null).show();
    }

    void showSettings(){
        heading("Impostazioni",current);
        LinearLayout legal=card();
        legal.addView(tv("Informazioni sull'app",17,true));
        legal.addView(tv("Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.",12,false));
        content.addView(legal);

        LinearLayout s=card();s.addView(tv("Parametri generali",17,true));
        EditText tax=field("Aliquota fiscale %",db.getTaxRate()*100);s.addView(tax);
        s.addView(tv("Firma ideatore: by Paolo Ferrucci\nLa firma è incorporata nel codice dell'app e non è modificabile dalle impostazioni.",12,true));
        Button save=btn("Salva impostazioni");save.setOnClickListener(v->{if(num(tax)!=null)db.setSettingDouble("tax_rate",n(tax)/100);toast("Impostazioni salvate");});s.addView(save);content.addView(s);

        LinearLayout pm=card();
        if(!current.equals(TOTAL) && !current.equals("HOME") && db.portfolioExists(current)){
            pm.addView(tv("Gestione portafoglio",17,true));
            Cursor one=db.portfolios(); boolean found=false;
            while(one.moveToNext()){
                String name=one.getString(one.getColumnIndexOrThrow("name"));
                if(!name.equals(current)) continue;
                found=true;
                boolean active=one.getInt(one.getColumnIndexOrThrow("active"))==1;
                double pac=one.getDouble(one.getColumnIndexOrThrow("pac_default"));
                pm.addView(tv(name+(active?"":" (archiviato)")+" • PAC predefinito "+euro.format(pac)+" €",14,true));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button ren=btn("Rinomina");ren.setOnClickListener(v->renamePortfolioDialog(name));
                Button arc=btn(active?"Archivia":"Riattiva");arc.setOnClickListener(v->{db.setPortfolioActive(name,!active);showSettings();});
                Button del=btn("Elimina");del.setOnClickListener(v->deletePortfolioDialog(name));
                actions.addView(ren,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(arc,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));
                pm.addView(actions);
                break;
            }
            one.close();
            if(!found) pm.addView(tv("Portafoglio non disponibile.",13,false));
        }else{
            pm.addView(tv("Gestione portafogli",17,true));
            pm.addView(tv("Da TOTALE puoi gestire i portafogli esistenti. Per crearne uno nuovo usa + AGGIUNGI PORTAFOGLIO nella Home.",13,false));
            Cursor pc=db.portfolios();
            while(pc.moveToNext()){
                String name=pc.getString(pc.getColumnIndexOrThrow("name"));
                boolean active=pc.getInt(pc.getColumnIndexOrThrow("active"))==1;
                double pac=pc.getDouble(pc.getColumnIndexOrThrow("pac_default"));
                LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(0,dp(8),0,dp(8));
                row.addView(tv(name+(active?"":" (archiviato)")+" • PAC predefinito "+euro.format(pac)+" €",14,true));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button ren=btn("Rinomina");ren.setOnClickListener(v->renamePortfolioDialog(name));
                Button arc=btn(active?"Archivia":"Riattiva");arc.setOnClickListener(v->{db.setPortfolioActive(name,!active);showSettings();});
                Button del=btn("Elimina");del.setOnClickListener(v->deletePortfolioDialog(name));
                actions.addView(ren,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(arc,new LinearLayout.LayoutParams(0,dp(48),1));
                actions.addView(del,new LinearLayout.LayoutParams(0,dp(48),1));
                row.addView(actions);pm.addView(row);
            }
            pc.close();
        }
        content.addView(pm);

        LinearLayout directa=card();directa.addView(tv("Importazione patrimonio da PDF",17,true));
        directa.addView(tv("Importazione disponibile per QUALSIASI portafoglio. Formato attualmente supportato: PDF 'Situazione Patrimoniale' Directa. Prima di aprire il file scegli sempre il portafoglio di destinazione; l'app riconosce ISIN, quantità, prezzo, controvalore, totale titoli e liquidità.",13,false));
        if(!current.equals(TOTAL) && !current.equals("HOME") && db.portfolioExists(current)){
            String lastImport=db.statusDate(current);
            directa.addView(tv("Portafoglio attivo: "+current+(lastImport.isEmpty()?"":"\nUltimo import: "+lastImport+" • "+db.positionCount(current)+" posizioni"),13,true));
        }else directa.addView(tv("Destinazione: scegli un portafoglio quando avvii l'importazione.",13,true));
        Button pdf=btn("Importa situazione patrimoniale PDF");pdf.setOnClickListener(v->choosePortfolioForPdfImport());directa.addView(pdf);content.addView(directa);

        LinearLayout backup=card();backup.addView(tv("Backup e migrazione",17,true));Button exp=btn("Esporta backup CSV V3.4");exp.setOnClickListener(v->exportCsv());backup.addView(exp);Button imp=btn("Importa CSV V2 / V3 / V3.1 / V3.2 / V3.3 / V3.4");imp.setOnClickListener(v->importCsv());backup.addView(imp);content.addView(backup);
        LinearLayout rules=card();rules.addView(tv("Regole importanti",17,true));rules.addView(tv("• Capitale investito = valore dei soli titoli.\n• Liquidità = denaro disponibile e non investito.\n• Patrimonio totale = capitale investito + liquidità.\n• Il rendimento usa il patrimonio totale: comprare titoli usando liquidità già nel broker è un movimento interno.\n• Inserisci nei versamenti/prelievi solo denaro che entra o esce davvero dal broker.\n• PAC e reinvestimenti interni non sono nuovo capitale.\n• Rinomina mantiene storico, cedole, rendimento e PAC collegati.\n• Archivia conserva i dati ma esclude il portafoglio dal Totale.\n• Elimina cancella definitivamente tutti i dati di quel portafoglio.",14,false));content.addView(rules);
    }

    void addPortfolioDialog(){
        final boolean fromHome=current.equals("HOME");
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(8),dp(18),0);EditText name=textField("Nome portafoglio","");EditText pac=field("PAC mensile predefinito €",0.0);box.addView(name);box.addView(pac);
        new AlertDialog.Builder(this).setTitle("Aggiungi portafoglio").setView(box).setPositiveButton("Aggiungi",(d,w)->{String nme=name.getText().toString().trim();double p=num(pac)==null?0:n(pac);if(db.addPortfolio(nme,p)){toast("Portafoglio aggiunto");if(fromHome)showHome();else showSettings();}else toast("Nome non valido o già esistente");}).setNegativeButton("Annulla",null).show();
    }
    void renamePortfolioDialog(String oldName){
        EditText name=textField("Nuovo nome",oldName);new AlertDialog.Builder(this).setTitle("Rinomina "+oldName).setView(name).setPositiveButton("Rinomina",(d,w)->{String nme=name.getText().toString().trim();if(db.renamePortfolio(oldName,nme)){if(current.equals(oldName))current=nme;toast("Portafoglio rinominato");showSettings();}else toast("Nome non valido o già esistente");}).setNegativeButton("Annulla",null).show();
    }
    void deletePortfolioDialog(String name){
        new AlertDialog.Builder(this).setTitle("Elimina portafoglio").setMessage("Eliminare definitivamente '"+name+"'? Saranno cancellati cedole, rendimenti, snapshot e PAC collegati. Per conservarli usa Archivia.").setPositiveButton("ELIMINA",(d,w)->{db.deletePortfolio(name);if(current.equals(name))current="HOME";toast("Portafoglio eliminato");showSettings();}).setNegativeButton("Annulla",null).show();
    }

    void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"Portafoglio_2026_V34_backup.csv");startActivityForResult(i,41);}
    void importCsv(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,42);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        if(requestCode==41){try(OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write(buildCsv().getBytes(StandardCharsets.UTF_8));toast("Backup esportato");}catch(Exception e){toast("Errore export: "+e.getMessage());}}
        else if(requestCode==42){try(InputStream is=getContentResolver().openInputStream(data.getData())){ByteArrayOutputStream bo=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))>0)bo.write(buf,0,n);pendingImport=bo.toString("UTF-8");confirmImport();}catch(Exception e){toast("Errore import: "+e.getMessage());}}
        else if(requestCode==43){readDirectaPdf(data.getData());}
    }

    void choosePortfolioForPdfImport(){
        java.util.List<String> ps=db.portfolioNames(true);
        if(ps.isEmpty()){toast("Crea prima almeno un portafoglio");return;}
        String[] names=ps.toArray(new String[0]);
        int checked=0;
        if(!current.equals(TOTAL) && !current.equals("HOME")){
            int i=ps.indexOf(current);if(i>=0)checked=i;
        }
        final int initial=checked;
        new AlertDialog.Builder(this).setTitle("Scegli portafoglio di destinazione")
                .setSingleChoiceItems(names,checked,null)
                .setPositiveButton("Continua",(d,w)->{
                    AlertDialog ad=(AlertDialog)d;int pos=ad.getListView().getCheckedItemPosition();
                    if(pos<0)pos=initial;pendingImportPortfolio=names[pos];openPortfolioPdf();
                }).setNegativeButton("Annulla",null).show();
    }

    void openPortfolioPdf(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");startActivityForResult(i,43);}

    void readDirectaPdf(Uri uri){
        toast("Lettura PDF in corso…");
        new Thread(()->{
            try(InputStream is=getContentResolver().openInputStream(uri); PDDocument doc=PDDocument.load(is)){
                String raw=new PDFTextStripper().getText(doc); DirectaImport out=parseDirectaSituation(raw);
                runOnUiThread(()->previewDirectaImport(out));
            }catch(Exception e){runOnUiThread(()->toast("PDF Directa non riconosciuto: "+e.getMessage()));}
        }).start();
    }

    DirectaImport parseDirectaSituation(String raw) throws Exception{
        if(raw==null||!raw.toUpperCase(Locale.ITALY).contains("SITUAZIONE PATRIMONIALE"))throw new Exception("non sembra una Situazione Patrimoniale Directa");
        DirectaImport out=new DirectaImport();String t=raw.replace('\u00A0',' ');
        Matcher dm=Pattern.compile("(?i)data\\s*Operazione\\s*(\\d{1,2}/\\d{1,2}/\\d{4})").matcher(t);if(dm.find())out.date=dm.group(1);
        Matcher cm=Pattern.compile("(?i)TOTALE\\s+LIQUIDITA'\\s*:\\s*([0-9.]+,[0-9]{2})").matcher(t);if(cm.find())out.cash=parseItalian(cm.group(1));
        Pattern row=Pattern.compile("(?m)^\\s*(.+?)\\s+\\(([A-Z]{2}[A-Z0-9]{10})\\)\\s+([0-9.,]+)\\s+([0-9.,]+)\\s+([0-9.]+,[0-9]{2})\\s*$");
        Matcher rm=row.matcher(t);double sum=0;while(rm.find()){String name=rm.group(1).trim(),isin=rm.group(2).trim();Double q=parseItalian(rm.group(3)),pr=parseItalian(rm.group(4)),v=parseItalian(rm.group(5));if(q!=null&&pr!=null&&v!=null){out.positions.add(new DbHelper.Position(isin,name,q,pr,v,out.date));sum+=v;}}
        Matcher tm=Pattern.compile("(?is)TOTALE\\s+TITOLI\\s+EURO.{0,120}?([0-9.]+,[0-9]{2})").matcher(t);if(tm.find())out.printedInvested=parseItalian(tm.group(1));
        out.invested=out.printedInvested!=null?out.printedInvested:sum;
        if(out.positions.isEmpty())throw new Exception("nessuna posizione trovata");if(out.cash==null)throw new Exception("liquidità non trovata");
        if(out.printedInvested!=null&&Math.abs(sum-out.printedInvested)>0.10)throw new Exception("totale titoli non coerente con le posizioni");
        return out;
    }

    Double parseItalian(String s){try{if(s==null)return null;String x=s.trim().replace(".","").replace(",",".");return Double.parseDouble(x);}catch(Exception e){return null;}}

    void previewDirectaImport(DirectaImport out){
        if(pendingImportPortfolio==null||pendingImportPortfolio.isEmpty()||!db.portfolioExists(pendingImportPortfolio)){toast("Portafoglio di destinazione non valido");return;}
        pendingDirectaImport=out;double total=(out.invested==null?0:out.invested)+(out.cash==null?0:out.cash);
        StringBuilder msg=new StringBuilder();msg.append("Portafoglio destinazione: ").append(pendingImportPortfolio).append("\n");msg.append("Data situazione: ").append(out.date.isEmpty()?"non indicata":out.date).append("\n\n");msg.append("Posizioni trovate: ").append(out.positions.size()).append("\n");msg.append("Capitale investito: ").append(euro.format(out.invested)).append(" €\n");msg.append("Liquidità: ").append(euro.format(out.cash)).append(" €\n");msg.append("Patrimonio totale: ").append(euro.format(total)).append(" €\n\n");msg.append("Confermando, saranno sostituite SOLO le posizioni e la situazione patrimoniale corrente del portafoglio '").append(pendingImportPortfolio).append("'. Cedole, PAC, rendimenti e storico non vengono cancellati.");
        new AlertDialog.Builder(this).setTitle("Anteprima import patrimonio").setMessage(msg.toString()).setPositiveButton("Importa",(d,w)->confirmPortfolioPdfImport()).setNegativeButton("Annulla",null).show();
    }

    void confirmPortfolioPdfImport(){
        if(pendingDirectaImport==null||pendingImportPortfolio==null||pendingImportPortfolio.isEmpty())return;
        String target=pendingImportPortfolio;
        db.replacePositionsAndStatus(target,pendingDirectaImport.positions,pendingDirectaImport.invested,pendingDirectaImport.cash,pendingDirectaImport.date,"PDF Situazione Patrimoniale Directa");
        toast(target+" aggiornato: "+pendingDirectaImport.positions.size()+" posizioni importate");
        current=target;pendingDirectaImport=null;pendingImportPortfolio="";showDashboard();
    }

    void showPositionsDialog(String broker){
        Cursor c=db.positions(broker);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(4),dp(10),dp(4));int n=0;
        while(c.moveToNext()){n++;String name=c.getString(c.getColumnIndexOrThrow("instrument"));String isin=c.getString(c.getColumnIndexOrThrow("isin"));double q=c.getDouble(c.getColumnIndexOrThrow("quantity")),pr=c.getDouble(c.getColumnIndexOrThrow("price")),v=c.getDouble(c.getColumnIndexOrThrow("current_value"));box.addView(tv(name+"\n"+isin+" • Q.tà "+trim(q)+" • Prezzo "+trim(pr)+" • Valore "+euro.format(v)+" €",13,n==1));}
        c.close();ScrollView sc=new ScrollView(this);sc.addView(box);new AlertDialog.Builder(this).setTitle("Posizioni "+broker+" ("+n+")").setView(sc).setPositiveButton("Chiudi",null).show();
    }

    void confirmImport(){new AlertDialog.Builder(this).setTitle("Importa backup").setMessage("Vuoi sostituire tutti i dati attuali con quelli del file? Usa 'Aggiungi' solo se sei certo di non creare duplicati.").setPositiveButton("Sostituisci",(d,w)->{db.clearTablesOnly();parseImport(pendingImport);showHome();}).setNeutralButton("Aggiungi",(d,w)->{parseImport(pendingImport);showHome();}).setNegativeButton("Annulla",null).show();}

    String esc(String s){return s==null?"":s.replace(";",",").replace("\n"," ");}
    String val(Double d){return d==null?"":String.valueOf(d);}
    String buildCsv(){
        StringBuilder s=new StringBuilder();s.append("PORTAFOGLIO2026_V34;4\n");s.append("SETTING;tax_rate;").append(db.getTaxRate()).append("\n");Cursor ports=db.portfolios();while(ports.moveToNext())s.append("PORTFOLIO;").append(esc(ports.getString(ports.getColumnIndexOrThrow("name")))).append(";").append(ports.getInt(ports.getColumnIndexOrThrow("active"))).append(";").append(ports.getDouble(ports.getColumnIndexOrThrow("pac_default"))).append("\n");ports.close();
        Cursor c=db.incomes(null);while(c.moveToNext())s.append("INCOME;").append(esc(c.getString(c.getColumnIndexOrThrow("date")))).append(";").append(c.getInt(c.getColumnIndexOrThrow("month"))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("broker")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("category")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("instrument")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("isin")))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("income_type")))).append(";").append(c.getDouble(c.getColumnIndexOrThrow("gross"))).append(";").append(c.getDouble(c.getColumnIndexOrThrow("tax_rate"))).append(";").append(esc(c.getString(c.getColumnIndexOrThrow("notes")))).append("\n");c.close();
        for(String b:db.portfolioNames(false)){Cursor r=db.snapshots(b);while(r.moveToNext())s.append("SNAPSHOT;").append(esc(b)).append(";").append(r.getInt(r.getColumnIndexOrThrow("month"))).append(";").append(val(getNullable(r,"initial_value"))).append(";").append(val(getNullable(r,"final_value"))).append(";").append(val(getNullable(r,"deposits"))).append(";").append(val(getNullable(r,"withdrawals"))).append(";").append(esc(r.getString(r.getColumnIndexOrThrow("notes")))).append(";").append(val(getNullable(r,"initial_invested"))).append(";").append(val(getNullable(r,"initial_cash"))).append(";").append(val(getNullable(r,"final_invested"))).append(";").append(val(getNullable(r,"final_cash"))).append("\n");r.close();Cursor p=db.pacs(b);while(p.moveToNext())s.append("PAC;").append(esc(b)).append(";").append(p.getInt(p.getColumnIndexOrThrow("month"))).append(";").append(val(getNullable(p,"planned"))).append(";").append(val(getNullable(p,"external_actual"))).append(";").append(val(getNullable(p,"internal_actual"))).append(";").append(esc(p.getString(p.getColumnIndexOrThrow("notes")))).append("\n");p.close();}
        Cursor pos=db.allPositions();while(pos.moveToNext())s.append("POSITION;").append(esc(pos.getString(pos.getColumnIndexOrThrow("broker")))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("isin")))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("instrument")))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("quantity"))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("price"))).append(";").append(pos.getDouble(pos.getColumnIndexOrThrow("current_value"))).append(";").append(esc(pos.getString(pos.getColumnIndexOrThrow("source_date")))).append("\n");pos.close();
        Cursor st=db.portfolioStatuses();while(st.moveToNext())s.append("STATUS;").append(esc(st.getString(st.getColumnIndexOrThrow("broker")))).append(";").append(val(getNullable(st,"invested"))).append(";").append(val(getNullable(st,"cash"))).append(";").append(esc(st.getString(st.getColumnIndexOrThrow("source_date")))).append(";").append(esc(st.getString(st.getColumnIndexOrThrow("source")))).append("\n");st.close();
        Cursor ah=db.annualHistory();while(ah.moveToNext())s.append("ANNUAL;").append(ah.getInt(ah.getColumnIndexOrThrow("year"))).append(";").append(val(getNullable(ah,"gross_income"))).append(";").append(val(getNullable(ah,"net_income"))).append(";").append(val(getNullable(ah,"portfolio_profit"))).append(";").append(val(getNullable(ah,"return_rate"))).append(";").append(esc(ah.getString(ah.getColumnIndexOrThrow("notes")))).append("\n");ah.close();
        return s.toString();
    }

    Double parseD(String s){try{return s==null||s.trim().isEmpty()?null:Double.parseDouble(s.replace(",","."));}catch(Exception e){return null;}}
    void parseImport(String text){
        try{
            String[] lines=text.replace("\r","").split("\n");if(lines.length==0)return;boolean v2=lines[0].startsWith("SEZIONE;");
            if(v2){importV2(lines);toast("Backup V2 importato in Directa");return;}
            for(String line:lines){if(line.trim().isEmpty())continue;String[] a=line.split(";",-1);if(a[0].equals("SETTING")&&a.length>=3){if(a[1].equals("tax_rate")){Double x=parseD(a[2]);if(x!=null)db.setSettingDouble(a[1],x);}else if(a[1].equals("creator_name")){/* ignorato: firma incorporata nel codice */}}else if(a[0].equals("ANNUAL")&&a.length>=7){Double yr=parseD(a[1]);if(yr!=null)db.saveAnnualHistory((int)Math.round(yr),parseD(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),a[6]);}else if(a[0].equals("PORTFOLIO")&&a.length>=4){Double pac=parseD(a[3]);db.ensurePortfolio(a[1]);db.setPortfolioPacDefault(a[1],pac==null?0:pac);db.setPortfolioActive(a[1],!a[2].equals("0"));}else if(a[0].equals("INCOME")&&a.length>=11){Double g=parseD(a[8]),tr=parseD(a[9]);db.ensurePortfolio(a[3]);if(g!=null)db.addIncome(a[1],Integer.parseInt(a[2]),a[3],a[4],a[5],a[6],a[7],g,tr==null?db.getTaxRate():tr,a[10]);}else if(a[0].equals("SNAPSHOT")&&a.length>=8){db.ensurePortfolio(a[1]);if(a.length>=12&&(parseD(a[8])!=null||parseD(a[9])!=null||parseD(a[10])!=null||parseD(a[11])!=null))db.saveSnapshotSplit(a[1],Integer.parseInt(a[2]),parseD(a[8]),parseD(a[9]),parseD(a[10]),parseD(a[11]),parseD(a[5]),parseD(a[6]),a[7]);else db.saveSnapshot(a[1],Integer.parseInt(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),parseD(a[6]),a[7]);}else if(a[0].equals("POSITION")&&a.length>=8){Double q=parseD(a[4]),pr=parseD(a[5]),v=parseD(a[6]);if(q!=null&&pr!=null&&v!=null)db.savePosition(a[1],new DbHelper.Position(a[2],a[3],q,pr,v,a[7]));}else if(a[0].equals("STATUS")&&a.length>=6){db.savePortfolioStatus(a[1],parseD(a[2]),parseD(a[3]),a[4],a[5]);}else if(a[0].equals("PAC")&&a.length>=7){db.ensurePortfolio(a[1]);db.savePac(a[1],Integer.parseInt(a[2]),parseD(a[3]),parseD(a[4]),parseD(a[5]),a[6]);}}
             toast("Backup V3/V3.4 importato");
        }catch(Exception e){toast("Import non riuscito: "+e.getMessage());}
    }

    int monthIndex(String name){for(int i=0;i<months.length;i++)if(months[i].equalsIgnoreCase(name))return i+1;return 0;}
    void importV2(String[] lines){
        for(int i=1;i<lines.length;i++){String[] a=lines[i].split(";",-1);if(a.length<13||!a[0].equals("MESE"))continue;int m=monthIndex(a[1]);if(m==0)continue;String date="2026-"+String.format(Locale.US,"%02d",m)+"-28";String[] cats={"Azioni","ETF","ETP","Certificati"};for(int j=0;j<4;j++){Double g=parseD(a[2+j]);if(g!=null&&g!=0)db.addIncome(date,m,DbHelper.DIRECTA,cats[j],"Import V2","",j==3?"Cedola":"Distribuzione",g,db.getTaxRate(),"Importato da V2");}db.saveSnapshot(DbHelper.DIRECTA,m,parseD(a[7]),parseD(a[8]),parseD(a[9]),parseD(a[10]),a[12]);}
        for(int m=1;m<=12;m++)db.savePac(DbHelper.DIRECTA,m,db.getPacDefault(DbHelper.DIRECTA),null,null,"Import V2");
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    public class ChartView extends View {
        double[] data; boolean line; String unit; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        public ChartView(Context c,double[] d,boolean l,String u){super(c);data=d;line=l;unit=u;p.setTypeface(android.graphics.Typeface.DEFAULT);setPadding(dp(8),dp(10),dp(8),dp(8));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();p.setColor(Color.rgb(220,224,228));p.setStrokeWidth(dp(1));c.drawLine(dp(28),h-dp(30),w-dp(8),h-dp(30),p);double max=0,min=0;for(double v:data)if(!Double.isNaN(v)){max=Math.max(max,v);min=Math.min(min,v);}double range=max-min;if(range<0.0001)range=1;float left=dp(32),right=w-dp(10),top=dp(15),bottom=h-dp(32),step=(right-left)/12f;
            if(line){p.setColor(Color.rgb(31,126,209));p.setStrokeWidth(dp(3));Path path=new Path();boolean started=false;for(int i=0;i<12;i++){double v=data[i];if(Double.isNaN(v)||v==0&&max>0&&i>0)continue;float x=left+step*(i+0.5f),y=(float)(bottom-(v-min)/range*(bottom-top));if(!started){path.moveTo(x,y);started=true;}else path.lineTo(x,y);c.drawCircle(x,y,dp(3),p);}c.drawPath(path,p);}else{for(int i=0;i<12;i++){double v=data[i];if(Double.isNaN(v))continue;float x=left+step*i+dp(2),bw=step-dp(4);double zeroPos=(0-min)/range;float y0=(float)(bottom-zeroPos*(bottom-top));float y=(float)(bottom-(v-min)/range*(bottom-top));p.setColor(v>=0?Color.rgb(31,126,209):Color.rgb(198,65,65));c.drawRect(x,Math.min(y,y0),x+bw,Math.max(y,y0),p);}}
            p.setColor(Color.rgb(70,78,86));p.setTextSize(dp(9));for(int i=0;i<12;i+=2)c.drawText(months[i].substring(0,3),left+step*i,bottom+dp(18),p);p.setTextSize(dp(9));c.drawText(unit+" max "+shortNum(max),dp(4),dp(11),p);
        }
        String shortNum(double x){if(Double.isNaN(x))return "-";if(Math.abs(x)>=1000)return String.format(Locale.ITALY,"%.1fk",x/1000.0);return String.format(Locale.ITALY,"%.1f",x);}
    }
}
