# Portafoglio 2026 V3.4.10 Personale

Versione tecnica 3.4.9 - versionCode 51.

## Novità V3.4.10 - motore multi-broker
- ogni portafoglio ha ora un **profilo broker** separato dal nome del portafoglio;
- alla creazione è disponibile **Riconoscimento automatico**: nomi come Trade Republic / Trade Repubblic / TR vengono associati al profilo Trade Republic, Directa a Directa e così via;
- se il broker non è riconosciuto viene usato il profilo **Generico**, senza attivare funzioni non pertinenti;
- il nucleo contabile resta comune a tutti: versamenti, prelievi, trasferimenti, PAC, acquisti, vendite, commissioni, imposte, interessi e altro;
- per **Trade Republic** vengono attivate categorie aggiuntive: **Round up, Saveback e Pagamento carta**;
- Round up è classificato come movimento interno, Saveback come premio, Pagamento carta come movimento escluso dall'analisi degli investimenti;
- il profilo broker può essere cambiato dalle Impostazioni senza rinominare il portafoglio;
- nuovo **Registro movimenti** nello Storico, con classificazione automatica del flusso e nessun doppio conteggio nei proventi;
- backup CSV V3.4.10 conserva sia il profilo broker sia il registro movimenti ed è retrocompatibile con i backup precedenti.
- il **backup completo** è ora disponibile **solo nelle Impostazioni generali** della Home, non più dentro le impostazioni dei singoli portafogli;
- i pulsanti chiariscono che esportazione e ripristino riguardano **tutti i portafogli** e l'intero database dell'app;

## Regola contabile
Ogni euro deve avere una sola natura: nuovo capitale esterno, movimento interno, rendimento/premio, costo oppure movimento escluso. Dividendi e cedole restano nella sezione Proventi; reinvestirli non li trasforma in nuovo capitale.

## Funzioni mantenute
- portafogli multipli e Totale aggregato;
- proventi, PAC, rendimento mensile e da inizio anno;
- posizioni con quantità, PMC e prezzo attuale;
- importazione situazione patrimoniale da PDF;
- backup e migrazione CSV;
- firma ideatore incorporata nel codice: by Paolo Ferrucci.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria, raccomandazioni di investimento né servizi di intermediazione.

## Backup generale
Dalla Home è disponibile il pulsante **IMPOSTAZIONI GENERALI**. Solo in questa sezione compaiono i comandi di esportazione e importazione del backup. Il backup è unico e comprende tutti i portafogli; non esiste un backup separato per il portafoglio attualmente aperto.


## Sicurezza backup V3.4.10
- verifica il file prima di proporre la sostituzione;
- mostra un riepilogo dei portafogli e dei record trovati;
- il ripristino è transazionale: se una riga è errata, il database torna allo stato precedente;
- prima di ogni sostituzione crea un backup interno di emergenza;
- un file vuoto o non riconosciuto non può più cancellare i dati correnti.
