# Portafoglio 2026 — V3.4.41 DEV

Aggiornamento dedicato alla chiusura annuale e allo storico patrimoniale.

## Novità V3.4.41 DEV

- Storico annuale: capitale iniziale/finale in testa, versamenti e prelievi separati.
- Variazione patrimonio distinta dal rendimento: gli aumenti di capitale non sono più trattati come guadagno.
- Rendimento annuale automatico con flussi esterni neutralizzati e ponderazione delle date disponibili (Modified Dietz).
- Risultato investimenti in euro calcolato da capitale finale - capitale iniziale - versamenti + prelievi.
- Tutte le percentuali sono automatiche; nessun campo percentuale manuale.
- Tasse annuali calcolate dai movimenti fiscali noti, senza stima automatica fissa del 26%.
- Dialog annuale con etichette permanenti e anteprima live dei calcoli.
- Backup esteso a versamenti/prelievi annuali; chiusura anno e passaggio automatico del capitale finale invariati.

## Compatibilità

- applicationId: `it.portafoglio2026.v32`
- versionCode: `82`
- versionName: `3.4.41-dev`
- DB_VERSION: `14`
- Migrazione automatica da DB 12: i dati esistenti restano conservati; i nuovi campi annuali vengono aggiunti senza cancellare lo storico.
