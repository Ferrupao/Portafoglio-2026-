# Portafoglio 2026 V3.4.5 Personale

Versione tecnica 3.4.5 - versionCode 47.

## Novità V3.4.5
- interfaccia patrimonio resa più intuitiva: Valore titoli, Liquidità e Patrimonio totale;
- eliminate dalle schermate principali le diciture tecniche “noto”, “da separare” e “da compilare”;
- “Proventi YTD” rinominato “Proventi da inizio anno”;
- “Rendimento YTD” rinominato “Rendimento da inizio anno”;
- se mancano i dati necessari il rendimento mostra “Non disponibile” e spiega cosa serve;
- AGGIORNA PATRIMONIO offre solo due strade: INSERIMENTO MANUALE oppure IMPORTA DA FILE;
- l’inserimento manuale contiene nello stesso flusso riepilogo patrimoniale e posizioni dettagliate;
- campi posizione: nome, ISIN/ticker, quantità, PMC e prezzo attuale;
- Valore attuale = quantità × prezzo attuale;
- Capitale di carico = quantità × PMC;
- Guadagno/Perdita in euro e percentuale quando il PMC è disponibile;
- il Valore titoli si aggiorna automaticamente dalla somma delle posizioni; la Liquidità resta separata;
- chiarito il rendimento: acquisti/vendite con liquidità interna non sono rendimento; versamenti/prelievi esterni sono solo denaro che entra/esce dal broker; dividendi/cedole non sono versamenti esterni;
- importazione PDF resta opzionale e senza riferimenti al broker nell’interfaccia generale;
- backup aggiornato a CSV V3.4.5 e compatibile con i dati precedenti.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

L’app resta uno strumento locale di registrazione e analisi e non fornisce raccomandazioni di investimento.
