package it.portafoglio2026.v3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "portafoglio2026_v32.db";
    public static final int DB_VERSION = 3;

    public static final String DIRECTA = "Directa";
    public static final String TR = "Trade Republic";

    public DbHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)");
        db.execSQL("CREATE TABLE portfolios ("+
                "name TEXT PRIMARY KEY, active INTEGER NOT NULL DEFAULT 1, pac_default REAL NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE income_records ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, category TEXT, instrument TEXT, isin TEXT, income_type TEXT, gross REAL, tax_rate REAL, net REAL, notes TEXT)");
        db.execSQL("CREATE TABLE snapshots ("+
                "broker TEXT, month INTEGER, initial_value REAL, final_value REAL, deposits REAL, withdrawals REAL, notes TEXT, "+
                "initial_invested REAL, initial_cash REAL, final_invested REAL, final_cash REAL, PRIMARY KEY(broker,month))");
        db.execSQL("CREATE TABLE pac_records ("+
                "broker TEXT, month INTEGER, planned REAL, external_actual REAL, internal_actual REAL, notes TEXT, PRIMARY KEY(broker,month))");
        db.execSQL("CREATE TABLE annual_history ("+
                "year INTEGER PRIMARY KEY, gross_income REAL, net_income REAL, portfolio_profit REAL, return_rate REAL, notes TEXT)");

        putSetting(db,"tax_rate","0.26");
        putSetting(db,"year","2026");

        // VERSIONE DISTRIBUZIONE:
        // nessun dato finanziario personale precaricato.
        // Una nuova installazione parte con un solo portafoglio neutro e vuoto.
        String starter="Portafoglio 1";
        insertPortfolio(db,starter,0.0,1,1);
        for(int m=1;m<=12;m++){
            insertPac(db,starter,m,0.0,null,null,"");
        }
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion < 2){
            db.execSQL("CREATE TABLE IF NOT EXISTS annual_history ("+
                    "year INTEGER PRIMARY KEY, gross_income REAL, net_income REAL, portfolio_profit REAL, return_rate REAL, notes TEXT)");
        }
        if(oldVersion < 3){
            db.execSQL("ALTER TABLE snapshots ADD COLUMN initial_invested REAL");
            db.execSQL("ALTER TABLE snapshots ADD COLUMN initial_cash REAL");
            db.execSQL("ALTER TABLE snapshots ADD COLUMN final_invested REAL");
            db.execSQL("ALTER TABLE snapshots ADD COLUMN final_cash REAL");
        }
    }

    private void insertPortfolio(SQLiteDatabase db,String name,double pac,int active,int order){
        ContentValues cv=new ContentValues();cv.put("name",name);cv.put("pac_default",pac);cv.put("active",active);cv.put("sort_order",order);
        db.insertWithOnConflict("portfolios",null,cv,SQLiteDatabase.CONFLICT_IGNORE);
    }

    private void insertMonth(SQLiteDatabase db,int month,double stocks,double etf,double etp,double cert){
        String date="2026-"+(month<10?"0":"")+month+"-28";
        if(stocks!=0) insertIncome(db,date,month,DIRECTA,"Azioni","Storico aggregato","","Dividendo",stocks,0.26,"");
        if(etf!=0) insertIncome(db,date,month,DIRECTA,"ETF","Storico aggregato","","Distribuzione ETF",etf,0.26,"");
        if(etp!=0) insertIncome(db,date,month,DIRECTA,"ETP","Storico aggregato","","Distribuzione ETP",etp,0.26,"");
        if(cert!=0) insertIncome(db,date,month,DIRECTA,"Certificati","Storico aggregato","","Cedola",cert,0.26,"");
    }

    private void putSetting(SQLiteDatabase db,String k,String v){
        ContentValues cv=new ContentValues(); cv.put("k",k); cv.put("v",v); db.insert("settings",null,cv);
    }

    private void insertIncome(SQLiteDatabase db,String date,int month,String broker,String category,String instrument,String isin,String type,double gross,double tax,String notes){
        ContentValues cv=new ContentValues();
        cv.put("date",date); cv.put("month",month); cv.put("broker",broker); cv.put("category",category); cv.put("instrument",instrument); cv.put("isin",isin); cv.put("income_type",type);
        cv.put("gross",gross); cv.put("tax_rate",tax); cv.put("net",gross*(1.0-tax)); cv.put("notes",notes);
        db.insert("income_records",null,cv);
    }

    private void insertSnapshot(SQLiteDatabase db,String broker,int month,Double initial,Double fin,Double dep,Double wd,String notes){
        ContentValues cv=new ContentValues(); cv.put("broker",broker); cv.put("month",month);
        putNullable(cv,"initial_value",initial); putNullable(cv,"final_value",fin); putNullable(cv,"deposits",dep); putNullable(cv,"withdrawals",wd); cv.put("notes",notes);
        db.insert("snapshots",null,cv);
    }

    private void insertPac(SQLiteDatabase db,String broker,int month,Double planned,Double ext,Double in,String notes){
        ContentValues cv=new ContentValues(); cv.put("broker",broker); cv.put("month",month); putNullable(cv,"planned",planned); putNullable(cv,"external_actual",ext); putNullable(cv,"internal_actual",in); cv.put("notes",notes);
        db.insert("pac_records",null,cv);
    }

    private void insertAnnualHistory(SQLiteDatabase db,int year,Double gross,Double net,Double profit,Double ret,String notes){
        ContentValues cv=new ContentValues(); cv.put("year",year);
        putNullable(cv,"gross_income",gross); putNullable(cv,"net_income",net); putNullable(cv,"portfolio_profit",profit); putNullable(cv,"return_rate",ret);
        cv.put("notes",notes);
        db.insertWithOnConflict("annual_history",null,cv,SQLiteDatabase.CONFLICT_IGNORE);
    }

    private static void putNullable(ContentValues cv,String key,Double v){ if(v==null) cv.putNull(key); else cv.put(key,v); }
    private static Double sumNullable(Double a,Double b){ if(a==null&&b==null)return null; return (a==null?0:a)+(b==null?0:b); }

    public double getSettingDouble(String key,double def){
        Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{key});
        double out=def; if(c.moveToFirst()) try{out=Double.parseDouble(c.getString(0));}catch(Exception ignored){} c.close(); return out;
    }
    public void setSettingDouble(String key,double val){
        ContentValues cv=new ContentValues(); cv.put("v",String.valueOf(val));
        int n=getWritableDatabase().update("settings",cv,"k=?",new String[]{key});
        if(n==0){cv.put("k",key);getWritableDatabase().insert("settings",null,cv);}
    }
    public String getSetting(String key,String def){
        Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{key});
        String out=def; if(c.moveToFirst() && c.getString(0)!=null) out=c.getString(0); c.close(); return out;
    }
    public void setSetting(String key,String val){
        ContentValues cv=new ContentValues(); cv.put("v",val==null?"":val);
        int n=getWritableDatabase().update("settings",cv,"k=?",new String[]{key});
        if(n==0){cv.put("k",key);getWritableDatabase().insert("settings",null,cv);}
    }
    public double getTaxRate(){return getSettingDouble("tax_rate",0.26);}

    // ---- Gestione portafogli dinamici: nessun limite applicativo fisso ----
    public List<String> portfolioNames(boolean activeOnly){
        List<String> out=new ArrayList<>();
        String sql="SELECT name FROM portfolios"+(activeOnly?" WHERE active=1":"")+" ORDER BY sort_order,name COLLATE NOCASE";
        Cursor c=getReadableDatabase().rawQuery(sql,null);while(c.moveToNext())out.add(c.getString(0));c.close();return out;
    }
    public boolean portfolioExists(String name){
        Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM portfolios WHERE name=? LIMIT 1",new String[]{name});boolean yes=c.moveToFirst();c.close();return yes;
    }
    public boolean ensurePortfolio(String name){
        if(name==null||name.trim().isEmpty())return false;String n=name.trim();if(portfolioExists(n))return true;
        return addPortfolio(n,0.0);
    }
    public boolean addPortfolio(String name,double pacDefault){
        if(name==null)return false;String n=name.trim();if(n.isEmpty()||portfolioExists(n)||n.equalsIgnoreCase("Totale")||n.equalsIgnoreCase("HOME"))return false;
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_order),0)+1 FROM portfolios",null);int ord=1;if(c.moveToFirst())ord=c.getInt(0);c.close();
        ContentValues cv=new ContentValues();cv.put("name",n);cv.put("active",1);cv.put("pac_default",pacDefault);cv.put("sort_order",ord);
        long id=getWritableDatabase().insert("portfolios",null,cv);
        if(id<0)return false;
        for(int m=1;m<=12;m++)insertPac(getWritableDatabase(),n,m,pacDefault,null,null,"Nuovo portafoglio");
        return true;
    }
    public boolean renamePortfolio(String oldName,String newName){
        if(oldName==null||newName==null)return false;String n=newName.trim();if(n.isEmpty()||oldName.equals(n))return false;if(portfolioExists(n)||n.equalsIgnoreCase("Totale")||n.equalsIgnoreCase("HOME"))return false;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            ContentValues cv=new ContentValues();cv.put("name",n);int changed=db.update("portfolios",cv,"name=?",new String[]{oldName});if(changed==0)return false;
            ContentValues b=new ContentValues();b.put("broker",n);db.update("income_records",b,"broker=?",new String[]{oldName});db.update("snapshots",b,"broker=?",new String[]{oldName});db.update("pac_records",b,"broker=?",new String[]{oldName});
            db.setTransactionSuccessful();return true;
        }finally{db.endTransaction();}
    }
    public void setPortfolioActive(String name,boolean active){ContentValues cv=new ContentValues();cv.put("active",active?1:0);getWritableDatabase().update("portfolios",cv,"name=?",new String[]{name});}
    public boolean isPortfolioActive(String name){Cursor c=getReadableDatabase().rawQuery("SELECT active FROM portfolios WHERE name=?",new String[]{name});boolean x=c.moveToFirst()&&c.getInt(0)==1;c.close();return x;}
    public boolean deletePortfolio(String name){
        if(name==null)return false;SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            db.delete("income_records","broker=?",new String[]{name});db.delete("snapshots","broker=?",new String[]{name});db.delete("pac_records","broker=?",new String[]{name});int n=db.delete("portfolios","name=?",new String[]{name});db.setTransactionSuccessful();return n>0;
        }finally{db.endTransaction();}
    }
    public double getPacDefault(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT pac_default FROM portfolios WHERE name=?",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public void setPortfolioPacDefault(String broker,double value){ContentValues cv=new ContentValues();cv.put("pac_default",value);getWritableDatabase().update("portfolios",cv,"name=?",new String[]{broker});}
    public Cursor portfolios(){return getReadableDatabase().rawQuery("SELECT * FROM portfolios ORDER BY sort_order,name COLLATE NOCASE",null);}

    public long addIncome(String date,int month,String broker,String category,String instrument,String isin,String type,double gross,double tax,String notes){
        ensurePortfolio(broker);ContentValues cv=new ContentValues(); cv.put("date",date);cv.put("month",month);cv.put("broker",broker);cv.put("category",category);cv.put("instrument",instrument);cv.put("isin",isin);cv.put("income_type",type);cv.put("gross",gross);cv.put("tax_rate",tax);cv.put("net",gross*(1-tax));cv.put("notes",notes);
        return getWritableDatabase().insert("income_records",null,cv);
    }
    public void deleteIncome(long id){getWritableDatabase().delete("income_records","id=?",new String[]{String.valueOf(id)});}
    public Cursor incomes(String broker){
        if(broker==null) return getReadableDatabase().rawQuery("SELECT * FROM income_records ORDER BY date DESC,id DESC",null);
        return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE broker=? ORDER BY date DESC,id DESC",new String[]{broker});
    }
    public Cursor incomesForMonth(String broker,int month){
        if(broker==null) return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE month=? ORDER BY date,id",new String[]{String.valueOf(month)});
        return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE broker=? AND month=? ORDER BY date,id",new String[]{broker,String.valueOf(month)});
    }
    public double sumIncome(String broker,String field){
        String sql=broker==null?"SELECT COALESCE(SUM("+field+"),0) FROM income_records":"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE broker=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double sumIncomeMonth(String broker,int month,String field){
        String sql=broker==null?"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE month=?":"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE broker=? AND month=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?new String[]{String.valueOf(month)}:new String[]{broker,String.valueOf(month)}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double sumCategory(String broker,String category){
        String sql=broker==null?"SELECT COALESCE(SUM(gross),0) FROM income_records WHERE category=?":"SELECT COALESCE(SUM(gross),0) FROM income_records WHERE broker=? AND category=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?new String[]{category}:new String[]{broker,category}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public int monthsWithIncome(String broker){
        String sql=broker==null?"SELECT COUNT(DISTINCT month) FROM income_records WHERE gross<>0":"SELECT COUNT(DISTINCT month) FROM income_records WHERE broker=? AND gross<>0";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker}); int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x;
    }
    public Cursor incomesActive(){return getReadableDatabase().rawQuery("SELECT i.* FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 ORDER BY i.date DESC,i.id DESC",null);}
    public double sumIncomeActive(String field){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(i."+field+"),0) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double sumIncomeMonthActive(int month,String field){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(i."+field+"),0) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 AND i.month=?",new String[]{String.valueOf(month)});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double sumCategoryActive(String category){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(i.gross),0) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 AND i.category=?",new String[]{category});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public int monthsWithIncomeActive(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT i.month) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 AND i.gross<>0",null);int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x;}

    public void saveSnapshot(String broker,int month,Double initial,Double fin,Double dep,Double wd,String notes){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);putNullable(cv,"initial_value",initial);putNullable(cv,"final_value",fin);putNullable(cv,"deposits",dep);putNullable(cv,"withdrawals",wd);cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("snapshots",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void saveSnapshotSplit(String broker,int month,Double initialInvested,Double initialCash,Double finalInvested,Double finalCash,Double dep,Double wd,String notes){
        ensurePortfolio(broker);Double initial=sumNullable(initialInvested,initialCash),fin=sumNullable(finalInvested,finalCash);
        ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);
        putNullable(cv,"initial_value",initial);putNullable(cv,"final_value",fin);putNullable(cv,"deposits",dep);putNullable(cv,"withdrawals",wd);cv.put("notes",notes);
        putNullable(cv,"initial_invested",initialInvested);putNullable(cv,"initial_cash",initialCash);putNullable(cv,"final_invested",finalInvested);putNullable(cv,"final_cash",finalCash);
        getWritableDatabase().insertWithOnConflict("snapshots",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor snapshot(String broker,int month){return getReadableDatabase().rawQuery("SELECT * FROM snapshots WHERE broker=? AND month=?",new String[]{broker,String.valueOf(month)});}
    public Cursor snapshots(String broker){return getReadableDatabase().rawQuery("SELECT * FROM snapshots WHERE broker=? ORDER BY month",new String[]{broker});}
    public double latestPortfolioValue(String broker){
        Cursor c=getReadableDatabase().rawQuery("SELECT final_value FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public Double latestInvestedValue(String broker){
        Cursor c=getReadableDatabase().rawQuery("SELECT final_invested FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});Double x=null;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();return x;
    }
    public Double latestCashValue(String broker){
        Cursor c=getReadableDatabase().rawQuery("SELECT final_cash FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});Double x=null;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();return x;
    }
    private Double latestSplitAllActive(String field){
        double sum=0;boolean any=false;
        for(String b:portfolioNames(true)){
            Cursor c=getReadableDatabase().rawQuery("SELECT final_value,"+field+" FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{b});
            if(c.moveToFirst()){any=true;if(c.isNull(1)){c.close();return null;}sum+=c.getDouble(1);}c.close();
        }
        return any?sum:null;
    }
    public Double latestInvestedValueAllActive(){return latestSplitAllActive("final_invested");}
    public Double latestCashValueAllActive(){return latestSplitAllActive("final_cash");}
    public double latestPortfolioValueAllActive(){double x=0;for(String b:portfolioNames(true))x+=latestPortfolioValue(b);return x;}

    public void savePac(String broker,int month,Double planned,Double ext,Double in,String notes){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);putNullable(cv,"planned",planned);putNullable(cv,"external_actual",ext);putNullable(cv,"internal_actual",in);cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("pac_records",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor pac(String broker,int month){return getReadableDatabase().rawQuery("SELECT * FROM pac_records WHERE broker=? AND month=?",new String[]{broker,String.valueOf(month)});}
    public Cursor pacs(String broker){return getReadableDatabase().rawQuery("SELECT * FROM pac_records WHERE broker=? ORDER BY month",new String[]{broker});}

    public void saveAnnualHistory(int year,Double gross,Double net,Double profit,Double ret,String notes){
        ContentValues cv=new ContentValues(); cv.put("year",year);
        putNullable(cv,"gross_income",gross); putNullable(cv,"net_income",net); putNullable(cv,"portfolio_profit",profit); putNullable(cv,"return_rate",ret);
        cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("annual_history",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor annualHistory(){return getReadableDatabase().rawQuery("SELECT * FROM annual_history ORDER BY year DESC",null);}
    public Cursor annualHistoryYear(int year){return getReadableDatabase().rawQuery("SELECT * FROM annual_history WHERE year=?",new String[]{String.valueOf(year)});}
    public void deleteAnnualHistory(int year){getWritableDatabase().delete("annual_history","year=?",new String[]{String.valueOf(year)});}
public void clearTablesOnly(){SQLiteDatabase db=getWritableDatabase(); db.delete("income_records",null,null); db.delete("snapshots",null,null); db.delete("pac_records",null,null); db.delete("annual_history",null,null);}

    public void clearAllUserData(){
        SQLiteDatabase db=getWritableDatabase(); db.delete("income_records",null,null); db.delete("snapshots",null,null); db.delete("pac_records",null,null); db.delete("annual_history",null,null);
        for(String b:portfolioNames(false))for(int m=1;m<=12;m++)insertPac(db,b,m,getPacDefault(b),null,null,"");
    }
}
