# Roadmap aggiornata – Portafoglio 2026 V3.4.19

**Direzione prodotto aggiornata con V3.4.26 DEV**

Principio guida: Portafoglio 2026 è un gestore semplice e intuitivo del portafoglio personale. Il centro dell'app è la contabilità di titoli, patrimonio, proventi, tasse, costi, acquisti, vendite e plus/minusvalenze. Le quotazioni servono soltanto ad aggiornare il valore del patrimonio e il P/L.

| Area | Stato | Situazione attuale / obiettivo |
|---|---|---|
| Multi-portafoglio / multi-broker | ✅ Fatto | Directa e Trade Republic separati, con totale complessivo |
| Titoli / liquidità / patrimonio | ✅ Fatto / evoluzione | Gestione del patrimonio e delle posizioni realmente possedute |
| Titoli / Posizioni | ✅ Fatto / evoluzione | Ricerca per nome, ISIN o ticker; categorie Azioni / ETF / ETP / Certificati / Altro; gestione per broker e totale |
| Dettaglio titolo | 🟡 Da completare | Quantità, PMC, valore attuale, P/L, proventi, storico operazioni e tasse/costi collegati |
| Quotazioni automatiche | 🔵 Supporto | Solo per aggiornare valore del patrimonio e P/L; non come piattaforma di mercato |
| Vendite e P/L realizzato | 🟡 In evoluzione | Vendita totale/parziale, commissioni, imposte, risultato lordo e netto |
| Codifica colori P/L | 🔵 V3.4.26 DEV | Plusvalenze verdi, minusvalenze rosse in riepiloghi, titoli, vendite e storico |
| Proventi | 🟡 Priorità centrale | Dividendi, cedole, distribuzioni, interessi e altri proventi con lordo, tasse e netto |
| Classificazione automatica proventi | 🔵 V3.4.26 DEV | Certificati→Cedola; Azioni→Dividendo; ETF/ETP→Distribuzione; Liquidità→Interesse; Altro→Altro provento |
| Proventi mese per mese | 🟡 In evoluzione | Totale mensile e annuale, lordo/netto, grafico e dettaglio del mese |
| Grafico proventi → dettaglio mese | 🟡 Presente / da rifinire | Tocco sul mese per aprire i proventi relativi |
| Contabilità fiscale semplificata | 🔵 V3.4.26 DEV | Imposte trattenute sui proventi, imposte su vendite, Tobin Tax, bollo/altre imposte, totale tasse registrate |
| Costi e commissioni | 🟡 In evoluzione | Costi separati da proventi e rendimento; configurazione per broker |
| Operazioni | 🔵 V3.4.26 DEV | Sezione dedicata a acquisti, vendite, movimenti, commissioni, imposte e storico |
| Barra inferiore | 🔵 V3.4.26 DEV | Home / Portafoglio / Proventi / Movimenti / Altro con sfondo più deciso, voci in grassetto e migliore risalto della sezione attiva |
| Dashboard patrimonio | 🔵 V3.4.26 DEV | Donut “Composizione patrimonio totale” nella Home subito sotto il riepilogo; aggrega tutti i portafogli, mostra Azioni / ETF / ETP / Certificati / Liquidità ed è cliccabile per aprire il dettaglio |
| Grafici secondari | 🔵 V3.4.26 DEV | Grafici patrimonio/proventi ridotti e collocati alla fine delle schermate come corredo, dopo funzioni e dati contabili |
| Importazione estratti conto | 🟡 In sviluppo | Carica PDF del broker e aggiorna posizioni, movimenti e proventi riducendo l'inserimento manuale |
| Snapshot mensili broker | 🟡 In sviluppo | Ogni nuovo estratto aggiorna il broker senza sommare erroneamente posizioni vecchie |
| Controllo duplicati import | 🟡 In sviluppo | Evitare doppie importazioni dello stesso estratto |
| Storico estratti / patrimonio | 🟡 Previsto | Conservare lo storico mensile anche quando lo snapshot corrente viene aggiornato |
| PAC | 🟡 Da integrare meglio | Gestione PAC e riconoscimento progressivamente più automatico dagli acquisti/import |
| Copertura PAC con proventi | 🟡 Previsto | Confrontare proventi netti incassati e versamenti PAC |
| Storico annuale | 🟡 Previsto / presente in parte | Lordo, netto, tasse, utile/perdita e rendimento anno per anno |
| Backup / ripristino | ✅ Presente / da testare | Backup completo di portafogli, movimenti, proventi, posizioni e storico; backup prima degli aggiornamenti |
| Migrazione database | 🟡 Controllo continuo | Aggiornare l'app senza perdere i dati delle versioni precedenti |
| Semplicità e UX smartphone | 🔵 Principio guida | Pochi passaggi, schermate pulite, pulsanti chiari, termini comprensibili e automazioni dove possibile |
| Grafica generale | 🔵 Fase successiva | Dashboard e card più pulite, contrasto, spaziature e aspetto professionale senza sovraccaricare |
| Nome e identità dell'app | 🔵 Fase successiva | Sostituire “Portafoglio 2026” con un nome commerciale originale dopo verifica disponibilità |
| Beta test | 🔵 In corso | V3.4.23 resta la beta distribuita ai tester; V3.4.26 DEV viene provata sul telefono principale come aggiornamento |
| QA commerciale | 🔵 Prima della pubblicazione | Test installazione/aggiornamento, backup/ripristino, import, contabilità, usabilità e assenza crash |
| Multi-broker esteso | 🔵 Successivo | Aggiungere altri broker solo dopo aver reso robusti flussi contabili e import |
| Versione Pro / monetizzazione | 🔵 Successivo | Valutare solo quando automazione, affidabilità, sicurezza e onboarding saranno maturi |

## Fuori dalla roadmap
Sono state eliminate come priorità le funzioni stile Investing.com/TradingView: news di mercato, segnali operativi, analisi tecnica, RSI/indicatori, screener, idee di trading, raccomandazioni di acquisto/vendita e watchlist di mercato come funzione centrale.

La regola per ogni nuova funzione resta: **deve rendere l'app più semplice, più automatica o più utile nella gestione contabile del portafoglio.**
