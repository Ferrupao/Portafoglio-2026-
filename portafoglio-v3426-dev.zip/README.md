# Portafoglio 2026 — V3.4.26 DEV

Versione di sviluppo basata sulla V3.4.23 Beta Test.

## Principio guida
L'app è un gestore contabile del portafoglio personale: titoli posseduti, patrimonio, proventi, tasse, costi, plus/minusvalenze e storico. Non è una piattaforma di trading o analisi di mercato.

## Novità V3.4.26 DEV
- Donut “Composizione patrimonio totale” nella Home subito sotto la Panoramica, aggregato su tutti i portafogli.
- Donut e legenda cliccabili: le categorie aprono i titoli filtrati; Liquidità apre il riepilogo per broker; il centro apre il Totale.
- Centratura del donut corretta per smartphone.
- Grafici secondari ridotti e spostati alla fine delle schermate come elementi di corredo.
- Barra inferiore: Home | Portafoglio | Proventi | Movimenti | Altro.
- Proventi al centro della UX.
- Classificazione automatica del tipo di provento dalla categoria dello strumento.
- Contabilità lordo / tasse / netto più visibile.
- Plusvalenze verdi e minusvalenze rosse nei riepiloghi principali.
- Quotazioni usate solo come supporto al valore del patrimonio/P&L.
- Nessuna funzione stile Investing.com (news, segnali, analisi tecnica, trading).
- applicationId invariato: it.portafoglio2026.v32.
- versionCode 68; versionName 3.4.26-dev.
- DB_VERSION invariato a 10: nessuna cancellazione o migrazione distruttiva dei dati della V3.4.23.

Prima dell'installazione sul telefono principale: eseguire il backup dati dalla V3.4.23.

- Backup dati visibile direttamente in Altro con pulsante “Esporta backup completo”.
