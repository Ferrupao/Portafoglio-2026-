# Portafoglio 2026 V3.4.17 Stable Beta

Versione tecnica **3.4.17** - versionCode **59**.

## Novità V3.4.17
- nuovo pulsante **Importa estratto conto** nella Home e pulsante dedicato nel singolo portafoglio;
- nuovo **Centro importazioni estratti conto** accessibile dal Totale, con cronologia degli ultimi file importati;
- importazione mensile con **anteprima prima della conferma**;
- il nuovo estratto **sostituisce soltanto la situazione corrente del broker selezionato**: non viene mai sommato al patrimonio precedente;
- ogni import salva o aggiorna lo **snapshot del mese** nello storico patrimoniale;
- controllo duplicati tramite impronta **SHA-256**: lo stesso file non può essere importato due volte nello stesso portafoglio;
- gli **ISIN già presenti conservano PMC e commissioni di acquisto** quando l’estratto non li fornisce;
- cedole/dividendi, PAC, movimenti, vendite, costi e gli altri portafogli non vengono cancellati;
- se un file non contiene la liquidità, l’app conserva quella già registrata invece di azzerarla;
- parser automatico per **Situazione Patrimoniale Directa PDF**;
- parser **Trade Republic PDF beta**: importa solo quando le posizioni valorizzate sono riconoscibili con sufficiente coerenza; in caso contrario blocca l’import senza modificare dati;
- supporto a CSV mensili con colonne riconoscibili (ISIN, quantità, prezzo/valore);
- registro degli estratti incluso nel backup completo **V3.4.17**;
- stessa firma permanente e stesso `applicationId`, quindi aggiornamento sopra la V3.4.16 senza disinstallazione.

## Regola contabile dell’import mensile
Esempio: Directa vale 110.000 € e il nuovo estratto indica 112.500 €. Dopo l’import Directa vale **112.500 €**, non 222.500 €. Il Totale complessivo viene ricalcolato automaticamente con gli altri portafogli.

L’import aggiorna la fotografia corrente e conserva uno snapshot mensile. Non genera automaticamente dividendi, imposte o operazioni se tali informazioni non sono presenti e riconoscibili nel file: in caso di dubbio l’app non inventa dati.

## Firma stabile
Il progetto usa la stessa chiave release permanente già configurata nei GitHub Actions Secrets. La chiave privata non deve essere pubblicata.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria o servizi di intermediazione.
