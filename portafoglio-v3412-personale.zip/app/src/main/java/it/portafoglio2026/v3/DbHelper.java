package it.portafoglio2026.v3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "portafoglio2026_v32.db";
    public static final int DB_VERSION = 7;

    public static final String DIRECTA = "Directa";
    public static final String TR = "Trade Republic";

    public DbHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)");
        db.execSQL("CREATE TABLE portfolios ("+
                "name TEXT PRIMARY KEY, active INTEGER NOT NULL DEFAULT 1, pac_default REAL NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0, broker_profile TEXT NOT NULL DEFAULT 'Generico', buy_commission_type TEXT NOT NULL DEFAULT 'FISSA', buy_commission_value REAL NOT NULL DEFAULT 0, sell_commission_type TEXT NOT NULL DEFAULT 'FISSA', sell_commission_value REAL NOT NULL DEFAULT 0, commission_min REAL NOT NULL DEFAULT 0, commission_max REAL NOT NULL DEFAULT 0, fiscal_regime TEXT NOT NULL DEFAULT 'Non specificato')");
        db.execSQL("CREATE TABLE income_records ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, category TEXT, instrument TEXT, isin TEXT, income_type TEXT, gross REAL, tax_rate REAL, net REAL, notes TEXT, amount_mode TEXT NOT NULL DEFAULT 'LORDO')");
        db.execSQL("CREATE TABLE snapshots ("+
                "broker TEXT, month INTEGER, initial_value REAL, final_value REAL, deposits REAL, withdrawals REAL, notes TEXT, "+
                "initial_invested REAL, initial_cash REAL, final_invested REAL, final_cash REAL, PRIMARY KEY(broker,month))");
        db.execSQL("CREATE TABLE pac_records ("+
                "broker TEXT, month INTEGER, planned REAL, external_actual REAL, internal_actual REAL, notes TEXT, PRIMARY KEY(broker,month))");
        db.execSQL("CREATE TABLE annual_history ("+
                "year INTEGER PRIMARY KEY, gross_income REAL, net_income REAL, portfolio_profit REAL, return_rate REAL, notes TEXT)");
        db.execSQL("CREATE TABLE positions ("+
                "broker TEXT, isin TEXT, instrument TEXT, quantity REAL, pmc REAL, price REAL, current_value REAL, source_date TEXT, buy_fee REAL NOT NULL DEFAULT 0, PRIMARY KEY(broker,isin))");
        db.execSQL("CREATE TABLE portfolio_status ("+
                "broker TEXT PRIMARY KEY, invested REAL, cash REAL, total_value REAL, source_date TEXT, source TEXT)");
        db.execSQL("CREATE TABLE movement_records ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, movement_type TEXT, flow_class TEXT, amount REAL, notes TEXT)");
        db.execSQL("CREATE TABLE trade_records ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, trade_type TEXT, isin TEXT, instrument TEXT, quantity REAL, price REAL, gross_amount REAL, cost_basis REAL, buy_fee_allocated REAL, commission REAL, taxes REAL, net_amount REAL, realized_pl_gross REAL, realized_pl_net REAL, notes TEXT)");
        db.execSQL("CREATE TABLE cost_records ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, cost_kind TEXT, cost_type TEXT, amount REAL, instrument TEXT, isin TEXT, notes TEXT)");

        putSetting(db,"tax_rate","0.26");
        putSetting(db,"year","2026");
        insertPortfolio(db,DIRECTA,1131.0,1,1,"Directa");
        insertPortfolio(db,TR,183.0,1,2,"Trade Republic");

        // Dalla V3.4.12 le installazioni nuove partono senza dati patrimoniali/proventi pre-caricati.
        // Restano soltanto i due portafogli personali e i PAC predefiniti; i dati reali arrivano dal backup/import.
    }



    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion < 2){
            db.execSQL("CREATE TABLE IF NOT EXISTS annual_history ("+
                    "year INTEGER PRIMARY KEY, gross_income REAL, net_income REAL, portfolio_profit REAL, return_rate REAL, notes TEXT)");
        }
        if(oldVersion < 3){
            db.execSQL("ALTER TABLE snapshots ADD COLUMN initial_invested REAL");
            db.execSQL("ALTER TABLE snapshots ADD COLUMN initial_cash REAL");
            db.execSQL("ALTER TABLE snapshots ADD COLUMN final_invested REAL");
            db.execSQL("ALTER TABLE snapshots ADD COLUMN final_cash REAL");
        }
        if(oldVersion < 4){
            db.execSQL("CREATE TABLE IF NOT EXISTS positions ("+
                    "broker TEXT, isin TEXT, instrument TEXT, quantity REAL, pmc REAL, price REAL, current_value REAL, source_date TEXT, buy_fee REAL NOT NULL DEFAULT 0, PRIMARY KEY(broker,isin))");
            db.execSQL("CREATE TABLE IF NOT EXISTS portfolio_status ("+
                    "broker TEXT PRIMARY KEY, invested REAL, cash REAL, total_value REAL, source_date TEXT, source TEXT)");
        }
        if(oldVersion < 5){
            try{db.execSQL("ALTER TABLE positions ADD COLUMN pmc REAL");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolio_status ADD COLUMN total_value REAL");}catch(Exception ignored){}
        }
        if(oldVersion < 6){
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN broker_profile TEXT NOT NULL DEFAULT 'Generico'");}catch(Exception ignored){}
            db.execSQL("CREATE TABLE IF NOT EXISTS movement_records (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, movement_type TEXT, flow_class TEXT, amount REAL, notes TEXT)");
            try{db.execSQL("UPDATE portfolios SET broker_profile='Trade Republic' WHERE lower(name) LIKE '%trade%repub%' OR lower(name)='tr'");}catch(Exception ignored){}
            try{db.execSQL("UPDATE portfolios SET broker_profile='Directa' WHERE lower(name) LIKE '%directa%'");}catch(Exception ignored){}
        }
        if(oldVersion < 7){
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN buy_commission_type TEXT NOT NULL DEFAULT 'FISSA'");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN buy_commission_value REAL NOT NULL DEFAULT 0");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN sell_commission_type TEXT NOT NULL DEFAULT 'FISSA'");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN sell_commission_value REAL NOT NULL DEFAULT 0");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN commission_min REAL NOT NULL DEFAULT 0");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN commission_max REAL NOT NULL DEFAULT 0");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE portfolios ADD COLUMN fiscal_regime TEXT NOT NULL DEFAULT 'Non specificato'");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE income_records ADD COLUMN amount_mode TEXT NOT NULL DEFAULT 'LORDO'");}catch(Exception ignored){}
            try{db.execSQL("UPDATE income_records SET amount_mode='NETTO' WHERE tax_rate=0 AND (lower(notes) LIKE '%netto accreditato%' OR lower(notes) LIKE '%già netto%' OR lower(notes) LIKE '%gia netto%')");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE positions ADD COLUMN buy_fee REAL NOT NULL DEFAULT 0");}catch(Exception ignored){}
            db.execSQL("CREATE TABLE IF NOT EXISTS trade_records (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, trade_type TEXT, isin TEXT, instrument TEXT, quantity REAL, price REAL, gross_amount REAL, cost_basis REAL, buy_fee_allocated REAL, commission REAL, taxes REAL, net_amount REAL, realized_pl_gross REAL, realized_pl_net REAL, notes TEXT)");
            db.execSQL("CREATE TABLE IF NOT EXISTS cost_records (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, month INTEGER, broker TEXT, cost_kind TEXT, cost_type TEXT, amount REAL, instrument TEXT, isin TEXT, notes TEXT)");
            try{db.execSQL("INSERT INTO cost_records(date,month,broker,cost_kind,cost_type,amount,instrument,isin,notes) SELECT date,month,broker,CASE WHEN movement_type='Commissione' THEN 'COMMISSIONE' ELSE 'IMPOSTA' END,movement_type,amount,'','',notes FROM movement_records WHERE movement_type IN ('Commissione','Imposta')");}catch(Exception ignored){}
        }
    }

    private void insertPortfolio(SQLiteDatabase db,String name,double pac,int active,int order,String profile){
        ContentValues cv=new ContentValues();cv.put("name",name);cv.put("pac_default",pac);cv.put("active",active);cv.put("sort_order",order);cv.put("broker_profile",profile);
        db.insertWithOnConflict("portfolios",null,cv,SQLiteDatabase.CONFLICT_IGNORE);
    }

    private void insertMonth(SQLiteDatabase db,int month,double stocks,double etf,double etp,double cert){
        String date="2026-"+(month<10?"0":"")+month+"-28";
        if(stocks!=0) insertIncome(db,date,month,DIRECTA,"Azioni","Storico aggregato","","Dividendo",stocks,0.26,"");
        if(etf!=0) insertIncome(db,date,month,DIRECTA,"ETF","Storico aggregato","","Distribuzione ETF",etf,0.26,"");
        if(etp!=0) insertIncome(db,date,month,DIRECTA,"ETP","Storico aggregato","","Distribuzione ETP",etp,0.26,"");
        if(cert!=0) insertIncome(db,date,month,DIRECTA,"Certificati","Storico aggregato","","Cedola",cert,0.26,"");
    }

    private void putSetting(SQLiteDatabase db,String k,String v){
        ContentValues cv=new ContentValues(); cv.put("k",k); cv.put("v",v); db.insert("settings",null,cv);
    }

    private void insertIncome(SQLiteDatabase db,String date,int month,String broker,String category,String instrument,String isin,String type,double gross,double tax,String notes){
        ContentValues cv=new ContentValues();
        cv.put("date",date); cv.put("month",month); cv.put("broker",broker); cv.put("category",category); cv.put("instrument",instrument); cv.put("isin",isin); cv.put("income_type",type);
        cv.put("gross",gross); cv.put("tax_rate",tax); cv.put("net",gross*(1.0-tax)); cv.put("notes",notes);
        db.insert("income_records",null,cv);
    }

    private void insertSnapshot(SQLiteDatabase db,String broker,int month,Double initial,Double fin,Double dep,Double wd,String notes){
        ContentValues cv=new ContentValues(); cv.put("broker",broker); cv.put("month",month);
        putNullable(cv,"initial_value",initial); putNullable(cv,"final_value",fin); putNullable(cv,"deposits",dep); putNullable(cv,"withdrawals",wd); cv.put("notes",notes);
        db.insert("snapshots",null,cv);
    }

    private void insertPac(SQLiteDatabase db,String broker,int month,Double planned,Double ext,Double in,String notes){
        ContentValues cv=new ContentValues(); cv.put("broker",broker); cv.put("month",month); putNullable(cv,"planned",planned); putNullable(cv,"external_actual",ext); putNullable(cv,"internal_actual",in); cv.put("notes",notes);
        db.insert("pac_records",null,cv);
    }

    private void insertAnnualHistory(SQLiteDatabase db,int year,Double gross,Double net,Double profit,Double ret,String notes){
        ContentValues cv=new ContentValues(); cv.put("year",year);
        putNullable(cv,"gross_income",gross); putNullable(cv,"net_income",net); putNullable(cv,"portfolio_profit",profit); putNullable(cv,"return_rate",ret);
        cv.put("notes",notes);
        db.insertWithOnConflict("annual_history",null,cv,SQLiteDatabase.CONFLICT_IGNORE);
    }

    private static void putNullable(ContentValues cv,String key,Double v){ if(v==null) cv.putNull(key); else cv.put(key,v); }
    private static Double sumNullable(Double a,Double b){ if(a==null&&b==null)return null; return (a==null?0:a)+(b==null?0:b); }

    public double getSettingDouble(String key,double def){
        Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{key});
        double out=def; if(c.moveToFirst()) try{out=Double.parseDouble(c.getString(0));}catch(Exception ignored){} c.close(); return out;
    }
    public void setSettingDouble(String key,double val){
        ContentValues cv=new ContentValues(); cv.put("v",String.valueOf(val));
        int n=getWritableDatabase().update("settings",cv,"k=?",new String[]{key});
        if(n==0){cv.put("k",key);getWritableDatabase().insert("settings",null,cv);}
    }
    public String getSetting(String key,String def){
        Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{key});
        String out=def; if(c.moveToFirst() && c.getString(0)!=null) out=c.getString(0); c.close(); return out;
    }
    public void setSetting(String key,String val){
        ContentValues cv=new ContentValues(); cv.put("v",val==null?"":val);
        int n=getWritableDatabase().update("settings",cv,"k=?",new String[]{key});
        if(n==0){cv.put("k",key);getWritableDatabase().insert("settings",null,cv);}
    }
    public double getTaxRate(){return getSettingDouble("tax_rate",0.26);}

    // ---- Gestione portafogli dinamici: nessun limite applicativo fisso ----
    public List<String> portfolioNames(boolean activeOnly){
        List<String> out=new ArrayList<>();
        String sql="SELECT name FROM portfolios"+(activeOnly?" WHERE active=1":"")+" ORDER BY sort_order,name COLLATE NOCASE";
        Cursor c=getReadableDatabase().rawQuery(sql,null);while(c.moveToNext())out.add(c.getString(0));c.close();return out;
    }
    public boolean portfolioExists(String name){
        Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM portfolios WHERE name=? LIMIT 1",new String[]{name});boolean yes=c.moveToFirst();c.close();return yes;
    }
    public boolean ensurePortfolio(String name){
        if(name==null||name.trim().isEmpty())return false;String n=name.trim();if(portfolioExists(n))return true;
        return addPortfolio(n,0.0,inferBrokerProfile(n));
    }
    public static String inferBrokerProfile(String name){
        if(name==null)return "Generico";String n=name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]","");
        if(n.contains("traderepub")||n.equals("tr"))return "Trade Republic";
        if(n.contains("directa"))return "Directa";
        if(n.contains("fineco"))return "Fineco";
        if(n.contains("interactivebrokers")||n.equals("ibkr"))return "Interactive Brokers";
        if(n.contains("degiro"))return "DEGIRO";
        if(n.contains("scalable"))return "Scalable Capital";
        if(n.contains("etoro"))return "eToro";
        return "Generico";
    }
    public boolean addPortfolio(String name,double pacDefault){return addPortfolio(name,pacDefault,inferBrokerProfile(name));}
    public boolean addPortfolio(String name,double pacDefault,String profile){
        if(name==null)return false;String n=name.trim();if(n.isEmpty()||portfolioExists(n)||n.equalsIgnoreCase("Totale")||n.equalsIgnoreCase("HOME"))return false;
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_order),0)+1 FROM portfolios",null);int ord=1;if(c.moveToFirst())ord=c.getInt(0);c.close();
        ContentValues cv=new ContentValues();cv.put("name",n);cv.put("active",1);cv.put("pac_default",pacDefault);cv.put("sort_order",ord);cv.put("broker_profile",profile==null||profile.trim().isEmpty()?inferBrokerProfile(n):profile.trim());
        long id=getWritableDatabase().insert("portfolios",null,cv);
        if(id<0)return false;
        for(int m=1;m<=12;m++)insertPac(getWritableDatabase(),n,m,pacDefault,null,null,"Nuovo portafoglio");
        return true;
    }
    public String getBrokerProfile(String name){
        Cursor c=getReadableDatabase().rawQuery("SELECT broker_profile FROM portfolios WHERE name=?",new String[]{name});String x=inferBrokerProfile(name);if(c.moveToFirst()&&!c.isNull(0)&&!c.getString(0).trim().isEmpty())x=c.getString(0);c.close();return x;
    }
    public void setBrokerProfile(String name,String profile){ContentValues cv=new ContentValues();cv.put("broker_profile",profile==null||profile.trim().isEmpty()?"Generico":profile.trim());getWritableDatabase().update("portfolios",cv,"name=?",new String[]{name});}
    public boolean isTradeRepublicProfile(String name){return "Trade Republic".equalsIgnoreCase(getBrokerProfile(name));}

    public boolean renamePortfolio(String oldName,String newName){
        if(oldName==null||newName==null)return false;String n=newName.trim();if(n.isEmpty()||oldName.equals(n))return false;if(portfolioExists(n)||n.equalsIgnoreCase("Totale")||n.equalsIgnoreCase("HOME"))return false;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            ContentValues cv=new ContentValues();cv.put("name",n);int changed=db.update("portfolios",cv,"name=?",new String[]{oldName});if(changed==0)return false;
            ContentValues b=new ContentValues();b.put("broker",n);db.update("income_records",b,"broker=?",new String[]{oldName});db.update("snapshots",b,"broker=?",new String[]{oldName});db.update("pac_records",b,"broker=?",new String[]{oldName});db.update("positions",b,"broker=?",new String[]{oldName});db.update("portfolio_status",b,"broker=?",new String[]{oldName});db.update("movement_records",b,"broker=?",new String[]{oldName});db.update("trade_records",b,"broker=?",new String[]{oldName});db.update("cost_records",b,"broker=?",new String[]{oldName});
            db.setTransactionSuccessful();return true;
        }finally{db.endTransaction();}
    }
    public void setPortfolioActive(String name,boolean active){ContentValues cv=new ContentValues();cv.put("active",active?1:0);getWritableDatabase().update("portfolios",cv,"name=?",new String[]{name});}
    public boolean isPortfolioActive(String name){Cursor c=getReadableDatabase().rawQuery("SELECT active FROM portfolios WHERE name=?",new String[]{name});boolean x=c.moveToFirst()&&c.getInt(0)==1;c.close();return x;}
    public boolean deletePortfolio(String name){
        if(name==null)return false;SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            db.delete("income_records","broker=?",new String[]{name});db.delete("snapshots","broker=?",new String[]{name});db.delete("pac_records","broker=?",new String[]{name});db.delete("positions","broker=?",new String[]{name});db.delete("portfolio_status","broker=?",new String[]{name});db.delete("movement_records","broker=?",new String[]{name});db.delete("trade_records","broker=?",new String[]{name});db.delete("cost_records","broker=?",new String[]{name});int n=db.delete("portfolios","name=?",new String[]{name});db.setTransactionSuccessful();return n>0;
        }finally{db.endTransaction();}
    }
    public double getPacDefault(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT pac_default FROM portfolios WHERE name=?",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public void setPortfolioPacDefault(String broker,double value){ContentValues cv=new ContentValues();cv.put("pac_default",value);getWritableDatabase().update("portfolios",cv,"name=?",new String[]{broker});}
    public Cursor portfolios(){return getReadableDatabase().rawQuery("SELECT * FROM portfolios ORDER BY sort_order,name COLLATE NOCASE",null);}

    public long addIncome(String date,int month,String broker,String category,String instrument,String isin,String type,double gross,double tax,String notes){return addIncome(date,month,broker,category,instrument,isin,type,gross,tax,notes,"LORDO");}
    public long addIncome(String date,int month,String broker,String category,String instrument,String isin,String type,double amount,double tax,String notes,String amountMode){
        ensurePortfolio(broker);String mode="NETTO".equalsIgnoreCase(amountMode)?"NETTO":"LORDO";double effectiveTax=mode.equals("NETTO")?0:tax;double net=mode.equals("NETTO")?amount:amount*(1-effectiveTax);
        ContentValues cv=new ContentValues(); cv.put("date",date);cv.put("month",month);cv.put("broker",broker);cv.put("category",category);cv.put("instrument",instrument);cv.put("isin",isin);cv.put("income_type",type);cv.put("gross",amount);cv.put("tax_rate",effectiveTax);cv.put("net",net);cv.put("notes",notes);cv.put("amount_mode",mode);
        return getWritableDatabase().insert("income_records",null,cv);
    }
    public void deleteIncome(long id){getWritableDatabase().delete("income_records","id=?",new String[]{String.valueOf(id)});}
    public Cursor incomes(String broker){
        if(broker==null) return getReadableDatabase().rawQuery("SELECT * FROM income_records ORDER BY date DESC,id DESC",null);
        return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE broker=? ORDER BY date DESC,id DESC",new String[]{broker});
    }
    public Cursor incomesForMonth(String broker,int month){
        if(broker==null) return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE month=? ORDER BY date,id",new String[]{String.valueOf(month)});
        return getReadableDatabase().rawQuery("SELECT * FROM income_records WHERE broker=? AND month=? ORDER BY date,id",new String[]{broker,String.valueOf(month)});
    }
    public double sumIncome(String broker,String field){
        String sql=broker==null?"SELECT COALESCE(SUM("+field+"),0) FROM income_records":"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE broker=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double sumIncomeMonth(String broker,int month,String field){
        String sql=broker==null?"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE month=?":"SELECT COALESCE(SUM("+field+"),0) FROM income_records WHERE broker=? AND month=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?new String[]{String.valueOf(month)}:new String[]{broker,String.valueOf(month)}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double sumCategory(String broker,String category){
        String sql=broker==null?"SELECT COALESCE(SUM(gross),0) FROM income_records WHERE category=?":"SELECT COALESCE(SUM(gross),0) FROM income_records WHERE broker=? AND category=?";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?new String[]{category}:new String[]{broker,category}); double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public int monthsWithIncome(String broker){
        String sql=broker==null?"SELECT COUNT(DISTINCT month) FROM income_records WHERE gross<>0":"SELECT COUNT(DISTINCT month) FROM income_records WHERE broker=? AND gross<>0";
        Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker}); int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x;
    }
    public Cursor incomesActive(){return getReadableDatabase().rawQuery("SELECT i.* FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 ORDER BY i.date DESC,i.id DESC",null);}
    public double sumIncomeActive(String field){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(i."+field+"),0) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double sumIncomeMonthActive(int month,String field){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(i."+field+"),0) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 AND i.month=?",new String[]{String.valueOf(month)});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double sumCategoryActive(String category){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(i.gross),0) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 AND i.category=?",new String[]{category});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public int monthsWithIncomeActive(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT i.month) FROM income_records i JOIN portfolios p ON p.name=i.broker WHERE p.active=1 AND i.gross<>0",null);int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x;}

    public void saveSnapshot(String broker,int month,Double initial,Double fin,Double dep,Double wd,String notes){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);putNullable(cv,"initial_value",initial);putNullable(cv,"final_value",fin);putNullable(cv,"deposits",dep);putNullable(cv,"withdrawals",wd);cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("snapshots",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void saveSnapshotSplit(String broker,int month,Double initialInvested,Double initialCash,Double finalInvested,Double finalCash,Double dep,Double wd,String notes){
        ensurePortfolio(broker);Double initial=sumNullable(initialInvested,initialCash),fin=sumNullable(finalInvested,finalCash);
        ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);
        putNullable(cv,"initial_value",initial);putNullable(cv,"final_value",fin);putNullable(cv,"deposits",dep);putNullable(cv,"withdrawals",wd);cv.put("notes",notes);
        putNullable(cv,"initial_invested",initialInvested);putNullable(cv,"initial_cash",initialCash);putNullable(cv,"final_invested",finalInvested);putNullable(cv,"final_cash",finalCash);
        getWritableDatabase().insertWithOnConflict("snapshots",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor snapshot(String broker,int month){return getReadableDatabase().rawQuery("SELECT * FROM snapshots WHERE broker=? AND month=?",new String[]{broker,String.valueOf(month)});}
    public Cursor snapshots(String broker){return getReadableDatabase().rawQuery("SELECT * FROM snapshots WHERE broker=? ORDER BY month",new String[]{broker});}
    private Double statusField(String broker,String field){
        Cursor c=getReadableDatabase().rawQuery("SELECT "+field+" FROM portfolio_status WHERE broker=? LIMIT 1",new String[]{broker});
        Double x=null;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();return x;
    }
    private boolean hasPortfolioStatus(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM portfolio_status WHERE broker=? LIMIT 1",new String[]{broker});boolean ok=c.moveToFirst();c.close();return ok;}
    public double latestPortfolioValue(String broker){
        int pc=positionCount(broker);double posVal=pc>0?sumPositionsCurrentValue(broker):0;Double total=statusField(broker,"total_value");
        if(total!=null&&(Math.abs(total)>0.000001||pc==0))return total;
        Double inv=statusField(broker,"invested"),cash=statusField(broker,"cash");
        if(inv!=null||cash!=null){double invested=inv!=null?inv:posVal;return invested+(cash==null?0:cash);}
        Cursor c=getReadableDatabase().rawQuery("SELECT final_value FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});Double x=null;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();
        if(x!=null&&(Math.abs(x)>0.000001||pc==0))return x;
        if(pc>0)return posVal;
        return 0;
    }
    public Double latestInvestedValue(String broker){
        if(hasPortfolioStatus(broker)){Double v=statusField(broker,"invested");if(v!=null)return v;}
        Cursor c=getReadableDatabase().rawQuery("SELECT final_invested FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});Double x=null;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();
        if(x==null&&positionCount(broker)>0)x=sumPositionsCurrentValue(broker);
        return x;
    }
    public Double latestCashValue(String broker){
        if(hasPortfolioStatus(broker))return statusField(broker,"cash");
        Cursor c=getReadableDatabase().rawQuery("SELECT final_cash FROM snapshots WHERE broker=? AND final_value IS NOT NULL ORDER BY month DESC LIMIT 1",new String[]{broker});Double x=null;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();return x;
    }
    public Double latestInvestedValueAllActive(){double x=0;boolean any=false;for(String b:portfolioNames(true)){Double v=latestInvestedValue(b);if(v!=null){x+=v;any=true;}}return any?x:null;}
    public Double latestCashValueAllActive(){double x=0;boolean any=false;for(String b:portfolioNames(true)){Double v=latestCashValue(b);if(v!=null){x+=v;any=true;}}return any?x:null;}
    public double latestPortfolioValueAllActive(){double x=0;for(String b:portfolioNames(true))x+=latestPortfolioValue(b);return x;}
    public boolean isPortfolioFullySeparated(String broker){return latestInvestedValue(broker)!=null&&latestCashValue(broker)!=null;}
    public int separatedPortfolioCountActive(){int n=0;for(String b:portfolioNames(true))if(isPortfolioFullySeparated(b))n++;return n;}
    public int unseparatedPortfolioCountActive(){int n=0;for(String b:portfolioNames(true))if(!isPortfolioFullySeparated(b)&&latestPortfolioValue(b)!=0)n++;return n;}
    public Double knownInvestedValueAllActive(){double x=0;boolean any=false;for(String b:portfolioNames(true))if(isPortfolioFullySeparated(b)){Double v=latestInvestedValue(b);if(v!=null){x+=v;any=true;}}return any?x:null;}
    public Double knownCashValueAllActive(){double x=0;boolean any=false;for(String b:portfolioNames(true))if(isPortfolioFullySeparated(b)){Double v=latestCashValue(b);if(v!=null){x+=v;any=true;}}return any?x:null;}
    public double unseparatedPortfolioValueAllActive(){double x=0;for(String b:portfolioNames(true))if(!isPortfolioFullySeparated(b))x+=latestPortfolioValue(b);return x;}

    // ---- Registro movimenti generico e profili broker ----
    public long addMovement(String date,int month,String broker,String type,String flowClass,double amount,String notes){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("date",date);cv.put("month",month);cv.put("broker",broker);cv.put("movement_type",type);cv.put("flow_class",flowClass);cv.put("amount",amount);cv.put("notes",notes);return getWritableDatabase().insert("movement_records",null,cv);
    }
    public void deleteMovement(long id){getWritableDatabase().delete("movement_records","id=?",new String[]{String.valueOf(id)});}
    public Cursor movements(String broker){
        if(broker==null)return getReadableDatabase().rawQuery("SELECT m.* FROM movement_records m JOIN portfolios p ON p.name=m.broker WHERE p.active=1 ORDER BY m.date DESC,m.id DESC",null);
        return getReadableDatabase().rawQuery("SELECT * FROM movement_records WHERE broker=? ORDER BY date DESC,id DESC",new String[]{broker});
    }
    public Cursor allMovements(){return getReadableDatabase().rawQuery("SELECT * FROM movement_records ORDER BY broker,date DESC,id DESC",null);}
    public double sumMovements(String broker,String flowClass){
        String sql=broker==null?"SELECT COALESCE(SUM(m.amount),0) FROM movement_records m JOIN portfolios p ON p.name=m.broker WHERE p.active=1 AND m.flow_class=?":"SELECT COALESCE(SUM(amount),0) FROM movement_records WHERE broker=? AND flow_class=?";
        String[] args=broker==null?new String[]{flowClass}:new String[]{broker,flowClass};Cursor c=getReadableDatabase().rawQuery(sql,args);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }

    public static class Position {
        public String isin,instrument,sourceDate; public double quantity,price,currentValue,buyFee; public Double pmc;
        public Position(String isin,String instrument,double quantity,double price,double currentValue,String sourceDate){this(isin,instrument,quantity,null,price,currentValue,sourceDate,0);}
        public Position(String isin,String instrument,double quantity,Double pmc,double price,double currentValue,String sourceDate){this(isin,instrument,quantity,pmc,price,currentValue,sourceDate,0);}
        public Position(String isin,String instrument,double quantity,Double pmc,double price,double currentValue,String sourceDate,double buyFee){this.isin=isin;this.instrument=instrument;this.quantity=quantity;this.pmc=pmc;this.price=price;this.currentValue=currentValue;this.sourceDate=sourceDate;this.buyFee=buyFee;}
    }
    public void savePosition(String broker,Position p){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("isin",p.isin);cv.put("instrument",p.instrument);cv.put("quantity",p.quantity);putNullable(cv,"pmc",p.pmc);cv.put("price",p.price);cv.put("current_value",p.currentValue);cv.put("source_date",p.sourceDate);cv.put("buy_fee",p.buyFee);
        getWritableDatabase().insertWithOnConflict("positions",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public String portfolioString(String broker,String col,String def){Cursor c=getReadableDatabase().rawQuery("SELECT "+col+" FROM portfolios WHERE name=?",new String[]{broker});String x=def;if(c.moveToFirst()&&!c.isNull(0))x=c.getString(0);c.close();return x;}
    public double portfolioDouble(String broker,String col,double def){Cursor c=getReadableDatabase().rawQuery("SELECT "+col+" FROM portfolios WHERE name=?",new String[]{broker});double x=def;if(c.moveToFirst()&&!c.isNull(0))x=c.getDouble(0);c.close();return x;}
    public void saveBrokerFinancialSettings(String broker,String buyType,double buyValue,String sellType,double sellValue,double min,double max,String fiscalRegime){
        ContentValues cv=new ContentValues();cv.put("buy_commission_type",buyType);cv.put("buy_commission_value",buyValue);cv.put("sell_commission_type",sellType);cv.put("sell_commission_value",sellValue);cv.put("commission_min",min);cv.put("commission_max",max);cv.put("fiscal_regime",fiscalRegime);getWritableDatabase().update("portfolios",cv,"name=?",new String[]{broker});
    }
    public double defaultCommission(String broker,boolean sale,double gross){String type=portfolioString(broker,sale?"sell_commission_type":"buy_commission_type","FISSA");double value=portfolioDouble(broker,sale?"sell_commission_value":"buy_commission_value",0);double fee="PERCENTUALE".equalsIgnoreCase(type)?gross*value/100.0:value;double min=portfolioDouble(broker,"commission_min",0),max=portfolioDouble(broker,"commission_max",0);if(min>0)fee=Math.max(fee,min);if(max>0)fee=Math.min(fee,max);return Math.max(0,fee);}
    public String fiscalRegime(String broker){return portfolioString(broker,"fiscal_regime","Non specificato");}

    public long addCost(String date,int month,String broker,String kind,String type,double amount,String instrument,String isin,String notes){ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("date",date);cv.put("month",month);cv.put("broker",broker);cv.put("cost_kind",kind);cv.put("cost_type",type);cv.put("amount",amount);cv.put("instrument",instrument);cv.put("isin",isin);cv.put("notes",notes);return getWritableDatabase().insert("cost_records",null,cv);}
    public Cursor costs(String broker){if(broker==null)return getReadableDatabase().rawQuery("SELECT c.* FROM cost_records c JOIN portfolios p ON p.name=c.broker WHERE p.active=1 ORDER BY c.date DESC,c.id DESC",null);return getReadableDatabase().rawQuery("SELECT * FROM cost_records WHERE broker=? ORDER BY date DESC,id DESC",new String[]{broker});}
    public Cursor allCosts(){return getReadableDatabase().rawQuery("SELECT * FROM cost_records ORDER BY broker,date DESC,id DESC",null);}
    public void deleteCost(long id){getWritableDatabase().delete("cost_records","id=?",new String[]{String.valueOf(id)});}
    public double sumCosts(String broker,String kind){String sql=broker==null?"SELECT COALESCE(SUM(c.amount),0) FROM cost_records c JOIN portfolios p ON p.name=c.broker WHERE p.active=1 AND c.cost_kind=?":"SELECT COALESCE(SUM(amount),0) FROM cost_records WHERE broker=? AND cost_kind=?";String[] args=broker==null?new String[]{kind}:new String[]{broker,kind};Cursor c=getReadableDatabase().rawQuery(sql,args);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double sumTaxType(String broker,String type){String sql=broker==null?"SELECT COALESCE(SUM(c.amount),0) FROM cost_records c JOIN portfolios p ON p.name=c.broker WHERE p.active=1 AND c.cost_kind='IMPOSTA' AND c.cost_type=?":"SELECT COALESCE(SUM(amount),0) FROM cost_records WHERE broker=? AND cost_kind='IMPOSTA' AND cost_type=?";String[] args=broker==null?new String[]{type}:new String[]{broker,type};Cursor c=getReadableDatabase().rawQuery(sql,args);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}

    public static class SaleResult {public double gross,net,plGross,plNet,commission,taxes;public boolean closed;}
    public SaleResult sellPosition(String broker,String isin,double quantity,double sellPrice,double sellCommission,double taxCapitalGain,double tobinTax,double otherTax,String date,String notes){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            Cursor c=db.rawQuery("SELECT * FROM positions WHERE broker=? AND isin=?",new String[]{broker,isin});if(!c.moveToFirst()){c.close();throw new IllegalArgumentException("Posizione non trovata");}
            double qBefore=c.getDouble(c.getColumnIndexOrThrow("quantity"));Double pmc=c.isNull(c.getColumnIndexOrThrow("pmc"))?null:c.getDouble(c.getColumnIndexOrThrow("pmc"));double currentPrice=c.getDouble(c.getColumnIndexOrThrow("price"));String instrument=c.getString(c.getColumnIndexOrThrow("instrument"));double buyFee=c.getColumnIndex("buy_fee")>=0&&!c.isNull(c.getColumnIndex("buy_fee"))?c.getDouble(c.getColumnIndex("buy_fee")):0;c.close();
            if(quantity<=0||quantity-qBefore>0.0000001)throw new IllegalArgumentException("Quantità di vendita non valida");if(pmc==null)throw new IllegalArgumentException("Inserisci il PMC prima di vendere");
            int month=1;try{month=Integer.parseInt(date.substring(5,7));}catch(Exception ignored){}
            double gross=quantity*sellPrice,costBasis=quantity*pmc,ratio=quantity/qBefore,buyFeeAllocated=buyFee*ratio,taxes=Math.max(0,taxCapitalGain)+Math.max(0,tobinTax)+Math.max(0,otherTax),net=gross-Math.max(0,sellCommission)-taxes,plGross=gross-costBasis,plNet=plGross-buyFeeAllocated-Math.max(0,sellCommission)-taxes;
            ContentValues tr=new ContentValues();tr.put("date",date);tr.put("month",month);tr.put("broker",broker);tr.put("trade_type","SELL");tr.put("isin",isin);tr.put("instrument",instrument);tr.put("quantity",quantity);tr.put("price",sellPrice);tr.put("gross_amount",gross);tr.put("cost_basis",costBasis);tr.put("buy_fee_allocated",buyFeeAllocated);tr.put("commission",Math.max(0,sellCommission));tr.put("taxes",taxes);tr.put("net_amount",net);tr.put("realized_pl_gross",plGross);tr.put("realized_pl_net",plNet);tr.put("notes",notes);db.insert("trade_records",null,tr);
            if(sellCommission>0)addCostTx(db,date,month,broker,"COMMISSIONE","Vendita",sellCommission,instrument,isin,"Vendita posizione");if(taxCapitalGain>0)addCostTx(db,date,month,broker,"IMPOSTA","Plusvalenza",taxCapitalGain,instrument,isin,"Vendita posizione");if(tobinTax>0)addCostTx(db,date,month,broker,"IMPOSTA","Tobin Tax",tobinTax,instrument,isin,"Vendita posizione");if(otherTax>0)addCostTx(db,date,month,broker,"IMPOSTA","Altre imposte",otherTax,instrument,isin,"Vendita posizione");
            double qRemain=qBefore-quantity;boolean closed=qRemain<0.0000001;if(closed)db.delete("positions","broker=? AND isin=?",new String[]{broker,isin});else{ContentValues pv=new ContentValues();pv.put("quantity",qRemain);pv.put("current_value",qRemain*currentPrice);pv.put("buy_fee",Math.max(0,buyFee-buyFeeAllocated));pv.put("source_date",date);db.update("positions",pv,"broker=? AND isin=?",new String[]{broker,isin});}
            Double cash=statusField(broker,"cash");double invested=sumPositionsCurrentValueDb(db,broker);Double total=statusField(broker,"total_value");ContentValues st=new ContentValues();st.put("broker",broker);st.put("invested",invested);if(cash!=null){double newCash=cash+net;st.put("cash",newCash);st.put("total_value",invested+newCash);}else if(total!=null){double markedValueSold=quantity*currentPrice;double delta=gross-markedValueSold-Math.max(0,sellCommission)-taxes;st.put("total_value",total+delta);}st.put("source_date",date);st.put("source","Vendita posizione");db.insertWithOnConflict("portfolio_status",null,st,SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();SaleResult r=new SaleResult();r.gross=gross;r.net=net;r.plGross=plGross;r.plNet=plNet;r.commission=sellCommission;r.taxes=taxes;r.closed=closed;return r;
        }finally{db.endTransaction();}
    }
    private void addCostTx(SQLiteDatabase db,String date,int month,String broker,String kind,String type,double amount,String instrument,String isin,String notes){ContentValues cv=new ContentValues();cv.put("date",date);cv.put("month",month);cv.put("broker",broker);cv.put("cost_kind",kind);cv.put("cost_type",type);cv.put("amount",amount);cv.put("instrument",instrument);cv.put("isin",isin);cv.put("notes",notes);db.insert("cost_records",null,cv);}
    private double sumPositionsCurrentValueDb(SQLiteDatabase db,String broker){Cursor c=db.rawQuery("SELECT COALESCE(SUM(current_value),0) FROM positions WHERE broker=?",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public Cursor sales(String broker){if(broker==null)return getReadableDatabase().rawQuery("SELECT t.* FROM trade_records t JOIN portfolios p ON p.name=t.broker WHERE p.active=1 AND t.trade_type='SELL' ORDER BY t.date DESC,t.id DESC",null);return getReadableDatabase().rawQuery("SELECT * FROM trade_records WHERE broker=? AND trade_type='SELL' ORDER BY date DESC,id DESC",new String[]{broker});}
    public long addTradeRecord(String date,int month,String broker,String tradeType,String isin,String instrument,double quantity,double price,double gross,double costBasis,double buyFeeAllocated,double commission,double taxes,double netAmount,double plGross,double plNet,String notes){ensurePortfolio(broker);ContentValues tr=new ContentValues();tr.put("date",date);tr.put("month",month);tr.put("broker",broker);tr.put("trade_type",tradeType);tr.put("isin",isin);tr.put("instrument",instrument);tr.put("quantity",quantity);tr.put("price",price);tr.put("gross_amount",gross);tr.put("cost_basis",costBasis);tr.put("buy_fee_allocated",buyFeeAllocated);tr.put("commission",commission);tr.put("taxes",taxes);tr.put("net_amount",netAmount);tr.put("realized_pl_gross",plGross);tr.put("realized_pl_net",plNet);tr.put("notes",notes);return getWritableDatabase().insert("trade_records",null,tr);}
    public Cursor allTrades(){return getReadableDatabase().rawQuery("SELECT * FROM trade_records ORDER BY broker,date DESC,id DESC",null);}
    public double sumRealized(String broker,String field){String sql=broker==null?"SELECT COALESCE(SUM(t."+field+"),0) FROM trade_records t JOIN portfolios p ON p.name=t.broker WHERE p.active=1 AND t.trade_type='SELL'":"SELECT COALESCE(SUM("+field+"),0) FROM trade_records WHERE broker=? AND trade_type='SELL'";Cursor c=getReadableDatabase().rawQuery(sql,broker==null?null:new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}

    public void savePortfolioStatus(String broker,Double invested,Double cash,String sourceDate,String source){
        Double total=(invested==null&&cash==null)?null:(invested==null?0:invested)+(cash==null?0:cash);
        savePortfolioStatus(broker,invested,cash,total,sourceDate,source);
    }
    public void savePortfolioStatus(String broker,Double invested,Double cash,Double total,String sourceDate,String source){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("broker",broker);putNullable(cv,"invested",invested);putNullable(cv,"cash",cash);putNullable(cv,"total_value",total);cv.put("source_date",sourceDate);cv.put("source",source);
        getWritableDatabase().insertWithOnConflict("portfolio_status",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void savePortfolioTotalOnly(String broker,Double total,String sourceDate,String source){
        savePortfolioStatus(broker,null,null,total,sourceDate,source);
    }
    public void replacePositionsAndStatus(String broker,List<Position> rows,Double invested,Double cash,String sourceDate,String source){
        ensurePortfolio(broker);SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            db.delete("positions","broker=?",new String[]{broker});
            for(Position p:rows){ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("isin",p.isin);cv.put("instrument",p.instrument);cv.put("quantity",p.quantity);putNullable(cv,"pmc",p.pmc);cv.put("price",p.price);cv.put("current_value",p.currentValue);cv.put("source_date",p.sourceDate);cv.put("buy_fee",p.buyFee);db.insertWithOnConflict("positions",null,cv,SQLiteDatabase.CONFLICT_REPLACE);}
            ContentValues st=new ContentValues();st.put("broker",broker);putNullable(st,"invested",invested);putNullable(st,"cash",cash);Double total=(invested==null&&cash==null)?null:(invested==null?0:invested)+(cash==null?0:cash);putNullable(st,"total_value",total);st.put("source_date",sourceDate);st.put("source",source);db.insertWithOnConflict("portfolio_status",null,st,SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public Cursor positions(String broker){return getReadableDatabase().rawQuery("SELECT * FROM positions WHERE broker=? ORDER BY current_value DESC,instrument COLLATE NOCASE",new String[]{broker});}
    public Cursor position(String broker,String isin){return getReadableDatabase().rawQuery("SELECT * FROM positions WHERE broker=? AND isin=? LIMIT 1",new String[]{broker,isin});}
    public double sumIncomeForInstrument(String broker,String isin){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(gross),0) FROM income_records WHERE broker=? AND upper(COALESCE(isin,''))=upper(?)",new String[]{broker,isin==null?"":isin});
        double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public Cursor salesForIsin(String broker,String isin){
        return getReadableDatabase().rawQuery("SELECT * FROM trade_records WHERE broker=? AND isin=? AND trade_type='SELL' ORDER BY date DESC,id DESC",new String[]{broker,isin});
    }
    public Cursor closedSales(String broker){
        if(broker==null){
            return getReadableDatabase().rawQuery(
                "SELECT t.* FROM trade_records t JOIN portfolios pf ON pf.name=t.broker "+
                "WHERE pf.active=1 AND t.trade_type='SELL' "+
                "AND NOT EXISTS(SELECT 1 FROM positions p WHERE p.broker=t.broker AND p.isin=t.isin) "+
                "AND t.id=(SELECT MAX(t2.id) FROM trade_records t2 WHERE t2.broker=t.broker AND t2.isin=t.isin AND t2.trade_type='SELL') "+
                "ORDER BY t.date DESC,t.id DESC",null);
        }
        return getReadableDatabase().rawQuery(
            "SELECT t.* FROM trade_records t WHERE t.broker=? AND t.trade_type='SELL' "+
            "AND NOT EXISTS(SELECT 1 FROM positions p WHERE p.broker=t.broker AND p.isin=t.isin) "+
            "AND t.id=(SELECT MAX(t2.id) FROM trade_records t2 WHERE t2.broker=t.broker AND t2.isin=t.isin AND t2.trade_type='SELL') "+
            "ORDER BY t.date DESC,t.id DESC",new String[]{broker});
    }
    public Cursor allPositions(){return getReadableDatabase().rawQuery("SELECT * FROM positions ORDER BY broker,instrument COLLATE NOCASE",null);}
    public int positionCount(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM positions WHERE broker=?",new String[]{broker});int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;}
    public double sumPositionsCurrentValue(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(current_value),0) FROM positions WHERE broker=?",new String[]{broker});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public Double sumPositionsCostBasis(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT SUM(quantity*pmc), COUNT(*), SUM(CASE WHEN pmc IS NOT NULL THEN 1 ELSE 0 END) FROM positions WHERE broker=?",new String[]{broker});Double x=null;if(c.moveToFirst()&&c.getInt(1)>0&&c.getInt(1)==c.getInt(2)&&!c.isNull(0))x=c.getDouble(0);c.close();return x;}
    public void deletePosition(String broker,String isin){getWritableDatabase().delete("positions","broker=? AND isin=?",new String[]{broker,isin});}
    public void syncInvestedFromPositions(String broker,String sourceDate){
        double invested=sumPositionsCurrentValue(broker);
        Double cash=statusField(broker,"cash");
        Double oldTotal=statusField(broker,"total_value");
        if(oldTotal==null){double v=latestPortfolioValue(broker);if(v>0)oldTotal=v;}
        Double total=cash!=null?invested+cash:(oldTotal!=null?Math.max(oldTotal,invested):invested);
        savePortfolioStatus(broker,invested,cash,total,sourceDate,"Posizioni manuali");
    }
    public String statusDate(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT source_date FROM portfolio_status WHERE broker=?",new String[]{broker});String s="";if(c.moveToFirst()&&!c.isNull(0))s=c.getString(0);c.close();return s;}
    public String statusSource(String broker){Cursor c=getReadableDatabase().rawQuery("SELECT source FROM portfolio_status WHERE broker=?",new String[]{broker});String s="";if(c.moveToFirst()&&!c.isNull(0))s=c.getString(0);c.close();return s;}
    public Cursor portfolioStatuses(){return getReadableDatabase().rawQuery("SELECT * FROM portfolio_status ORDER BY broker",null);}

    public void savePac(String broker,int month,Double planned,Double ext,Double in,String notes){
        ensurePortfolio(broker);ContentValues cv=new ContentValues();cv.put("broker",broker);cv.put("month",month);putNullable(cv,"planned",planned);putNullable(cv,"external_actual",ext);putNullable(cv,"internal_actual",in);cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("pac_records",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor pac(String broker,int month){return getReadableDatabase().rawQuery("SELECT * FROM pac_records WHERE broker=? AND month=?",new String[]{broker,String.valueOf(month)});}
    public Cursor pacs(String broker){return getReadableDatabase().rawQuery("SELECT * FROM pac_records WHERE broker=? ORDER BY month",new String[]{broker});}

    public void saveAnnualHistory(int year,Double gross,Double net,Double profit,Double ret,String notes){
        ContentValues cv=new ContentValues(); cv.put("year",year);
        putNullable(cv,"gross_income",gross); putNullable(cv,"net_income",net); putNullable(cv,"portfolio_profit",profit); putNullable(cv,"return_rate",ret);
        cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("annual_history",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor annualHistory(){return getReadableDatabase().rawQuery("SELECT * FROM annual_history ORDER BY year DESC",null);}
    public Cursor annualHistoryYear(int year){return getReadableDatabase().rawQuery("SELECT * FROM annual_history WHERE year=?",new String[]{String.valueOf(year)});}
    public void deleteAnnualHistory(int year){getWritableDatabase().delete("annual_history","year=?",new String[]{String.valueOf(year)});}
public void clearTablesOnly(){SQLiteDatabase db=getWritableDatabase(); db.delete("income_records",null,null); db.delete("snapshots",null,null); db.delete("pac_records",null,null); db.delete("annual_history",null,null); db.delete("positions",null,null); db.delete("portfolio_status",null,null); db.delete("movement_records",null,null); db.delete("trade_records",null,null); db.delete("cost_records",null,null);}

    public void clearAllUserData(){
        SQLiteDatabase db=getWritableDatabase(); db.delete("income_records",null,null); db.delete("snapshots",null,null); db.delete("pac_records",null,null); db.delete("annual_history",null,null); db.delete("positions",null,null); db.delete("portfolio_status",null,null); db.delete("movement_records",null,null); db.delete("trade_records",null,null); db.delete("cost_records",null,null);
        for(String b:portfolioNames(false))for(int m=1;m<=12;m++)insertPac(db,b,m,getPacDefault(b),null,null,"");
    }
}
