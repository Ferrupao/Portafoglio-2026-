# Portafoglio 2026 V3.4 Personale

Versione tecnica 3.4.0 - versionCode 42.

## Novità V3.4
- importazione PDF “Situazione Patrimoniale” Directa;
- anteprima obbligatoria prima dell’importazione;
- riconoscimento automatico di data, ISIN, strumento, quantità, prezzo, controvalore, totale titoli e liquidità;
- archivio locale delle posizioni importate, consultabile dalla Dashboard;
- Dashboard aggiornata dal PDF senza alterare cedole, PAC, rendimento mensile o storico annuale;
- capitale investito, liquidità e patrimonio totale restano separati;
- backup CSV V3.4 include anche posizioni e stato patrimoniale;
- compatibilità con backup precedenti V2/V3/V3.1/V3.2/V3.3.

La versione personale mantiene applicationId `it.portafoglio2026.v32`.

Il parser V3.4 fase 1 è stato progettato sul formato reale Directa “Situazione Patrimoniale” fornito come file di test.
