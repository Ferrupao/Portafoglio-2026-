# Portafoglio 2026 V3.4.16 Stable Beta

Versione tecnica **3.4.16** - versionCode **58**.

## Novità V3.4.16
- correzione del riepilogo **PAC Totale**: mostra il PAC del mese corrente, non la somma dei mesi storici;
- con i dati attuali di settembre il riepilogo usa **Directa 1.131 € + Trade Republic 183 € = 1.314 € al mese**;
- il capitale esterno resta separato e viene mostrato come totale registrato da inizio anno;
- la **Copertura netta mensile del PAC** non usa più dati netti incompleti;
- i proventi Directa registrati come **cumulativi/aggregati** non vengono attribuiti artificialmente a un singolo mese;
- i mesi non determinabili restano vuoti nel grafico invece di mostrare percentuali fuorvianti;
- i mesi futuri non vengono mostrati come 0%;
- nel singolo portafoglio il pulsante **Usa copertura suggerita** viene disattivato quando il netto mensile è incompleto o coperto da dati cumulativi;
- l'import patrimoniale chiarisce che un nuovo estratto conto **sostituisce la situazione corrente del solo broker**: non viene sommato al vecchio totale;
- gli altri portafogli, cedole, PAC, movimenti, rendimenti e storico non vengono cancellati dall'import patrimoniale;
- backup CSV **V3.4.16**, compatibile con i backup precedenti;
- stessa firma permanente e stesso `applicationId`, quindi aggiornamento sopra la V3.4.15 senza disinstallazione.

## Import estratti conto
L'import patrimoniale disponibile aggiorna la situazione corrente del portafoglio selezionato. Esempio: se Directa era 110.000 € e il nuovo estratto indica 112.500 €, dopo l'import Directa diventa 112.500 € e il Totale complessivo si ricalcola; **non** diventa 222.500 €.

La versione attuale non trasforma automaticamente ogni estratto importato in uno snapshot mensile storico: questa può essere aggiunta come funzione dedicata, mantenendo separati situazione corrente e storico mensile.

## Firma stabile
Il progetto usa la stessa chiave release permanente già configurata nei GitHub Actions Secrets. La chiave privata non deve essere pubblicata.

Portafoglio 2026 è uno strumento di registrazione e analisi dei dati finanziari. Non fornisce consulenza finanziaria o servizi di intermediazione.
