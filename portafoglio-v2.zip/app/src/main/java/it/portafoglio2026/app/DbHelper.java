package it.portafoglio2026.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "portafoglio2026.db";
    public static final int DB_VERSION = 1;

    public DbHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)");
        db.execSQL("CREATE TABLE coupons (" +
                "month INTEGER PRIMARY KEY, stocks REAL, etf REAL, etp REAL, cert REAL, declared REAL)");
        db.execSQL("CREATE TABLE returns (" +
                "month INTEGER PRIMARY KEY, initial_value REAL, final_value REAL, deposits REAL, withdrawals REAL, notes TEXT)");
        db.execSQL("CREATE TABLE income_shares (" +
                "name TEXT PRIMARY KEY, invested REAL, qty REAL, pmc REAL, dividends REAL, note TEXT)");

        putSetting(db, "tax_rate", "0.26");
        putSetting(db, "year", "2026");

        // Dati storici dal file Excel/PDF al 31/08/2026
        insertCoupon(db,1,29.21,37.09,272.03,897.96,1236.39);
        insertCoupon(db,2,0,72.14,943.11,1219.31,2234.56);
        insertCoupon(db,3,36.08,63.20,455.87,616.03,1172.18);
        insertCoupon(db,4,91.80,123.74,398.41,616.03,1229.98);
        insertCoupon(db,5,70.80,226.12,520.20,616.03,1433.15);
        insertCoupon(db,6,542.76,352.93,727.15,616.03,2238.87);
        insertCoupon(db,7,269.45,89.06,572.04,584.78,1515.33);
        insertCoupon(db,8,0,28.16,571.40,435.55,1063.27);
        for(int m=9;m<=12;m++) insertCoupon(db,m,0,0,0,0,0);

        insertIncome(db,"Coinbase",1342.14,200,6.7107,644.17,"Storico PDF");
        insertIncome(db,"Nvidia",749.47,100,7.4947,39.91,"Potrebbe non essere più in portafoglio");
        insertIncome(db,"Tesla",1535.40,200,7.6770,908.67,"Storico PDF");
        insertIncome(db,"Nasdaq 100",1249.61,200,6.2481,808.73,"Storico PDF");
        insertIncome(db,"S&P 500",1179.00,200,5.8950,545.90,"Storico PDF");
        insertIncome(db,"Gold",3766.30,300,12.5543,364.81,"Storico PDF");
        insertIncome(db,"Silver",2225.18,35,63.5766,870.74,"Storico PDF");
        insertIncome(db,"Palantir",2801.10,90,31.1231,1034.44,"Storico PDF");
        insertIncome(db,"Alibaba",967.00,30,32.2343,303.49,"Storico PDF");
        insertIncome(db,"AMD",4139.62,109,37.9792,1888.23,"Storico PDF");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    private void putSetting(SQLiteDatabase db, String k, String v) {
        ContentValues cv=new ContentValues(); cv.put("k",k); cv.put("v",v);
        db.insert("settings",null,cv);
    }

    private void insertCoupon(SQLiteDatabase db,int month,double s,double e,double p,double c,double d){
        ContentValues cv=new ContentValues();
        cv.put("month",month); cv.put("stocks",s); cv.put("etf",e); cv.put("etp",p); cv.put("cert",c); cv.put("declared",d);
        db.insert("coupons",null,cv);
    }

    private void insertIncome(SQLiteDatabase db,String name,double invested,double qty,double pmc,double div,String note){
        ContentValues cv=new ContentValues();
        cv.put("name",name); cv.put("invested",invested); cv.put("qty",qty); cv.put("pmc",pmc); cv.put("dividends",div); cv.put("note",note);
        db.insert("income_shares",null,cv);
    }

    public double getTaxRate(){
        SQLiteDatabase db=getReadableDatabase();
        Cursor c=db.rawQuery("SELECT v FROM settings WHERE k='tax_rate'",null);
        double v=0.26; if(c.moveToFirst()) try { v=Double.parseDouble(c.getString(0)); } catch(Exception ignored){}
        c.close(); return v;
    }

    public void setTaxRate(double r){
        ContentValues cv=new ContentValues(); cv.put("v",String.valueOf(r));
        getWritableDatabase().update("settings",cv,"k='tax_rate'",null);
    }

    public Cursor coupons(){ return getReadableDatabase().rawQuery("SELECT * FROM coupons ORDER BY month",null); }
    public Cursor returns(){ return getReadableDatabase().rawQuery("SELECT * FROM returns ORDER BY month",null); }
    public Cursor income(){ return getReadableDatabase().rawQuery("SELECT * FROM income_shares ORDER BY name",null); }

    public void saveCoupon(int month,double stocks,double etf,double etp,double cert, Double declared){
        ContentValues cv=new ContentValues();
        cv.put("stocks",stocks); cv.put("etf",etf); cv.put("etp",etp); cv.put("cert",cert);
        if(declared==null) cv.putNull("declared"); else cv.put("declared",declared);
        getWritableDatabase().update("coupons",cv,"month=?",new String[]{String.valueOf(month)});
    }

    public void saveReturn(int month, Double initialValue, Double finalValue, Double deposits, Double withdrawals, String notes){
        ContentValues cv=new ContentValues();
        cv.put("month",month);
        if(initialValue==null) cv.putNull("initial_value"); else cv.put("initial_value",initialValue);
        if(finalValue==null) cv.putNull("final_value"); else cv.put("final_value",finalValue);
        if(deposits==null) cv.putNull("deposits"); else cv.put("deposits",deposits);
        if(withdrawals==null) cv.putNull("withdrawals"); else cv.put("withdrawals",withdrawals);
        cv.put("notes",notes);
        getWritableDatabase().insertWithOnConflict("returns",null,cv,SQLiteDatabase.CONFLICT_REPLACE);
    }

    public Cursor returnForMonth(int month){
        return getReadableDatabase().rawQuery("SELECT * FROM returns WHERE month=?",new String[]{String.valueOf(month)});
    }

    public Cursor couponForMonth(int month){
        return getReadableDatabase().rawQuery("SELECT * FROM coupons WHERE month=?",new String[]{String.valueOf(month)});
    }
}
