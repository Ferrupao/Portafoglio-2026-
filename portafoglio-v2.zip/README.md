# Portafoglio 2026 — Android v2

Versione 2 con navigazione ottimizzata per smartphone Android moderni.

Migliorie:
- menu spostato in alto sotto il titolo, sempre cliccabile;
- nessun pulsante coperto dalla barra di navigazione Android;
- pulsanti più grandi e testo su una sola riga;
- supporto agli inset di sistema / edge-to-edge di Android 15;
- conserva lo stesso database della v1 durante l’aggiornamento.

Funzioni: Dashboard, Cedole, Rendimento, IncomeShares, Impostazioni, export CSV.
