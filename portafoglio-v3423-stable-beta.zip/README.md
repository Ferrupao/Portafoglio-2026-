# Portafoglio 2026 V3.4.23 Beta Test

Versione tecnica **3.4.23** - versionCode **65** - database **10**.

## Novità V3.4.23 – contrasto e navigazione

- sfondo generale grigio/blu chiaro per separare meglio le card;
- card bianche con bordo più leggibile ed elevazione maggiore;
- barra inferiore aumentata a 72dp, con fondo azzurrato e indicatore visivo della sezione attiva;
- Home / Portafogli / Cerca / Proventi / Altro evidenziati in modo coerente;
- funzioni meno frequenti (aggiungi portafoglio, import, backup, impostazioni, avvertenza) raccolte in **Altro**;
- Home alleggerita e analisi meno invasiva quando il rendimento non è disponibile;
- nella dashboard il grafico **Andamento patrimonio** viene subito dopo Posizioni, prima dell’analisi dettagliata;
- database invariato: nessuna migrazione dati rispetto alla V3.4.22.

Backup CSV aggiornato a **PORTAFOGLIO2026_V3423** e compatibile con i backup precedenti.
